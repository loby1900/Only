class_name Objectives
extends RefCounted
## The level's objective chain (Levels "steps"): which step is next, the HUD line for it and
## the checkpoint (where you come back after being caught — set after every finished step).
## Steps done out of order count: the chain skips everything already done.

var level: Dictionary = {}
var index := 0
var done := {}
var checkpoint := Vector3.ZERO
var checkpoint_yaw := 0.0


func reset(new_level: Dictionary, start: Vector3) -> void:
	level = new_level
	index = 0
	done.clear()
	checkpoint = start
	checkpoint_yaw = 0.0


## Marks "take:1" / "open:A" / "use:F" done; returns true when it was new.
func mark(key: String) -> bool:
	if done.has(key):
		return false
	done[key] = true
	var steps: Array = level.steps
	while index < steps.size() and done.has(key_of(steps[index])):
		index += 1
	return true


func save_checkpoint(at: Vector3, yaw: float) -> void:
	checkpoint = at
	checkpoint_yaw = yaw


## The HUD line for the next step.
func text() -> String:
	var steps: Array = level.steps
	return describe(steps[mini(index, steps.size() - 1)], level)


static func key_of(entry: Dictionary) -> String:
	var kind: String = entry.keys()[0]
	return "%s:%s" % [kind, entry[kind]]


static func describe(entry: Dictionary, lvl: Dictionary) -> String:
	var t := Hud.TEXT
	if entry.has("take"):
		return t.obj_take % Inventory.info(String(lvl.items.get(entry.take, ""))).name
	if entry.has("open"):
		var needs := String(lvl.locks.get(entry.open, ""))
		if needs == "power":
			return t.obj_power
		if needs == "crowbar":
			return t.crowbar_door
		return t.obj_open % Inventory.info(needs).name
	if entry.has("use"):
		return t.obj_use
	return t.obj_reach
