class_name ProbeWalk
extends RefCounted
## Probe helpers (test runs only): navmesh coverage of a built house, and an autopilot that
## walks the player along navmesh paths with the real movement code, opens doors on the way
## and uses things by looking at them and pressing the real "interact" action.

var probe: Node
var game: HorrorGame


func _init(owner: Node) -> void:
	probe = owner
	game = owner.get("game")


## Starts level `index` fresh through the real game flow (main's "restart").
func start_level(index: int) -> void:
	var before := NavigationServer3D.map_get_iteration_id(map())
	GameState.level = index
	(probe.get("main") as Main)._on_command("restart")
	# The rebuilt navmesh reaches the map on its next sync (a later frame when rendering is slow).
	for i in 120:
		await probe.get_tree().process_frame
		if NavigationServer3D.map_get_iteration_id(map()) != before and i > 3:
			break
	await frames(4)


func frames(count: int) -> void:
	for i in count:
		await probe.get_tree().physics_frame


## Waits up to `seconds` of game time for `condition`.
func until(condition: Callable, seconds: float) -> bool:
	var left := seconds
	while left > 0.0 and not condition.call():
		await probe.get_tree().physics_frame
		left -= probe.get_physics_process_delta_time() * Engine.time_scale
	return condition.call()


func map() -> RID:
	return game.get_world_3d().navigation_map


## Every room (flood-filled region), every cellar floor cell group and the secret must be
## reachable on the navmesh from the player's start.
func check_navmesh() -> void:
	var house := game.house
	var plan := house.plan
	var start := NavigationServer3D.map_get_closest_point(map(), house.player_start)
	var rooms := {}
	for cell: Vector2i in plan.regions:
		var region: int = plan.regions[cell]
		if rooms.get(region, false):
			continue
		var target := plan.center(cell)
		if NavigationServer3D.map_get_closest_point(map(), target).distance_to(target) > 0.4:
			continue   # furniture on this cell: try another cell of the room
		rooms[region] = reaches(start, target)
	var reached := rooms.values().count(true)
	probe.call("check", reached == rooms.size() and rooms.size() >= 4, "  navmesh: %d/%d rooms reachable from the start" % [reached, rooms.size()])
	for thing in house.things:
		if thing.kind == Interactable.Kind.SECRET:
			probe.call("check", reaches(start, thing.exit), "  navmesh: the secret in the cellar is reachable (stairs + doors)")
	for point in house.patrol:
		if not reaches(start, point):
			probe.call("check", false, "  navmesh: patrol point %s reachable" % point)


func reaches(from: Vector3, to: Vector3) -> bool:
	var path := NavigationServer3D.map_get_path(map(), from, to, true)
	return path.size() > 0 and path[path.size() - 1].distance_to(to) < 0.6


## Plays the level's "steps" like a player would. Returns true when the level completed.
func play_steps(level: Dictionary) -> bool:
	for entry: Dictionary in level.steps:
		var target := _target(entry)
		if target == null:
			probe.call("check", false, "  step %s: target exists" % entry)
			return false
		var stand: Vector3 = target.exit if target is Interactable and (target as Interactable).kind == Interactable.Kind.SECRET else _front(target)
		var arrived: bool = await walk_to(stand, 0.5)
		var used: bool = await use(target)
		probe.call("check", arrived and used, "  step %s: walked %s, used %s" % [entry, arrived, used])
		if not used:
			return false
	return await until(func() -> bool: return not game.running, 3.0)


func _target(entry: Dictionary) -> Node3D:
	var key: String = entry.values()[0]
	if entry.has("open"):
		for door in game.house.doors:
			if door.letter == key:
				return door
		return null
	for thing in game.house.things:
		if thing.slot == key and is_instance_valid(thing):
			return thing
	return null


## Where to stand to use a target: next to it, on a side the player can walk to without
## passing a locked door (the navmesh runs through doors, locked or not).
func _front(target: Node3D) -> Vector3:
	var at: Vector3 = target.global_position
	if target is Door:
		var normal := (target as Door).global_transform.basis.z
		var best := Vector3.ZERO
		var shortest := INF
		for side in [1.0, -1.0]:
			var stand := NavigationServer3D.map_get_closest_point(map(), at + normal * side * 0.9)
			var length := _length(NavigationServer3D.map_get_path(map(), game.player.global_position, stand, true))
			if length < shortest and not _crosses_locked(game.player.global_position, stand, target as Door):
				best = stand
				shortest = length
		return best
	return NavigationServer3D.map_get_closest_point(map(), at)


static func _length(path: PackedVector3Array) -> float:
	var total := 0.0
	for i in path.size() - 1:
		total += path[i].distance_to(path[i + 1])
	return total


func _crosses_locked(from: Vector3, to: Vector3, ignore: Door) -> bool:
	var path := NavigationServer3D.map_get_path(map(), from, to, true)
	for door in game.house.doors:
		if not door.locked or door == ignore:
			continue
		for i in path.size() - 1:
			var closest := Geometry3D.get_closest_point_to_segment(door.global_position, path[i], path[i + 1])
			if closest.distance_to(door.global_position) < 0.6:
				return true
	return false


## Walks along the navmesh path; opens closed, unlocked doors in the way. Game-time timeout.
func walk_to(goal: Vector3, radius: float) -> bool:
	var player := game.player
	var time := 0.0
	while time < 90.0:
		var here := player.global_position
		if Vector2(here.x - goal.x, here.z - goal.z).length() < radius and absf(here.y - goal.y) < 1.2:
			player.auto_input = Vector2.ZERO
			return true
		var path := NavigationServer3D.map_get_path(map(), here, goal, true)
		var next := goal
		for point in path:
			if Vector2(point.x - here.x, point.z - here.z).length() > 0.35:
				next = point
				break
		game.rig.yaw = atan2(-(next.x - here.x), -(next.z - here.z))
		game.rig.pitch = 0.0
		player.auto_input = Vector2(0, -1)
		for door in game.house.doors:
			if not door.is_open and not door.locked and door.global_position.distance_to(here + Vector3.UP) < 1.7:
				door.open_from(here, true)
		await probe.get_tree().physics_frame
		time += probe.get_physics_process_delta_time() * Engine.time_scale
	player.auto_input = Vector2.ZERO
	var path := NavigationServer3D.map_get_path(map(), player.global_position, goal, true)
	print("PROBE note stuck at %s (cell %s) going to %s, path %d points" % [player.global_position, game.house.plan.cell_of(player.global_position), goal, path.size()])
	return false


## Looks at the target, checks the interaction system focuses it, presses "interact".
func use(target: Node3D) -> bool:
	var player := game.player
	player.auto_input = Vector2.ZERO
	await frames(2)
	var eye := game.rig.camera.global_position
	var to: Vector3 = target.aim_point() - eye
	game.rig.yaw = atan2(-to.x, -to.z)
	game.rig.pitch = asin(clampf(to.normalized().y, -1.0, 1.0))
	await frames(3)
	if target is Door and (target as Door).is_open:
		return true   # opened on the way (walk_to opens doors in reach); progress already counted
	var focused := game.interaction.focus == target
	if not focused:
		print("PROBE note focus=%s wanted=%s dist=%.2f" % [game.interaction.focus, target, to.length()])
		return false
	var step_before := game.objectives.index
	Input.action_press("interact")
	await frames(2)
	Input.action_release("interact")
	await frames(2)
	return game.objectives.index > step_before or not game.running
