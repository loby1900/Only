class_name Interaction
extends Node
## One button for everything: every frame it finds what you look at within reach (doors,
## items, hiding spots, the fuse box, the secret), shows the prompt, and on "interact" uses it.
## Reports objective progress as "take:1", "open:A", "use:F", "reach:X" (see Levels "steps")
## and makes noise through the game. Hiding moves the camera into the wardrobe / under the bed.

signal progress(key: String)

var game: HorrorGame
var focus: Node3D                    # a Door or an Interactable
var hiding: Interactable


func update() -> void:
	var player := game.player
	if hiding:
		focus = hiding
		game.hud.set_prompt(Hud.TEXT.leave)
		if player.active and Input.is_action_just_pressed("interact"):
			unhide()
		return
	focus = _find()
	game.hud.set_prompt(prompt(focus) if focus else "")
	if focus and player.active and Input.is_action_just_pressed("interact"):
		use(focus)


func prompt(target: Node3D) -> String:
	var t := Hud.TEXT
	if target is Door:
		var door := target as Door
		if door.locked:
			if door.needs == "power":
				return t.door_power
			var name: String = Inventory.info(door.needs).name
			return (t.door_use if game.inventory.has(door.needs) else t.door_needs) % name
		return t.door_close if door.is_open else t.door_open
	var thing := target as Interactable
	match thing.kind:
		Interactable.Kind.ITEM:
			return t.take % Inventory.info(thing.item).name
		Interactable.Kind.CLOSET:
			return t.hide_closet
		Interactable.Kind.BED:
			return t.hide_bed
		Interactable.Kind.FUSE_BOX:
			return t.fuse_in if game.inventory.has("fuse") else t.fuse_need
		Interactable.Kind.EVIDENCE:
			return t.evidence
	return t.secret


func use(target: Node3D) -> void:
	if target is Door:
		_door(target as Door)
		return
	var thing := target as Interactable
	match thing.kind:
		Interactable.Kind.ITEM:
			if not game.inventory.add(thing.item):
				game.hud.toast(Hud.TEXT.bag_full, Config.CORAL)
				return
			game.house.things.erase(thing)
			thing.take()
			Sfx.play("pickup")
			game.noise(thing.global_position, Config.NOISE.pickup)
			game.hud.toast(Hud.TEXT.taken % Inventory.info(thing.item).name, Config.SUNNY)
			progress.emit("take:" + thing.slot)
		Interactable.Kind.CLOSET, Interactable.Kind.BED:
			hide(thing)
		Interactable.Kind.FUSE_BOX:
			if thing.used or not game.inventory.has("fuse"):
				Sfx.play("locked")
				return
			game.inventory.remove("fuse")
			thing.used = true
			var led: MeshInstance3D = thing.model.get_meta("led")
			var green := (led.mesh.surface_get_material(0) as StandardMaterial3D)
			green.albedo_color = Config.MINT
			green.emission = Config.MINT
			Sfx.play("fuse")
			game.set_power(true)
			progress.emit("use:F")
		Interactable.Kind.SECRET:
			if not thing.used:
				thing.open_up()
				progress.emit("reach:X")
		Interactable.Kind.EVIDENCE:
			if not thing.used:
				thing.used = true
				game.house.things.erase(thing)
				thing.take()
				GameState.add_score(50)
				GameState.add_currency(1)
				game.evidence_found += 1
				Sfx.play("pickup")
				game.hud.toast(Hud.TEXT.evidence_found % [game.evidence_found, game.evidence_total], Config.SUNNY, 2.0)
				game.noise(thing.global_position, Config.NOISE.pickup * 0.5)
				if game.evidence_found >= game.evidence_total and game.evidence_total > 0:
					GameState.add_score(200)
					GameState.add_currency(3)
					game.hud.toast(Hud.TEXT.evidence_complete, Config.MINT, 3.0)


func _door(door: Door) -> void:
	var player := game.player
	if door.locked:
		if door.needs != "power" and game.inventory.has(door.needs):
			game.inventory.remove(door.needs)
			door.unlock()
			Sfx.play("unlock")
			game.noise(door.global_position, Config.NOISE.unlock)
			door.open_from(player.global_position, true)   # Door.opened → objective progress
		else:
			Sfx.play("locked")
			game.hud.toast(prompt(door), Config.CORAL)
		return
	if door.is_open:
		door.close(player.sprinting)
	else:
		door.open_from(player.global_position, true)
		game.noise(door.global_position, Config.NOISE.door)


func hide(spot: Interactable) -> void:
	var player := game.player
	hiding = spot
	player.hidden = true
	player.shape.disabled = true
	var offset := 0.5
	player.global_position = spot.eye - Vector3.UP * offset
	player.eye_height = offset
	game.rig.snap(spot.face_yaw, -0.1 if spot.kind == Interactable.Kind.CLOSET else 0.0)
	game.brain.player_hid(spot)
	game.hud.set_hiding(spot.kind == Interactable.Kind.BED)
	Sfx.play("hide")


func unhide() -> void:
	if hiding == null:
		return
	var player := game.player
	player.global_position = hiding.exit
	player.shape.disabled = false
	player.hidden = false
	hiding = null
	game.brain.player_hid(null)
	game.hud.clear_hiding()
	Sfx.play("hide", -4.0)


## The usable thing closest to the centre of the view, within reach and not behind a wall.
func _find() -> Node3D:
	var camera := game.rig.camera
	var eye := camera.global_position
	var ahead := -camera.global_transform.basis.z
	var best: Node3D
	var best_score := 0.0
	var candidates: Array = game.house.doors + game.house.things
	for target: Node3D in candidates:
		if target is Interactable and (target as Interactable).used:
			continue
		var point: Vector3 = target.aim_point()
		var to := point - eye
		var bonus: float = target.reach_bonus() if target is Interactable else 0.3
		if to.length() > Config.INTERACT_RANGE + bonus:
			continue
		var aim := ahead.dot(to.normalized())
		if aim < 0.75 - bonus * 0.3:
			continue
		var score := aim - to.length() * 0.08
		if score > best_score and _clear(eye, point):
			best = target
			best_score = score
	return best


func _clear(from: Vector3, to: Vector3) -> bool:
	var query := PhysicsRayQueryParameters3D.create(from, to, 2, [game.player.get_rid()])
	var hit := game.player.get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or (hit.position as Vector3).distance_to(to) < 0.9
