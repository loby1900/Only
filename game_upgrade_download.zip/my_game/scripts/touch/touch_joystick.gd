class_name TouchJoystick
extends Control
## Floating joystick: the first finger that lands on the left half of the screen becomes the
## stick, centred where it landed; the base follows a finger that runs past the rim. It presses
## the move_* actions with analog strength, so gameplay only ever reads Input.get_vector().
## A second finger is left alone (the camera takes it). Hidden = inactive.
## (Godot 4.7 has a native VirtualJoystick class: never name a script class that.)

var radius := Config.JOYSTICK_RADIUS
var rest := Vector2(200, 520)          # where the faint idle stick is drawn (set by TouchControls)

var _index := -1
var _origin := Vector2.ZERO
var _knob := Vector2.ZERO


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func is_active() -> bool:
	return _index >= 0


func _input(event: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if touch.pressed and _index < 0 and touch.position.x < size.x * 0.5:
			_index = touch.index
			_origin = touch.position
			_knob = touch.position
			get_viewport().set_input_as_handled()
			queue_redraw()
		elif not touch.pressed and touch.index == _index:
			release()
			get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag and (event as InputEventScreenDrag).index == _index:
		var offset: Vector2 = (event as InputEventScreenDrag).position - _origin
		if offset.length() > radius:
			_origin += offset - offset.normalized() * radius
			offset = offset.normalized() * radius
		_knob = _origin + offset
		_apply(offset / radius)
		get_viewport().set_input_as_handled()
		queue_redraw()


## Lets go of the stick (finger lifted, pause, focus lost).
func release() -> void:
	_index = -1
	_apply(Vector2.ZERO)
	queue_redraw()


func _apply(value: Vector2) -> void:
	if value.length() < Config.JOYSTICK_DEADZONE:
		value = Vector2.ZERO
	_set_action("move_left", maxf(-value.x, 0.0))
	_set_action("move_right", maxf(value.x, 0.0))
	_set_action("move_forward", maxf(-value.y, 0.0))
	_set_action("move_back", maxf(value.y, 0.0))


static func _set_action(action: String, strength: float) -> void:
	if strength > 0.0:
		Input.action_press(action, strength)
	else:
		Input.action_release(action)


func _draw() -> void:
	var active := _index >= 0
	var center := _origin if active else rest
	var knob := _knob if active else rest
	var alpha := 1.0 if active else 0.45
	draw_circle(center, radius, Color(Config.INK, 0.28 * alpha), true, -1.0, true)
	draw_circle(center, radius, Color(Config.CREAM, 0.6 * alpha), false, 4.0, true)
	var nub := radius * 0.44
	draw_circle(knob + Vector2(0, 5), nub, Color(Config.INK, 0.3 * alpha), true, -1.0, true)
	draw_circle(knob, nub, Color(Config.SKY, 0.95 * alpha), true, -1.0, true)
	draw_circle(knob - Vector2(0, nub * 0.15), nub * 0.7, Color(Config.SKY.lightened(0.15), alpha), true, -1.0, true)
