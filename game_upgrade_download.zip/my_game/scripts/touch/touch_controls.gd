class_name TouchControls
extends Control
## The in-game touch layer: a floating TouchJoystick on the left, the ActionButtons from
## Config.TOUCH_BUTTONS at the bottom right, and CameraDrag for every other finger.
## Everything scales with the screen and re-lays out on rotation / resize. The joystick only
## takes fingers on the left half, the buttons their circles, the camera every other finger.
## Add a button: one entry in Config.TOUCH_BUTTONS (and an input action in GameState).

var joystick: TouchJoystick
var camera_drag: CameraDrag
var buttons: Array[ActionButton] = []


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	joystick = TouchJoystick.new()
	add_child(joystick)
	for entry: Array in Config.TOUCH_BUTTONS:
		var button := ActionButton.new()
		add_child(button)
		button.setup(entry[0], entry[1], entry[2], entry[5], entry[6])
		buttons.append(button)
	camera_drag = CameraDrag.new()
	add_child(camera_drag)
	resized.connect(_layout)
	_layout()


func set_rig(rig: CameraRig) -> void:
	camera_drag.rig = rig


## Shows / hides the controls; hiding lets go of every held action.
func set_active(on: bool) -> void:
	visible = on
	camera_drag.enabled = on
	release_all()


func release_all() -> void:
	joystick.release()
	camera_drag.release()
	for button in buttons:
		button.release()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		release_all()


func _layout() -> void:
	if joystick == null:
		return
	var scale_factor := clampf(minf(size.x, size.y) / 720.0, 0.7, 1.6)
	var margin := 70.0 * scale_factor
	joystick.radius = Config.JOYSTICK_RADIUS * scale_factor
	joystick.rest = Vector2(margin + joystick.radius, size.y - margin - joystick.radius)
	joystick.queue_redraw()
	var r := Config.TOUCH_BUTTON_RADIUS * scale_factor
	var anchor := Vector2(size.x - margin - r, size.y - margin - r)
	for i in buttons.size():
		# Config.TOUCH_BUTTONS: offset from the corner button in radii, and a size factor.
		var entry: Array = Config.TOUCH_BUTTONS[i]
		buttons[i].place(anchor + (entry[3] as Vector2) * r, r * float(entry[4]))
