class_name CameraDrag
extends Node
## Turns the camera with any finger the joystick and the action buttons did not take (right
## half of the screen, or a second finger) and with a right/middle mouse drag. On a computer a
## left click in the game captures the mouse for free looking (Esc / pause releases it).
## Reads _unhandled_input, so HUD buttons (pause) and the stick never reach it.

var rig: CameraRig
var enabled := true
var _index := -1


func _unhandled_input(event: InputEvent) -> void:
	if rig == null or not enabled:
		return
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if touch.pressed and _index < 0:
			_index = touch.index
		elif not touch.pressed and touch.index == _index:
			_index = -1
	elif event is InputEventScreenDrag and (event as InputEventScreenDrag).index == _index:
		rig.look((event as InputEventScreenDrag).relative)
	elif event is InputEventMouseMotion:
		var motion := event as InputEventMouseMotion
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			rig.look(motion.relative * Config.MOUSE_SENSITIVITY / Config.LOOK_SENSITIVITY)
		elif motion.button_mask & (MOUSE_BUTTON_MASK_RIGHT | MOUSE_BUTTON_MASK_MIDDLE):
			rig.look(motion.relative)
	elif event is InputEventMouseButton and (event as InputEventMouseButton).pressed:
		var button := (event as InputEventMouseButton).button_index
		if button == MOUSE_BUTTON_LEFT and event.device != InputEvent.DEVICE_ID_EMULATION \
				and not DisplayServer.is_touchscreen_available() \
				and DisplayServer.get_name() != "headless" and not GameState.probe:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func release() -> void:
	_index = -1
	if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
