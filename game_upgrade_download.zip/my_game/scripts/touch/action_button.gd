class_name ActionButton
extends Control
## A round multi-touch button that holds an input action while a finger is on it, so gameplay
## reads Input.is_action_pressed / is_action_just_pressed("interact") the same for touch,
## keyboard and gamepad. Several can be held at once, together with the joystick. The icon can
## be rotated, or replaced by a drawn glyph ("flashlight").

var action := "jump"
var radius := Config.TOUCH_BUTTON_RADIUS
var color: Color = Config.SUNNY
var icon: Texture2D
var icon_rotation := 0.0
var glyph := ""

var _index := -1


func setup(action_name: String, icon_path: String, tint: Color, rotation_deg := 0.0, glyph_name := "") -> void:
	action = action_name
	color = tint
	icon = load(icon_path) if icon_path != "" and ResourceLoader.exists(icon_path) else null
	icon_rotation = deg_to_rad(rotation_deg)
	glyph = glyph_name
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	queue_redraw()


## Centre of the button in screen pixels.
func place(center: Vector2, button_radius: float) -> void:
	radius = button_radius
	size = Vector2.ONE * radius * 2.0
	position = center - size * 0.5
	pivot_offset = size * 0.5
	queue_redraw()


func _input(event: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		var inside := touch.position.distance_to(position + size * 0.5) <= radius * 1.1
		if touch.pressed and _index < 0 and inside:
			_index = touch.index
			Input.action_press(action)
			scale = Vector2.ONE * 0.9
			get_viewport().set_input_as_handled()
		elif not touch.pressed and touch.index == _index:
			release()
			get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag and (event as InputEventScreenDrag).index == _index:
		get_viewport().set_input_as_handled()   # a held button never turns the camera


func release() -> void:
	if _index >= 0:
		Input.action_release(action)
	_index = -1
	create_tween().tween_property(self, "scale", Vector2.ONE, 0.2).set_trans(Tween.TRANS_BACK)


func _draw() -> void:
	var c := size * 0.5
	draw_circle(c + Vector2(0, 6), radius, Color(Config.INK, 0.3), true, -1.0, true)
	draw_circle(c, radius, color.darkened(0.25), true, -1.0, true)
	draw_circle(c - Vector2(0, 4), radius - 3.0, color, true, -1.0, true)
	draw_circle(c - Vector2(0, 4), radius - 3.0, Color(Config.CREAM, 0.7), false, 3.0, true)
	var side := radius * 1.0
	draw_set_transform(c - Vector2(0, 4), icon_rotation)
	if icon:
		draw_texture_rect(icon, Rect2(-Vector2(side, side) * 0.5, Vector2(side, side)), false, Config.INK)
	elif glyph == "flashlight":
		# Body, head and three beam lines.
		var u := side / 10.0
		draw_rect(Rect2(Vector2(-4.5 * u, -1.2 * u), Vector2(5.0 * u, 2.4 * u)), Config.INK, true)
		draw_colored_polygon(PackedVector2Array([Vector2(0.5 * u, -1.2 * u), Vector2(2.5 * u, -2.4 * u),
			Vector2(2.5 * u, 2.4 * u), Vector2(0.5 * u, 1.2 * u)]), Config.INK)
		for k in [-1.0, 0.0, 1.0]:
			draw_line(Vector2(3.3 * u, k * 1.5 * u), Vector2(5.0 * u, k * 2.6 * u), Config.INK, 0.8 * u, true)
	draw_set_transform(Vector2.ZERO)
