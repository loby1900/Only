class_name Hud
extends CanvasLayer
## Everything on screen, built in code with the UiStyle theme. Minimal while playing: objective
## line and night number (top left), the danger eye (top centre), lives and pause (top right),
## a dot crosshair with the interact prompt, the inventory + stamina (bottom centre), toasts,
## the mood overlay (vignette, hiding view, scare flash) and the touch controls. Menus live in
## Screens. Buttons emit `command(name)`: play, continue, resume, restart, home, pause.
## Every player-facing string is in TEXT (Turkish) — translate or rename the game there.

signal command(name: String)

const TEXT := {
    "title": "جارك الغامض", "tagline": "ادخل بيت الجار واكتشف سر القبو من غير ما يمسكك!",
    "play": "لعبة جديدة", "continue": "متابعة", "resume": "استكمال اللعب", "restart": "إعادة المحاولة",
    "retry": "حاول تاني", "home": "القائمة الرئيسية", "paused": "اللعبة متوقفة", "game_over": "الجار مسكك!",
    "score": "النقاط %d", "best": "أفضل نتيجة %d", "new_best": "رقم قياسي جديد!", "level": "الليلة %d",
    "level_done": "اكتشفت السر!", "sensitivity": "حساسية الكاميرا", "reached": "وصلت لليلة: %d",
    "door_open": "افتح الباب", "door_close": "اقفل الباب", "door_needs": "مقفول — محتاج %s",
    "door_use": "افتح باستخدام %s", "door_power": "قفل كهربائي — شغّل الكهرباء الأول", "take": "خد %s",
    "hide_closet": "استخبى في الدولاب", "hide_bed": "استخبى تحت السرير", "leave": "اخرج",
    "fuse_in": "ركّب الفيوز", "fuse_need": "علبة الكهرباء — محتاج فيوز", "secret": "افتح",
    "bag_full": "الشنطة مليانة", "taken": "خدت: %s", "checkpoint": "نقطة حفظ",
    "caught": "الجار شافك! باقي %d محاولات", "obj_take": "دور على %s", "obj_open": "افتح الباب المقفول بـ %s",
    "obj_power": "افتح الباب الكهربائي", "obj_use": "ركّب الفيوز في علبة الكهرباء", "obj_reach": "اكتشف السر في القبو",
    "crowbar_door": "استخدم العتلة وشيل الألواح", "help": "طريقة اللعب", "back": "رجوع",
    "evidence": "اجمع الدليل السري", "evidence_found": "جمعت دليل سري (%d/%d)! +50 نقطة",
    "evidence_complete": "جمعت كل الأدلة! مكافأة إضافية +200 نقطة",
    "evidence_ending": "
جمعت كل الأدلة السرية، وكشفت جزءًا إضافيًا من الحقيقة!",
    "help_text": """الهدف: اجمع المفاتيح والأدوات وافتح الأبواب لحد ما توصل للقبو.

الحركة: استخدم عصاية اللمس على الشاشة. اسحب الناحية الفاضية عشان تحرك الكاميرا.

التفاعل: قرّب من الباب أو الغرض واضغط زر التفاعل.
الجري: اضغط زر الجري، بس خلي بالك إن الجار ممكن يسمعك.
الكشاف: شغّله وقت الحاجة، واستخبى في الدولاب أو تحت السرير لو الجار قرب.

على الكمبيوتر: WASD للحركة، الماوس للكاميرا، E للتفاعل، Shift للجري، F للكشاف، C للانحناء، Space للقفز، وEsc للإيقاف."""
}
const ICON_PAUSE := "res://assets/mobile-controls/icons/icon_pause.png"

var root: Control
var touch: TouchControls
var screens: Screens
var overlay: HorrorOverlay
var eye: DangerEye
var bar: InventoryBar
var _safe: MarginContainer
var _top: Control
var _objective: Label
var _night: Label
var _lives: Label
var _prompt: Label
var _toast: Label
var _dot: Control
var _banner: Label


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = UiStyle.make_theme(26)
	add_child(root)
	overlay = HorrorOverlay.new()
	root.add_child(overlay)
	touch = TouchControls.new()
	root.add_child(touch)
	_safe = MarginContainer.new()
	_safe.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_safe.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_safe)
	_top = HudLayout.build(self, _safe)
	_banner = UiStyle.title_label("", 72, Config.SUNNY)
	_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_banner.modulate.a = 0.0
	root.add_child(_banner)
	screens = Screens.new()
	root.add_child(screens)
	screens.command.connect(func(name: String) -> void: command.emit(name))
	get_viewport().size_changed.connect(_apply_safe_area)
	_apply_safe_area()


## HudLayout hands back the widgets it built.
func adopt(parts: Dictionary) -> void:
	_objective = parts.objective
	_night = parts.night
	_lives = parts.lives
	_prompt = parts.prompt
	_toast = parts.toast
	_dot = parts.dot
	eye = parts.eye
	bar = parts.bar


func show_title() -> void:
	_set_playing(false)
	overlay.danger = 0.3
	screens.show_title(TEXT)


func show_playing() -> void:
	screens.close()
	_set_playing(true)


func show_pause() -> void:
	_set_playing(false)
	screens.show_pause(TEXT)


func show_game_over(_score: int, _best: int, _record: bool) -> void:
	_set_playing(false)
	screens.show_game_over(TEXT, GameState.level + 1)


func show_level_done() -> void:
	banner(TEXT.level_done, Config.SUNNY, 2.2)


func show_secret(text: String) -> void:
	toast(text, Config.CREAM, 3.0)


func banner(text: String, color: Color = Config.SUNNY, hold := 1.0) -> void:
	_banner.text = text
	_banner.add_theme_color_override("font_color", color)
	_banner.reset_size()
	_banner.position = (root.size - _banner.size) * Vector2(0.5, 0.16)
	_banner.modulate.a = 1.0
	UiStyle.pop(_banner, 0.0, 0.5)
	var tween := _banner.create_tween()
	tween.tween_interval(hold)
	tween.tween_property(_banner, "modulate:a", 0.0, 0.5)


## A short message under the crosshair ("Kayıt noktası", "Kırmızı anahtar alındı").
func toast(text: String, color: Color = Config.CREAM, hold := 1.4) -> void:
	_toast.text = text
	_toast.add_theme_color_override("font_color", color)
	_toast.modulate.a = 1.0
	var tween := _toast.create_tween()
	tween.tween_interval(hold)
	tween.tween_property(_toast, "modulate:a", 0.0, 0.5)


func set_status(text: String) -> void:
	_objective.text = text
	_night.text = TEXT.level % (GameState.level + 1)


func set_prompt(text: String) -> void:
	_prompt.text = text
	_prompt.visible = text != ""
	_dot.modulate = Config.SUNNY if text != "" else Color(Config.CREAM, 0.6)


func set_lives(value: int) -> void:
	_lives.text = "♥ ".repeat(maxi(value, 0)).strip_edges()


func set_inventory(items: Array[String]) -> void:
	bar.set_items(items)


func set_stamina(value: float, sprinting: bool) -> void:
	bar.set_stamina(value, sprinting)


func set_danger(value: float, state: NeighborBrain.State, alert: float) -> void:
	overlay.danger = value
	eye.show_state(value, state, alert)


func set_hiding(under_bed: bool) -> void:
	overlay.hide_mode = 1 if under_bed else 0


func clear_hiding() -> void:
	overlay.hide_mode = -1


func pulse(color: Color) -> void:
	overlay.pulse(color)


func scare() -> void:
	overlay.scare()


func _set_playing(on: bool) -> void:
	_top.visible = on
	touch.set_active(on)
	if not on:
		clear_hiding()


func _apply_safe_area() -> void:
	var margin := Vector4(28, 18, 28, 16)
	var window := Vector2(DisplayServer.window_get_size())
	if window.x > 1.0 and window.y > 1.0:
		var safe := Rect2(DisplayServer.get_display_safe_area())
		var ratio := root.get_viewport_rect().size / window
		if safe.size.x > 1.0 and Rect2(Vector2.ZERO, window).encloses(safe):
			margin.x += safe.position.x * ratio.x
			margin.y += safe.position.y * ratio.y
			margin.z += (window.x - safe.end.x) * ratio.x
	_safe.add_theme_constant_override("margin_left", int(margin.x))
	_safe.add_theme_constant_override("margin_top", int(margin.y))
	_safe.add_theme_constant_override("margin_right", int(margin.z))
	_safe.add_theme_constant_override("margin_bottom", int(margin.w))
