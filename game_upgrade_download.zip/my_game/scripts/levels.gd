class_name Levels
extends RefCounted
## The neighbour's house, one Dictionary per level. Every plan is ASCII, one character per
## Config.CELL metres; rows[0] is the far (north, -Z) edge, columns grow to +X. `cellar` rows
## have the same size and lie Config.CELLAR_DEPTH below; stairs `S` (a straight run of cells)
## go down from the end that touches a walkable ground cell.
##
## Ground legend:
##   #  wall        W  window wall      .  wood floor     :  tile floor     ,  grass    =  path
##   f  fence       D  door             A B C  locked doors (see "locks")   S  stairs down
##   1-4 items (see "items")            H  wardrobe (hide inside)          U  bed (hide under)
##   F  fuse box    X  the secret (goal) P player start   N  neighbour start
##   *  patrol waypoint   !  scare trigger (see "scares", in order)   x  bottles (loud!)
##   props: k counter  r fridge  s sofa  t table  b bookcase  v tv  w washer  c crates
##          l lamp (flickers)   e lamp wired to the fuse box (dark until power is on)
## Cellar legend: the same, plus ' ' = solid earth.
##
## "items": {digit: item id (Inventory.ITEMS)}. "locks": {door letter: item id or "power"}
## (a door needing "power" opens once the fuse box has a fuse; planks need the crowbar).
## "steps": the objective chain, in order — HUD text, checkpoints and the probe's autopilot:
##   {"take": "1"}  pick up item 1        {"open": "A"}  open locked door A
##   {"use": "F"}   put the fuse in       {"reach": "X"} open the secret → level complete
## "ai": neighbour multipliers {speed, hearing, sight}. "look": "dusk" | "night".
## ADD A LEVEL: append a Dictionary; run the probe (it walks the steps and checks the navmesh).

const LIST := [
	{
		"name": "المفتاح الأحمر", "look": "dusk", "secret": "لقيت شريط كاسيت قديم في القبو... مين اللي سجّله؟",
		"ai": {"speed": 0.9, "hearing": 0.9, "sight": 0.9},
		"items": {"1": "key_red"}, "locks": {"A": "key_red"},
		"steps": [{"take": "1"}, {"open": "A"}, {"reach": "X"}],
		"scares": [{"type": "slam"}],
		"rows": [
			"ffffffffffffffffffff",
			"f,,,,,,,,,,,,,,,,,,f",
			"f,###W###W#####W##,f",
			"f,#kkr#b..U#H...l#,f",
			"f,W:::D.*..D.....W,f",
			"f,#t::#.1.l#!.*..#,f",
			"f,##D####D#####A##,f",
			"f,#s.*.#.....x#S#,,f",
			"f,W...v#..*...#S#,,f",
			"f,#l...D....N.#S#,,f",
			"f,###D###W#D#####,,f",
			"f,,,,,,,,,,=,,,,*,,f",
			"f,,*,,,,,,,=,,,,,,,f",
			"f,,,,,,,,,,P,,,,,,,f",
			"ffffffffffffffffffff",
		],
		"cellar": [
			"                    ",
			"                    ",
			"                    ",
			"                    ",
			"                    ",
			"                    ",
			"              ###   ",
			"              #.#   ",
			"              #.#   ",
			"              #.#   ",
			"         ######.### ",
			"         #c..*...X# ",
			"         #l.H....c# ",
			"         ########## ",
			"                    ",
		],
	},
	{
		"name": "عودة الكهرباء", "look": "night", "secret": "الحيطان مليانة صور لبيتك... إزاي وصلت هنا؟",
		"ai": {"speed": 1.0, "hearing": 1.2, "sight": 1.0},
		"items": {"1": "fuse", "2": "key_blue"}, "locks": {"A": "key_blue", "B": "power"},
		"steps": [{"take": "2"}, {"open": "A"}, {"take": "1"}, {"use": "F"}, {"open": "B"}, {"reach": "X"}],
		"scares": [{"type": "figure", "at": Vector2i(19, 8)}],
		"rows": [
			"fffffffffffffffffffffff",
			"f,,,,,,,,,,,,,,,,,,,,,f",
			"f,###W####W#####W####,f",
			"f,#w::F#kk::r#H...2l#,f",
			"f,#::::D::*::#......W,f",
			"f,D::*:#::t::#..*...#,f",
			"f,#c:::#:::::#.....U#,f",
			"f,##D#####D#####D####,f",
			"f,#..*..!....x*.....#,f",
			"f,###A######D####B#D#,f",
			"f,#b...t#..v...l#S#:#,f",
			"f,W.....#...*..N#S#H#,f",
			"f,#.1..l#s......#S#:#,f",
			"f,########W#D#W######,f",
			"f,,,,,,,,,,,=,,,,,,,*,f",
			"f,,*,,,,,,,,P,,,,,,,,,f",
			"fffffffffffffffffffffff",
		],
		"cellar": [
			"                       ",
			"                       ",
			"                       ",
			"                       ",
			"                       ",
			"                       ",
			"                       ",
			"                       ",
			"                       ",
			"                ###    ",
			"                #.#    ",
			"                #.#    ",
			"                #.#    ",
			"           ######.#### ",
			"           #e...c...e# ",
			"           #c..*....X# ",
			"           ########### ",
		],
	},
	{
		"name": "الغرفة المقفولة", "look": "night", "secret": "القفص فاضي... لكن القفل مفتوح من جوه.",
		"ai": {"speed": 1.12, "hearing": 1.4, "sight": 1.1},
		"items": {"1": "key_red", "2": "crowbar", "3": "fuse"},
		"locks": {"A": "key_red", "C": "crowbar", "B": "power"},
		"steps": [{"take": "1"}, {"open": "A"}, {"take": "2"}, {"open": "C"}, {"take": "3"},
			{"use": "F"}, {"open": "B"}, {"reach": "X"}],
		"scares": [{"type": "flicker"}],
		"rows": [
			"ffffffffffffffffffffffff",
			"f,,,,,,,,,,,,,,,,,,,,,,f",
			"f,###W#####W#####W####,f",
			"f,#kk::r#....b#H....1#,f",
			"f,W:::::D.t...#...*..#,f",
			"f,#:t:::#..*..#......W,f",
			"f,#:::::#l....#l....U#,f",
			"f,###D#####D#####D####,f",
			"f,#*......x...!....*.#,f",
			"f,##D####D##C###A#####,f",
			"f,#s......l#S#c:::::w#,f",
			"f,W..*..N..#S#:::*:::W,f",
			"f,#v...t...#S#:::::2:#,f",
			"f,#......H.###c:::::c#,f",
			"f,####D#W#############,f",
			"f,,*,,=,,,,,,,,,,,*,,,,f",
			"f,,,,,P,,,,,,,,,,,,,,,,f",
			"ffffffffffffffffffffffff",
		],
		"cellar": [
			"                        ",
			"                        ",
			"                        ",
			"                        ",
			"                        ",
			"                        ",
			"                        ",
			"                        ",
			"                        ",
			"           ###          ",
			"           #.#          ",
			"           #.#          ",
			"           #.#          ",
			"       #####.########   ",
			"       #l....F#e....#   ",
			"       #..*...B....X#   ",
			"       #3..c..#.c..e#   ",
			"       ##############   ",
		],
	},
]

## Level `index` (0-based). Past the last one the plans repeat with a faster, sharper neighbour.
static func get_level(index: int) -> Dictionary:
	var level: Dictionary = (LIST[index % LIST.size()] as Dictionary).duplicate(true)
	var lap := index / LIST.size()
	for key: String in ["speed", "hearing", "sight"]:
		level.ai[key] = float(level.ai[key]) * (1.0 + 0.12 * lap)
	return level
