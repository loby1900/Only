class_name UiStyle
extends RefCounted
## The shared UI look: Lilita One for everything (Fredoka's bold variation misplaces the Turkish
## cedilla in ş/Ş, Lilita draws it correctly), letter-spaced a little for small labels,
## cream text with ink outlines, chunky rounded buttons with a darker bottom edge, dark ink
## panels, bouncy pop-ins and floating "+10" text over 3D positions. Colours come from Config.

const LILITA := preload("res://assets/game-fonts/fonts/noto_sans_arabic_bold.ttf")
const ARABIC := preload("res://assets/game-fonts/fonts/noto_sans_arabic.ttf")


## Labels and buttons: Lilita One with a touch of extra letter spacing.
static func ui_font() -> FontVariation:
	var font := FontVariation.new()
	font.base_font = ARABIC
	font.spacing_glyph = 1
	return font


static func make_theme(font_size := 30) -> Theme:
	var theme := Theme.new()
	theme.default_font = ui_font()
	theme.default_font_size = font_size
	theme.set_color("font_color", "Label", Config.CREAM)
	theme.set_color("font_outline_color", "Label", Config.INK)
	theme.set_constant("outline_size", "Label", 10)
	theme.set_color("font_shadow_color", "Label", Color(Config.INK, 0.25))
	theme.set_constant("shadow_offset_y", "Label", 3)
	theme.set_stylebox("normal", "Button", box(Config.SUNNY))
	theme.set_stylebox("hover", "Button", box(Config.SUNNY.lightened(0.08)))
	theme.set_stylebox("pressed", "Button", box(Config.SUNNY.darkened(0.06), true))
	theme.set_stylebox("disabled", "Button", box(Color(Config.INK, 0.4)))
	theme.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	for state in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		theme.set_color(state, "Button", Config.INK)
	theme.set_constant("outline_size", "Button", 0)
	theme.set_stylebox("panel", "PanelContainer", panel_box())
	return theme


## A chunky rounded slab: flat colour and a darker bottom edge that reads as thickness.
static func box(color: Color, pressed := false, radius := 24) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(radius)
	style.border_color = color.darkened(0.28)
	style.border_width_bottom = 2 if pressed else 5
	style.shadow_color = Color(Config.INK, 0.25)
	style.shadow_size = 2 if pressed else 6
	style.shadow_offset = Vector2(0, 2 if pressed else 4)
	style.content_margin_left = 34
	style.content_margin_right = 34
	style.content_margin_top = 14 + (3 if pressed else 0)
	style.content_margin_bottom = 16 - (3 if pressed else 0)
	style.anti_aliasing = true
	return style


## Dark translucent ink card behind menus.
static func panel_box() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(Config.INK, 0.72)
	style.set_corner_radius_all(32)
	style.border_color = Color(Config.CREAM, 0.18)
	style.set_border_width_all(3)
	style.set_content_margin_all(36)
	style.anti_aliasing = true
	return style


## A big rounded button in one palette colour (text in ink on light fills, cream on dark).
static func button(text: String, color: Color = Config.SUNNY, font_size := 34) -> Button:
	var node := Button.new()
	node.text = text
	node.custom_minimum_size = Vector2(280, 84)
	node.add_theme_font_size_override("font_size", font_size)
	node.add_theme_stylebox_override("normal", box(color))
	node.add_theme_stylebox_override("hover", box(color.lightened(0.08)))
	node.add_theme_stylebox_override("pressed", box(color.darkened(0.06), true))
	var text_color := Config.INK if color.get_luminance() > 0.55 else Config.CREAM
	for state in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		node.add_theme_color_override(state, text_color)
	node.pressed.connect(func() -> void: pop(node, 0.0, 0.9))
	return node


## A round icon button (pause, sound). `icon_path` is loaded at runtime.
static func icon_button(icon_path: String, color: Color = Config.SKY, size := 88) -> Button:
	var node := Button.new()
	node.custom_minimum_size = Vector2(size, size)
	node.icon = load(icon_path)
	node.expand_icon = true
	node.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	for state in ["normal", "hover", "pressed"]:
		var style := box(color.darkened(0.06) if state == "pressed" else color, state == "pressed", size / 2)
		style.set_content_margin_all(size * 0.2)
		node.add_theme_stylebox_override(state, style)
	return node


static func panel() -> PanelContainer:
	var node := PanelContainer.new()
	node.add_theme_stylebox_override("panel", panel_box())
	return node


## A label in the title font (scores, headings).
static func title_label(text: String, font_size := 72, color: Color = Config.SUNNY) -> Label:
	var label := Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_override("font", LILITA)
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_constant_override("outline_size", 14)
	return label


## A bouncy entrance: grows from `from` scale with an overshoot.
static func pop(node: Control, delay := 0.0, from := 0.7) -> void:
	node.pivot_offset = node.size * 0.5
	node.scale = Vector2.ONE * from
	var tween := node.create_tween()
	tween.tween_interval(delay)
	tween.tween_property(node, "scale", Vector2.ONE, 0.4).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


## "+10" text that rises from a 3D position. `layer` is any Control / CanvasLayer on screen.
static func float_text(layer: Node, camera: Camera3D, world_pos: Vector3, text: String, color: Color = Config.SUNNY) -> void:
	if camera == null or camera.is_position_behind(world_pos):
		return
	var label := title_label(text, 44, color)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(label)
	label.reset_size()
	label.position = camera.unproject_position(world_pos) - label.size * 0.5
	pop(label, 0.0, 0.4)
	var tween := label.create_tween().set_parallel()
	tween.tween_property(label, "position:y", label.position.y - 90.0, 0.8).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tween.tween_property(label, "modulate:a", 0.0, 0.3).set_delay(0.5)
	tween.chain().tween_callback(label.queue_free)
