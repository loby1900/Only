class_name Scares
extends Node
## Scripted scares on the plan's "!" cells, one per trigger per level, with a cooldown so they
## never pile up. Types (level "scares", in plan order):
##   {"type": "slam"}                       the nearest door slams (bang + camera shake)
##   {"type": "flicker"}                    nearby lamps die for a few seconds, a creak
##   {"type": "figure", "at": Vector2i}     a pale figure stands at that cell; look at it, look
##                                          away — gone (the "look-away" scare)
## ADD A SCARE: a new "type" branch in _fire(), then put "!" and an entry in a level.
## Also the plan's "x" bottles: walking over them (not crouched) is loud.

var game: HorrorGame
var _fired := {}
var _cooldown := 0.0
var _figure: Human
var _figure_seen := 0.0
var _figure_life := 0.0
var _bottles := 0.0


func reset() -> void:
	_fired.clear()
	_cooldown = 0.0
	_remove_figure()


func update(delta: float) -> void:
	_cooldown -= delta
	_bottles -= delta
	if _figure:
		_watch_figure(delta)
	var house := game.house
	for spot in house.bottles:
		if game.player.global_position.distance_to(spot) < 0.8 and not game.player.crouching and _bottles <= 0.0:
			_bottles = 2.5
			Sfx.play_at("bottles", spot, 2.0)
			game.noise(spot, Config.NOISE.bottles)
	var cell := house.plan.cell_of(game.player.global_position)
	for i in house.triggers.size():
		if cell == house.triggers[i] and not _fired.has(i) and _cooldown <= 0.0 and game.player.global_position.y > -1.0:
			_fired[i] = true
			_cooldown = Config.SCARE_COOLDOWN
			var list: Array = game.level.get("scares", [])
			_fire(list[i] if i < list.size() else {"type": "slam"})


func _fire(scare: Dictionary) -> void:
	var player_at := game.player.global_position
	match String(scare.type):
		"slam":
			var nearest: Door
			for door in game.house.doors:
				if not door.locked and (nearest == null or door.global_position.distance_to(player_at) < nearest.global_position.distance_to(player_at)):
					nearest = door
			if nearest:
				if not nearest.is_open:
					nearest.open_from(player_at, false)
				get_tree().create_timer(0.35).timeout.connect(func() -> void: nearest.close(true))
		"flicker":
			for lamp in game.house.lamps:
				if lamp.global_position.distance_to(player_at) < 12.0:
					lamp.blackout(2.8)
			Sfx.play("creak", -2.0)
		"figure":
			_remove_figure()
			_figure = Human.new()
			game.house.add_child(_figure)
			_figure.setup(Outfit.preset("pale"), "Idle")
			var at: Vector2i = scare.get("at", game.house.plan.cell_of(player_at))
			_figure.global_position = game.house.plan.center(at)
			var to := player_at - _figure.global_position
			_figure.rotation.y = atan2(to.x, to.z)
			_figure_seen = 0.0
			_figure_life = 10.0
			Sfx.play("creak", -4.0)


## Vanishes once you have looked at it and then looked away (or after a while).
func _watch_figure(delta: float) -> void:
	_figure_life -= delta
	var camera := game.rig.camera
	var head := _figure.global_position + Vector3.UP * 1.6
	var in_view := not camera.is_position_behind(head) and \
		(-camera.global_transform.basis.z).dot((head - camera.global_position).normalized()) > 0.8
	if in_view:
		_figure_seen += delta
	if (_figure_seen > 0.4 and not in_view) or _figure_life <= 0.0:
		Sfx.play_at("step_heavy", _figure.global_position, -4.0)
		_remove_figure()


func _remove_figure() -> void:
	if _figure and is_instance_valid(_figure):
		_figure.queue_free()
	_figure = null
