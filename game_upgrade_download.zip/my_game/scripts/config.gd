class_name Config
extends RefCounted
## Every tuning number and colour of the game lives here. Tune from this file first.
## Levels (house plans, items, locks, AI difficulty) are in scripts/levels.gd.

const PORTRAIT := false              # first-person games play landscape (1280x720)

# ── Palette: UI colours + warm/cool night mid-tones for the house ───────────
const INK := Color("#1b2a49")        # text outlines, dark accents — never pure black
const CREAM := Color("#fff8e7")      # text and small highlights only
const CORAL := Color("#f2542d")      # danger, chase, lost life
const SUNNY := Color("#ffc93c")      # prompts, keys, primary buttons
const MINT := Color("#3dbe6e")       # safe, unlocked, play
const SKY := Color("#2e9bf0")        # neutral buttons
const GRAPE := Color("#7b5cd6")      # accents, the hiding overlay
const PARTICLES := [CORAL, SUNNY, MINT, SKY, GRAPE]
## Wall tints per room (flood-filled regions pick one in turn) and the other surfaces.
const ROOM_TINTS := [Color("#8a6a58"), Color("#5f7a78"), Color("#8a7a52"), Color("#6f6488"),
	Color("#7d5f62"), Color("#5f6f8a")]
const SIDING := Color("#56627a")     # outside walls
const WOOD := Color("#7a5236")       # floors, doors
const TILE := Color("#7f8b92")       # kitchen / bathroom floors
const CEILING := Color("#5e5650")
const CONCRETE := Color("#666a70")   # cellar
const GRASS := Color("#3f6a3a")
const PATH := Color("#7a6a5c")
const FENCE := Color("#5a4636")
const ROOF := Color("#5a3a36")
const LAMP_LIGHT := Color(1.0, 0.72, 0.42)
const MOON_LIGHT := Color(0.62, 0.72, 1.0)

# ── World look (scripts/world/environment.gd) ───────────────────────────────
const LOOK := "night"                # "day", "dusk" or "night"; levels override it
const FOG_DENSITY := 0.035           # night fog: close things read, far rooms fade

# ── Camera (scripts/camera/camera_rig.gd) ───────────────────────────────────
const CAMERA_MODE := "first_person"
const CAMERA_FOV := 70.0
const CAMERA_FOV_PORTRAIT := 80.0
const CAMERA_FOLLOW := 9.0
const ORBIT_DISTANCE := 7.5
const ORBIT_ZOOM := Vector2(4.0, 12.0)
const ORBIT_PITCH_DEG := -22.0
const ORBIT_PITCH_RANGE := Vector2(-60.0, -5.0)
const ORBIT_AUTO_ALIGN := 1.4
const TARGET_HEIGHT := 1.3
const TOP_DOWN_DISTANCE := 16.0
const TOP_DOWN_PITCH_DEG := -55.0
const TOP_DOWN_YAW_DEG := 0.0
const EYE_HEIGHT := 1.6              # standing eye height (the player can override: eye_height)
const FP_PITCH_RANGE := Vector2(-80.0, 80.0)
const FIXED_POSITION := Vector3(0, 14, 16)
const FIXED_LOOK_AT := Vector3(0, 0, 0)
const LOOK_SENSITIVITY := 0.0045     # radians per dragged pixel (times the player setting)
const MOUSE_SENSITIVITY := 0.0025    # captured desktop mouse
const KEY_TURN_SPEED := 2.4
const TITLE_SPIN := 0.12

# ── Player (scripts/actors/player.gd) ───────────────────────────────────────
const WALK_SPEED := 3.0
const SPRINT_SPEED := 5.4
const CROUCH_SPEED := 1.5
const ACCELERATION := 30.0
const GRAVITY := 20.0
const PLAYER_HEIGHT := 1.75
const CROUCH_HEIGHT := 1.0
const CROUCH_EYE := 0.95
const STAMINA_DRAIN := 22.0          # per second while sprinting (stamina 0..100)
const STAMINA_REGEN := 14.0
const STAMINA_MIN := 25.0            # needed to start sprinting again after running dry
const BOB_WALK := Vector2(0.045, 1.9)    # (height, steps per metre scale)
const BOB_SPRINT := Vector2(0.08, 1.9)
const STEP_LENGTH := 1.7             # metres between footstep sounds (walking)
const INTERACT_RANGE := 2.1
const FLASHLIGHT_RANGE := 13.0
const FLASHLIGHT_ANGLE := 28.0
const FLASHLIGHT_ENERGY := 2.4

# ── Noise the neighbour can hear: radius in metres (x level "hearing") ─────
const NOISE := {"walk": 3.5, "sprint": 10.0, "crouch": 0.0, "door": 5.0, "slam": 12.0,
	"bottles": 11.0, "pickup": 2.5, "unlock": 6.0}

# ── The neighbour (scripts/ai/) ─────────────────────────────────────────────
const AI_WALK_SPEED := 1.7           # patrol / search
const AI_ALERT_SPEED := 2.6          # walking to a noise
const AI_CHASE_SPEED := 4.5          # player sprint 5.4, walk 3.0: you must run (stamina!)
const AI_SIGHT := 15.0               # metres, fully lit player
const AI_FOV_DEG := 110.0
const AI_EYE_HEIGHT := 1.65
const AI_NOTICE_TIME := 0.7          # seconds of clear view before a chase (x visibility)
const AI_LOSE_TIME := 3.0            # seconds out of sight before SEARCH
const AI_SEARCH_TIME := 12.0         # seconds searching nearby hiding spots before PATROL
const AI_SEARCH_RADIUS := 9.0
const AI_WAIT_AT_POINT := 2.5        # pause at each patrol waypoint / noise spot
const AI_CATCH_RADIUS := 1.1
const AI_DOOR_REACH := 1.4           # opens doors this close on his path
const CROUCH_SHADOW_FACTOR := 0.5    # crouching in the dark halves how visible you are
const DARK_VISIBILITY := 0.45        # unlit room, flashlight off
const MOON_VISIBILITY := 0.7         # outdoors under the moon
const RESPAWN_GRACE := 3.0           # seconds the neighbour ignores you after a respawn

# ── Tension (scripts/tension.gd) ────────────────────────────────────────────
const HEARTBEAT_RANGE := 14.0        # heartbeat starts this close to the neighbour
const HEARTBEAT_SLOW := 1.25         # seconds between beats at the edge
const HEARTBEAT_FAST := 0.42         # during a chase
const SCARE_COOLDOWN := 25.0         # seconds between scripted scares

# ── Touch controls (scripts/touch/) ─────────────────────────────────────────
const JOYSTICK_RADIUS := 110.0
const JOYSTICK_DEADZONE := 0.12
## [input action, icon path ("" = drawn glyph named in the last field), colour,
##  offset from the bottom-right corner in button radii, size, icon rotation deg, glyph]
const TOUCH_BUTTONS := [
	["interact", "res://assets/mobile-controls/icons/icon_hand.png", SUNNY, Vector2(0, 0), 1.0, 0.0, ""],
	["run", "res://assets/mobile-controls/icons/icon_burst.png", CORAL, Vector2(-2.3, 0.35), 0.78, 0.0, ""],
	["crouch", "res://assets/mobile-controls/icons/icon_arrow.png", SKY, Vector2(-0.35, -2.3), 0.72, 90.0, ""],
	["flashlight", "", MINT, Vector2(-2.25, -1.95), 0.66, 0.0, "flashlight"],
]
const TOUCH_BUTTON_RADIUS := 74.0

# ── Flow and saving ─────────────────────────────────────────────────────────
const LEVEL_DONE_DELAY := 3.2
const AUTOSAVE_DELAY := 3.0
const LIVES := 3
const CAUGHT_TIME := 1.6             # jump-scare length before the respawn

# ── The house (scripts/house/) ──────────────────────────────────────────────
const CELL := 1.5                    # metres per character of a floor plan
const WALL_HEIGHT := 2.8
const WALL_THICKNESS := 0.24
const CELLAR_DEPTH := 2.8            # cellar floor top is this far below the ground floor
const DOOR_HEIGHT := 2.1
const WINDOW_SILL := 0.9
const WINDOW_TOP := 2.1
