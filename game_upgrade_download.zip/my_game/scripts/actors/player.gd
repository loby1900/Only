class_name Player
extends CharacterBody3D
## First-person body: camera-relative walking from Input.get_vector (keyboard, gamepad and the
## touch stick press the same move_* actions), sprint while "run" is held (drains stamina; when
## it runs dry you must recover to Config.STAMINA_MIN), crouch toggle (slower, lower, quiet),
## flashlight toggle, head bob and footsteps by speed. The camera (CameraRig FIRST_PERSON)
## reads `eye_height`; every footstep emits `step(noise_radius)` for the neighbour to hear.
## `hidden` freezes it (inside a wardrobe / under a bed). `auto_input` drives it in tests.

signal step(noise: float, sprinting: bool)
signal flashlight_toggled(on: bool)

var camera_basis := Basis.IDENTITY    # set by CameraRig every frame
var active := false                   # false = ignores input (menus, jump-scare, hiding)
var crouching := false
var sprinting := false
var hidden := false
var stamina := 100.0
var eye_height := Config.EYE_HEIGHT   # includes head bob; CameraRig reads it
var auto_input := Vector2.ZERO        # non-zero: overrides the stick (probe autopilot)
var flashlight: SpotLight3D           # on the camera; created by the game
var move_scale := 1.0
var _exhausted := false
var _bob := 0.0
var _walked := 0.0
var _eye := Config.EYE_HEIGHT
var _capsule: CapsuleShape3D

@onready var shape: CollisionShape3D = $CollisionShape3D


func _ready() -> void:
	_capsule = (shape.shape as CapsuleShape3D).duplicate()
	shape.shape = _capsule
	_set_height(Config.PLAYER_HEIGHT)


func respawn(at: Vector3) -> void:
	global_position = at
	velocity = Vector3.ZERO
	stamina = 100.0
	_exhausted = false
	set_crouch(false)
	hidden = false


func set_model_visible(_on: bool) -> void:
	pass   # no body model in first person


func set_crouch(on: bool) -> void:
	crouching = on
	_set_height(Config.CROUCH_HEIGHT if on else Config.PLAYER_HEIGHT)


func toggle_flashlight() -> void:
	if flashlight:
		flashlight.visible = not flashlight.visible
		Sfx.play("click", -10.0)
		flashlight_toggled.emit(flashlight.visible)


## A soft torch beam on the camera (off until toggled).
func attach_flashlight(camera: Camera3D) -> void:
	flashlight = SpotLight3D.new()
	flashlight.spot_range = Config.FLASHLIGHT_RANGE
	flashlight.spot_angle = Config.FLASHLIGHT_ANGLE
	flashlight.spot_angle_attenuation = 1.6
	flashlight.spot_attenuation = 0.9
	flashlight.light_energy = Config.FLASHLIGHT_ENERGY
	flashlight.light_color = Color(1.0, 0.94, 0.82)
	flashlight.shadow_enabled = true
	flashlight.position = Vector3(0.18, -0.2, 0.0)
	flashlight.visible = false
	camera.add_child(flashlight)


func flashlight_on() -> bool:
	return flashlight != null and flashlight.visible


func _physics_process(delta: float) -> void:
	if hidden:
		velocity = Vector3.ZERO
		return
	var input := auto_input
	if input == Vector2.ZERO and active:
		input = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if active and Input.is_action_just_pressed("crouch"):
		set_crouch(not crouching)
	if active and Input.is_action_just_pressed("flashlight"):
		toggle_flashlight()
	var wants_sprint := active and Input.is_action_pressed("run") and input.length() > 0.2
	sprinting = wants_sprint and not _exhausted and stamina > 0.0
	if sprinting:
		if crouching:
			set_crouch(false)
		stamina = maxf(stamina - Config.STAMINA_DRAIN * delta, 0.0)
		_exhausted = stamina <= 0.0
	else:
		stamina = minf(stamina + Config.STAMINA_REGEN * delta, 100.0)
		if stamina >= Config.STAMINA_MIN:
			_exhausted = false
	var speed := Config.SPRINT_SPEED if sprinting else (Config.CROUCH_SPEED if crouching else Config.WALK_SPEED)
	var forward := Vector3(-camera_basis.z.x, 0.0, -camera_basis.z.z).normalized()
	var right := Vector3(camera_basis.x.x, 0.0, camera_basis.x.z).normalized()
	var direction := (right * input.x + forward * -input.y).limit_length(1.0)
	var horizontal := Vector3(velocity.x, 0.0, velocity.z)
	horizontal = horizontal.move_toward(direction * speed * move_scale, Config.ACCELERATION * delta)
	velocity.x = horizontal.x
	velocity.z = horizontal.z
	velocity.y = 0.0 if is_on_floor() else velocity.y - Config.GRAVITY * delta
	move_and_slide()
	_head(delta, Vector2(get_real_velocity().x, get_real_velocity().z).length())


## Eye height, head bob and footsteps.
func _head(delta: float, flat_speed: float) -> void:
	var target := Config.CROUCH_EYE if crouching else Config.EYE_HEIGHT
	_eye = lerpf(_eye, target, 1.0 - exp(-10.0 * delta))
	var bob := Config.BOB_SPRINT if sprinting else Config.BOB_WALK
	if is_on_floor() and flat_speed > 0.3:
		_bob += delta * flat_speed * bob.y * PI / Config.STEP_LENGTH
		_walked += flat_speed * delta
	else:
		_bob = lerpf(_bob, roundf(_bob / PI) * PI, 1.0 - exp(-6.0 * delta))
	var amount := bob.x * (0.5 if crouching else 1.0)
	eye_height = _eye + absf(sin(_bob)) * amount - amount * 0.5
	var stride := Config.STEP_LENGTH * (1.25 if sprinting else (0.75 if crouching else 1.0))
	if _walked >= stride:
		_walked = 0.0
		var noise: float = Config.NOISE.sprint if sprinting else (Config.NOISE.crouch if crouching else Config.NOISE.walk)
		step.emit(noise, sprinting)


func _set_height(height: float) -> void:
	_capsule.radius = 0.3
	_capsule.height = height
	shape.position.y = height * 0.5
