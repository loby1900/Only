class_name OutfitMesh
extends RefCounted
## Mesh baking for Outfit, built once per gender / garment and cached.
## body(): the body mesh with clothing coordinates baked into vertex attributes from the skin
##   weights (which bones move a vertex decides what it wears):
##     COLOR = (torso, legs, arms, head+hands) region weights, blended at the joints
##     UV2   = (arm_t, leg_t): 0 at the shoulder → 1 at the wrist, 0 at the ankle → 1 at the hip
## shell(): a garment = the body triangles of its region pushed out along the normals, sharing
##   the skin and bone weights. Garments: top_0/1/2, trousers, shoes, jacket, open_jacket, suit,
##   hoodie, coat.

static var _bodies := {}           # gender -> {mesh, skin, albedo, normal, roughness, ...}
static var _shells := {}           # "gender/garment" -> ArrayMesh


static func body(gender: String, sample_root: Node3D) -> Dictionary:
	if _bodies.has(gender):
		return _bodies[gender]
	var source: MeshInstance3D
	for mesh_node: MeshInstance3D in sample_root.find_children("*", "MeshInstance3D", true, false):
		if mesh_node.name.to_lower().begins_with("superhero"):
			source = mesh_node
	var skeleton: Skeleton3D = sample_root.find_child("Skeleton3D", true, false)
	var rest := func(bone: String) -> Vector3: return skeleton.get_bone_global_rest(skeleton.find_bone(bone)).origin
	var shoulder_x: float = rest.call("upperarm_l").x
	var wrist_x: float = rest.call("hand_l").x - 0.02
	var ankle_y: float = rest.call("foot_l").y + 0.035
	var hip_y: float = rest.call("thigh_l").y
	# Bone → region: 0 torso, 1 legs, 2 arms, 3 head/neck/hands (skin).
	var region := PackedInt32Array()
	region.resize(skeleton.get_bone_count())
	for bone in skeleton.get_bone_count():
		var name := skeleton.get_bone_name(bone)
		if name.begins_with("spine") or name.begins_with("clavicle"):
			region[bone] = 0
		elif name == "pelvis" or name.begins_with("thigh") or name.begins_with("calf") or name.begins_with("foot") or name.begins_with("ball"):
			region[bone] = 1
		elif name.begins_with("upperarm") or name.begins_with("lowerarm"):
			region[bone] = 2
		else:
			region[bone] = 3
	var skin := source.skin
	var bind_region := PackedInt32Array()
	bind_region.resize(skin.get_bind_count())
	for bind in skin.get_bind_count():
		var bone := skeleton.find_bone(skin.get_bind_name(bind))
		bind_region[bind] = region[bone] if bone >= 0 else 3
	var mesh := source.mesh as ArrayMesh
	var arrays := mesh.surface_get_arrays(0)
	var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var bones: PackedInt32Array = arrays[Mesh.ARRAY_BONES]
	var weights: PackedFloat32Array = arrays[Mesh.ARRAY_WEIGHTS]
	var count := vertices.size()
	var per_vertex := bones.size() / count
	var colors := PackedColorArray()
	colors.resize(count)
	var coords := PackedVector2Array()
	coords.resize(count)
	for v in count:
		var sums := [0.0, 0.0, 0.0, 0.0]
		for k in per_vertex:
			var i := v * per_vertex + k
			sums[bind_region[bones[i]]] += weights[i]
		colors[v] = Color(sums[0], sums[1], sums[2], sums[3])
		var p := vertices[v]
		coords[v] = Vector2((absf(p.x) - shoulder_x) / (wrist_x - shoulder_x), (p.y - ankle_y) / (hip_y - ankle_y))
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_TEX_UV2] = coords
	for custom in [Mesh.ARRAY_CUSTOM0, Mesh.ARRAY_CUSTOM1, Mesh.ARRAY_CUSTOM2, Mesh.ARRAY_CUSTOM3]:
		arrays[custom] = null
	var flags := Mesh.ARRAY_FLAG_USE_8_BONE_WEIGHTS if per_vertex == 8 else 0
	var dressed := ArrayMesh.new()
	dressed.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays, [], {}, flags)
	var material := mesh.surface_get_material(0) as StandardMaterial3D
	var data := {
		"mesh": dressed, "arrays": arrays, "flags": flags, "skin": skin, "per_vertex": per_vertex,
		"albedo": material.albedo_texture, "normal": material.normal_texture, "roughness": material.roughness_texture,
		"head_y": rest.call("Head").y, "hip_y": hip_y,
	}
	_bodies[gender] = data
	return data


static func shell(gender: String, garment: String, data: Dictionary) -> ArrayMesh:
	var key := gender + "/" + garment
	if _shells.has(key):
		return _shells[key]
	var arrays: Array = data.arrays
	var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var normals: PackedVector3Array = arrays[Mesh.ARRAY_NORMAL]
	var colors: PackedColorArray = arrays[Mesh.ARRAY_COLOR]
	var coords: PackedVector2Array = arrays[Mesh.ARRAY_TEX_UV2]
	var indices: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
	var head_y: float = data.head_y
	var offset: float = {"hoodie": 0.032, "coat": 0.03, "top_0": 0.01, "top_1": 0.01, "top_2": 0.01,
		"trousers": 0.014, "shoes": 0.013}.get(garment, 0.024)
	var covers := func(v: int) -> bool:
		var c := colors[v]
		var t := coords[v]
		match garment:
			"jacket", "suit", "hoodie", "open_jacket", "coat":
				return (c.r + c.b * float(t.x < 0.97) > 0.5 and vertices[v].y < head_y - 0.06) or (garment == "coat" and c.g > 0.5 and t.y > 0.86)
			"top_0", "top_1", "top_2":
				var sleeve: float = [0.0, 0.3, 1.0][int(garment.right(1))]
				return c.r + c.b * float(t.x < sleeve) > 0.5 and vertices[v].y < head_y - 0.07
			"trousers":
				return c.g > 0.5 and t.y > 0.02 and c.r < 0.5
			"shoes":
				return c.g > 0.5 and t.y < 0.03
		return false
	var remap := PackedInt32Array()
	remap.resize(vertices.size())
	remap.fill(-1)
	var order: Array[int] = []
	var kept := PackedInt32Array()
	for tri in range(0, indices.size(), 3):
		var a := indices[tri]
		var b := indices[tri + 1]
		var c := indices[tri + 2]
		if not (covers.call(a) and covers.call(b) and covers.call(c)):
			continue
		var centre := (vertices[a] + vertices[b] + vertices[c]) / 3.0
		# Open fronts: a V down the chest shows the shirt.
		if garment in ["suit", "open_jacket"] and centre.z > 0.0 and centre.y > data.hip_y + 0.02:
			var half := 0.02 + maxf(centre.y - (data.hip_y + 0.2), 0.0) * (0.12 if garment == "suit" else 0.08)
			if absf(centre.x) < half:
				continue
		for v in [a, b, c]:
			if remap[v] < 0:
				remap[v] = order.size()
				order.append(v)
			kept.append(remap[v])
	var out := []
	out.resize(Mesh.ARRAY_MAX)
	var new_vertices := PackedVector3Array()
	var new_normals := PackedVector3Array()
	var new_uv := PackedVector2Array()
	var new_uv2 := PackedVector2Array()
	var new_bones := PackedInt32Array()
	var new_weights := PackedFloat32Array()
	var per_vertex: int = data.per_vertex
	var source_uv: PackedVector2Array = arrays[Mesh.ARRAY_TEX_UV]
	var source_bones: PackedInt32Array = arrays[Mesh.ARRAY_BONES]
	var source_weights: PackedFloat32Array = arrays[Mesh.ARRAY_WEIGHTS]
	for v in order:
		var push := offset
		if garment in ["hoodie", "coat"] and colors[v].b < 0.5:
			push += 0.008              # roomier around the torso than on the arms
		if garment == "trousers":
			push += clampf(0.6 - coords[v].y, 0.0, 0.6) * 0.012   # hang toward the hem
		new_vertices.append(vertices[v] + normals[v] * push)
		new_normals.append(normals[v])
		new_uv.append(source_uv[v])
		new_uv2.append(coords[v])
		for k in per_vertex:
			new_bones.append(source_bones[v * per_vertex + k])
			new_weights.append(source_weights[v * per_vertex + k])
	out[Mesh.ARRAY_VERTEX] = new_vertices
	out[Mesh.ARRAY_NORMAL] = new_normals
	out[Mesh.ARRAY_TEX_UV] = new_uv
	out[Mesh.ARRAY_TEX_UV2] = new_uv2
	out[Mesh.ARRAY_BONES] = new_bones
	out[Mesh.ARRAY_WEIGHTS] = new_weights
	out[Mesh.ARRAY_INDEX] = kept
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, out, [], {}, data.flags)
	_shells[key] = mesh
	return mesh
