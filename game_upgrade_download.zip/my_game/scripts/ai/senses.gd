class_name Senses
extends RefCounted
## What the neighbour can perceive. Pure functions, used by NeighborBrain every physics frame.
##   exposure(): 0..1 how visible you are — flashlight on or a lamp nearby = 1, moonlit yard =
##     MOON_VISIBILITY, dark room = DARK_VISIBILITY; crouching in the dark halves it.
##   sees(): inside his vision cone (or right next to him), within AI_SIGHT x exposure x level
##     "sight", and a clear ray from his eyes (walls and closed doors block it).
##   hears(): a noise radius (Config.NOISE x level "hearing"); a floor between you halves it.

const SIGHT_MASK := 2 | 16            # walls/furniture + doors


static func exposure(player: Player, house: House) -> float:
	if player.flashlight_on():
		return 1.0
	var chest := player.global_position + Vector3.UP
	var light := 0.0
	for lamp in house.lamps:
		light = maxf(light, lamp.lit_at(chest))
	var outside := chest.y > -1.0 and house.plan.outdoor(house.plan.cell_of(chest))
	var base := Config.MOON_VISIBILITY if outside else Config.DARK_VISIBILITY
	var value := maxf(base, lerpf(Config.DARK_VISIBILITY, 1.0, light))
	if player.crouching and light < 0.35:
		value *= Config.CROUCH_SHADOW_FACTOR
	return value


static func sees(neighbor: Neighbor, player: Player, visible: float, sight: float) -> bool:
	if player.hidden:
		return false
	var eye := neighbor.eye()
	var target := player.global_position + Vector3.UP * (0.6 if player.crouching else 1.3)
	var to := target - eye
	var distance := to.length()
	var close := distance < 1.8
	if distance > Config.AI_SIGHT * sight * visible and not close:
		return false
	var flat := Vector3(to.x, 0.0, to.z).normalized()
	if not close and neighbor.facing().dot(flat) < cos(deg_to_rad(Config.AI_FOV_DEG * 0.5)):
		return false
	var query := PhysicsRayQueryParameters3D.create(eye, target, SIGHT_MASK, [neighbor.get_rid(), player.get_rid()])
	return neighbor.get_world_3d().direct_space_state.intersect_ray(query).is_empty()


static func hears(neighbor: Neighbor, at: Vector3, radius: float, hearing: float) -> bool:
	var reach := radius * hearing
	if (at.y < -1.2) != (neighbor.global_position.y < -1.2):
		reach *= 0.5
	return reach > 0.0 and neighbor.global_position.distance_to(at) <= reach
