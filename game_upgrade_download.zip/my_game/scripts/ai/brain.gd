class_name NeighborBrain
extends Node
## The neighbour's mind — a state machine over the Neighbor body:
##   PATROL      walks the plan's * waypoints, pausing at each
##   SUSPICIOUS  heard a noise (running, bottles, a door) or glimpsed you: walks to the spot
##   CHASE       sees you (Senses): runs at you; out of sight for AI_LOSE_TIME → SEARCH
##   SEARCH      checks hiding spots and corners near where you vanished, then back to PATROL
##   CATCH       close enough: emits caught_player (the game plays the jump-scare)
## "alert" (0..1) fills while he sees you — faster when you are lit and close — and a chase
## starts at 1, so a quick crouched glimpse in the dark only makes him curious.
## Hiding: he can't see you in a wardrobe / under a bed unless he saw you get in (saw_hide).
## Tuning: Config.AI_* and the level's "ai" {speed, hearing, sight}.

signal state_changed(state: State)
signal caught_player

enum State { PATROL, SUSPICIOUS, CHASE, SEARCH, CATCH }
const NAMES := ["PATROL", "SUSPICIOUS", "CHASE", "SEARCH", "CATCH"]

var neighbor: Neighbor
var player: Player
var house: House
var tuning := {"speed": 1.0, "hearing": 1.0, "sight": 1.0}
var state := State.PATROL
var enabled := true
var alert := 0.0
var seeing := false
var last_seen := Vector3.ZERO
var noise_at := Vector3.ZERO
var saw_hide := false
var hide_spot: Interactable          # where the player is hiding (set by Interaction)
var _timer := 0.0
var _wait := 0.0
var _look_base := 0.0
var _patrol := 0
var _search: Array[Vector3] = []
var _grace := 0.0
var _rng := RandomNumberGenerator.new()


## Back to patrolling from `start`; ignores the player for `grace` seconds.
func reset(start: Vector3, grace := 0.0) -> void:
	neighbor.place(start)
	alert = 0.0
	saw_hide = false
	_grace = grace
	_patrol = _rng.randi_range(0, maxi(house.patrol.size() - 1, 0))
	_enter(State.PATROL)
	_wait = 0.001            # stands and looks around where he appears before walking on


## A noise at `at` with base radius `radius` (Config.NOISE).
func hear(at: Vector3, radius: float) -> void:
	if not enabled or state == State.CHASE or state == State.CATCH:
		return
	if Senses.hears(neighbor, at, radius, tuning.hearing):
		noise_at = _on_mesh(at)
		_enter(State.SUSPICIOUS)


## Interaction calls this when the player gets into a hiding spot (null when leaving it).
func player_hid(spot: Interactable) -> void:
	hide_spot = spot
	if spot:
		saw_hide = seeing


func _physics_process(delta: float) -> void:
	if not enabled or player == null or state == State.CATCH:
		return
	_grace -= delta
	var visible := Senses.exposure(player, house)
	seeing = _grace <= 0.0 and Senses.sees(neighbor, player, visible, tuning.sight)
	if seeing:
		last_seen = player.global_position
		var near := 2.0 if neighbor.global_position.distance_to(player.global_position) < 4.0 else 1.0
		var eager := 1.6 if state != State.PATROL else 1.0
		alert = minf(alert + delta * visible * near * eager / Config.AI_NOTICE_TIME, 1.0)
	elif state != State.CHASE:
		alert = maxf(alert - delta * 0.25, 0.0)
	if alert >= 1.0 and state != State.CHASE:
		_enter(State.CHASE)
	elif seeing and alert > 0.4 and state == State.PATROL:
		noise_at = _on_mesh(player.global_position)
		_enter(State.SUSPICIOUS)
	_timer += delta
	match state:
		State.PATROL:
			_patrol_step(delta)
		State.SUSPICIOUS:
			neighbor.go(noise_at, Config.AI_ALERT_SPEED * tuning.speed)
			if neighbor.arrived():
				_look_around(delta, func() -> void: _enter(State.SEARCH))
		State.CHASE:
			_chase_step()
		State.SEARCH:
			_search_step(delta)


func _patrol_step(delta: float) -> void:
	if house.patrol.is_empty():
		return
	var point := house.patrol[_patrol % house.patrol.size()]
	if _wait <= 0.0:
		neighbor.go(point, Config.AI_WALK_SPEED * tuning.speed)
	else:
		neighbor.halt()
	if neighbor.arrived():
		_look_around(delta, func() -> void:
			_patrol = (_patrol + 1 + _rng.randi_range(0, 1)) % house.patrol.size())


func _chase_step() -> void:
	if player.hidden:
		if saw_hide and hide_spot:
			neighbor.go(hide_spot.exit, Config.AI_CHASE_SPEED * tuning.speed)
			if neighbor.global_position.distance_to(hide_spot.exit) < 0.9:
				neighbor.face(hide_spot.global_position)
				_enter(State.CATCH)
		else:
			_enter(State.SEARCH)
		return
	if seeing:
		_timer = 0.0
		neighbor.go(player.global_position, Config.AI_CHASE_SPEED * tuning.speed)
	else:
		neighbor.go(last_seen, Config.AI_CHASE_SPEED * tuning.speed)
		if _timer > Config.AI_LOSE_TIME:
			_enter(State.SEARCH)
	var gap := neighbor.global_position - player.global_position
	if Vector2(gap.x, gap.z).length() < Config.AI_CATCH_RADIUS and absf(gap.y) < 1.0:
		_enter(State.CATCH)


func _search_step(delta: float) -> void:
	if _search.is_empty() or _timer > Config.AI_SEARCH_TIME:
		_enter(State.PATROL)
		return
	neighbor.go(_search[0], Config.AI_ALERT_SPEED * 0.8 * tuning.speed)
	if neighbor.arrived():
		_look_around(delta, func() -> void: _search.pop_front())


## Stands and looks left and right for AI_WAIT_AT_POINT seconds, then calls `done`.
func _look_around(delta: float, done: Callable) -> void:
	if _wait <= 0.001:
		_look_base = neighbor.body.rotation.y
	_wait += delta
	var angle := _look_base + sin(_wait * 1.4) * 1.1
	neighbor.face(neighbor.global_position + Vector3(sin(angle), 0, cos(angle)))
	if _wait >= Config.AI_WAIT_AT_POINT:
		_wait = 0.0
		done.call()


func _enter(next: State) -> void:
	if next == State.SEARCH:
		_plan_search()
	if next == State.CHASE:
		alert = 1.0
	elif next == State.PATROL:
		alert = minf(alert, 0.3)
	_timer = 0.0
	_wait = 0.0
	if next == State.CATCH:
		neighbor.halt()
		caught_player.emit()
	if next != state:
		state = next
		state_changed.emit(state)


## Hiding spots near where he lost you (closest first), then two random corners nearby.
func _plan_search() -> void:
	_search.clear()
	var centre := last_seen if state == State.CHASE else noise_at
	var spots: Array[Interactable] = []
	for thing in house.things:
		if (thing.kind == Interactable.Kind.CLOSET or thing.kind == Interactable.Kind.BED) \
				and thing.exit.distance_to(centre) < Config.AI_SEARCH_RADIUS:
			spots.append(thing)
	spots.sort_custom(func(a: Interactable, b: Interactable) -> bool: return a.exit.distance_to(centre) < b.exit.distance_to(centre))
	for spot in spots.slice(0, 3):
		_search.append(spot.exit)
	for i in 2:
		var offset := Vector3(_rng.randf_range(-4, 4), 0, _rng.randf_range(-4, 4))
		_search.append(_on_mesh(centre + offset))


func _on_mesh(point: Vector3) -> Vector3:
	return NavigationServer3D.map_get_closest_point(neighbor.get_world_3d().navigation_map, point)
