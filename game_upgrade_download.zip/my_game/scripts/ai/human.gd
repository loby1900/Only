class_name Human
extends Node3D
## A realistic person: the rigged man/woman body dressed by Outfit (scripts/ai/outfit.gd) and
## animated with the shared humanoid library. Faces +Z.
##
## Clip names are the imported ones: Godot strips the "_Loop" suffix and makes those clips loop
## (Walk, Walk_Formal, Idle, Sprint, Jog_Fwd, Idle_Torch, Idle_Lantern, Idle_FoldArms, Idle_No,
## Crouch_Fwd, Zombie_Walk_Fwd, Zombie_Idle ...). One-shots: Interact, Push, Punch_Cross,
## Melee_Hook, Zombie_Scratch, Hit_Chest, PickUp_Table, OverhandThrow, Yes.

const LIBRARIES := ["res://assets/quaternius-animations/ual1_standard.glb",
	"res://assets/quaternius-animations-2/ual2_standard.glb"]

static var _library: AnimationLibrary

var look: Dictionary
var anim: AnimationPlayer
var skeleton: Skeleton3D
var _clip := ""


func setup(new_look: Dictionary, idle := "Idle") -> void:
	look = new_look
	var body: Node3D = load(Outfit.BODY % ("female" if look.female else "male")).instantiate()
	add_child(body)
	body.scale = Vector3.ONE * float(look.height)
	skeleton = body.find_child("Skeleton3D", true, false)
	Outfit.dress(body, look)
	anim = AnimationPlayer.new()
	anim.name = "AnimationPlayer"
	body.add_child(anim)
	anim.add_animation_library("", library())
	play(idle)


func play(clip: String, blend := 0.2, speed := 1.0) -> void:
	anim.speed_scale = speed
	if clip == _clip or not anim.has_animation(clip):
		return
	_clip = clip
	anim.play(clip, blend)


## Restart a one-shot clip even if it is already playing.
func replay(clip: String, blend := 0.08, speed := 1.0) -> void:
	_clip = ""
	play(clip, blend, speed)
	anim.seek(0.0, true)


func current() -> String:
	return _clip


func clip_length(clip: String) -> float:
	return anim.get_animation(clip).length if anim.has_animation(clip) else 0.5


## One library for everybody: both packs merged, root motion off (controllers move people).
static func library() -> AnimationLibrary:
	if _library:
		return _library
	_library = AnimationLibrary.new()
	for path: String in LIBRARIES:
		var scene: Node = load(path).instantiate()
		var source: AnimationPlayer = scene.find_child("AnimationPlayer", true, false)
		for clip in source.get_animation_list():
			if _library.has_animation(clip):
				continue
			var animation := source.get_animation(clip)
			for track in animation.get_track_count():
				if animation.track_get_type(track) == Animation.TYPE_POSITION_3D and String(animation.track_get_path(track)).ends_with(":root"):
					animation.track_set_enabled(track, false)
			_library.add_animation(clip, animation)
		scene.free()
	return _library
