class_name Neighbor
extends CharacterBody3D
## The neighbour's body: a realistic dressed Human (Outfit "neighbor") with a lantern in his hand,
## moved along the baked navmesh by a NavigationAgent3D. It walks where the brain (NeighborBrain,
## child node "Brain") tells it, opens only unlocked doors, cannot bypass any locked door, picks
## walk / sprint / idle clips by speed and plays footsteps.
## MONSTER INSTEAD: change LOOK and CLIPS (e.g. "pale" + Zombie_Walk_Fwd / Zombie_Idle /
## Zombie_Scratch), or replace _make_body() with any rigged .glb that has an AnimationPlayer.

const LOOK := "neighbor"
const CLIPS := {"idle": "Idle", "walk": "Walk", "run": "Sprint", "search": "Idle_FoldArms", "grab": "Interact"}
const HEIGHT := 1.85

var house: House
var speed := 0.0
var moving := false
var blocked_by: Door                  # a locked door blocking his current path
var body: Human
var agent: NavigationAgent3D
var lantern: OmniLight3D
var _stuck := 0.0
var _last := Vector3.ZERO
var _stride := 0.0
var _one_shot := 0.0
var _face_target := Vector3.INF


func _ready() -> void:
	collision_layer = 4
	collision_mask = 2 | 16
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.3
	capsule.height = HEIGHT
	shape.shape = capsule
	shape.position.y = HEIGHT * 0.5
	add_child(shape)
	_make_body()
	agent = NavigationAgent3D.new()
	agent.path_desired_distance = 0.45
	agent.target_desired_distance = 0.55
	agent.radius = 0.3
	agent.height = HEIGHT
	add_child(agent)


func _make_body() -> void:
	body = Human.new()
	add_child(body)
	body.setup(Outfit.preset(LOOK), CLIPS.idle)
	# A small warm lantern in his right hand: you see him coming in the dark.
	var hand := BoneAttachment3D.new()
	hand.bone_name = "hand_r"
	body.skeleton.add_child(hand)
	lantern = OmniLight3D.new()
	lantern.light_color = Color(1.0, 0.66, 0.36)
	lantern.light_energy = 0.9
	lantern.omni_range = 4.5
	hand.add_child(lantern)


func place(at: Vector3) -> void:
	global_position = at
	velocity = Vector3.ZERO
	moving = false
	agent.target_position = at


func go(target: Vector3, new_speed: float) -> void:
	if not moving or agent.target_position.distance_to(target) > 0.3:
		agent.target_position = target
	speed = new_speed
	moving = true
	_face_target = Vector3.INF


func halt() -> void:
	moving = false


func arrived() -> bool:
	return not moving or agent.is_navigation_finished()


## Turns toward a point while standing still (checking a noise, a wardrobe, the player).
func face(point: Vector3) -> void:
	_face_target = point


func eye() -> Vector3:
	return global_position + Vector3.UP * Config.AI_EYE_HEIGHT


func facing() -> Vector3:
	return Vector3(sin(body.rotation.y), 0.0, cos(body.rotation.y))


## Plays a one-shot clip (the grab) for `time` seconds over the locomotion clips.
func gesture(clip: String, time: float) -> void:
	body.replay(CLIPS.get(clip, clip), 0.1)
	_one_shot = time


func _physics_process(delta: float) -> void:
	var flat := Vector3.ZERO
	blocked_by = null
	if moving and not agent.is_navigation_finished():
		var next := agent.get_next_path_position()
		flat = Vector3(next.x - global_position.x, 0.0, next.z - global_position.z)
		if flat.length() > 0.05:
			flat = flat.normalized() * speed
		_doors(flat)
		if blocked_by:
			flat = Vector3.ZERO
	velocity.x = move_toward(velocity.x, flat.x, 20.0 * delta)
	velocity.z = move_toward(velocity.z, flat.z, 20.0 * delta)
	velocity.y = 0.0 if is_on_floor() else velocity.y - Config.GRAVITY * delta
	move_and_slide()
	var real := Vector2(get_real_velocity().x, get_real_velocity().z)
	var look := Vector3(real.x, 0, real.y)
	if _face_target != Vector3.INF:
		look = _face_target - global_position
	if Vector2(look.x, look.z).length() > 0.1:
		body.rotation.y = lerp_angle(body.rotation.y, atan2(look.x, look.z), 1.0 - exp(-8.0 * delta))
	_animate(real.length(), delta)
	_unstick(delta)


func _doors(direction: Vector3) -> void:
	for door in house.doors:
		var to := door.global_position - global_position
		if absf(to.y) > 1.5 or Vector2(to.x, to.z).length() > Config.AI_DOOR_REACH:
			continue
		if door.is_open:
			door.keep_open()
		elif direction.dot(Vector3(to.x, 0, to.z)) > 0.0:
			# Locked doors are real barriers for the neighbour, regardless of which key
			# the player needs. The old logic let him open every keyed door for free.
			if door.locked:
				blocked_by = door
			else:
				door.pass_through(global_position)


func _animate(real_speed: float, delta: float) -> void:
	_one_shot -= delta
	if _one_shot > 0.0:
		return
	if real_speed > 3.0:
		body.play(CLIPS.run, 0.2, real_speed / 5.2)
	elif real_speed > 0.25:
		body.play(CLIPS.walk, 0.25, real_speed / 1.5)
	else:
		body.play(CLIPS.search if _face_target != Vector3.INF else CLIPS.idle, 0.3)
	_stride += real_speed * delta
	if _stride > (1.9 if real_speed > 3.0 else 1.2):
		_stride = 0.0
		Sfx.play_at("step_heavy", global_position, -2.0 if real_speed > 3.0 else -8.0)


## Stuck against something for a second: ask for a fresh path.
func _unstick(delta: float) -> void:
	if not moving or agent.is_navigation_finished() or blocked_by:
		_stuck = 0.0
		return
	_stuck += delta
	if _stuck > 1.0:
		if global_position.distance_to(_last) < 0.3:
			var target := agent.target_position
			agent.target_position = global_position
			agent.target_position = target
		_last = global_position
		_stuck = 0.0
