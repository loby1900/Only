class_name Outfit
extends RefCounted
## Procedural clothes for the realistic rigged body (quaternius-characters). The body only wears
## a dark base layer, so the neighbour is dressed here, at load time, from a `look` Dictionary:
##
##   var body: Node3D = load(Outfit.BODY % "male").instantiate()
##   add_child(body)
##   Outfit.dress(body, Outfit.preset("neighbor"))
##
## Painting: OutfitMesh bakes clothing coordinates into the body mesh (COLOR = region weights,
## UV2 = arm/leg position) and shaders/person.gdshader paints shirt, trousers, shoes and skin.
## Shells: jackets / trousers / shoes are body triangles pushed out along the normals, skinned to
## the same Skeleton3D so they follow every animation. Plus hair, beard and glasses.
## Add a look: one more `match` branch in preset() (keys: see _look()).

const BODY := "res://assets/quaternius-characters/base-characters/superhero_%s_fullbody.gltf"
const HAIR := "res://assets/quaternius-characters/hairstyles/%s.gltf"
const PERSON_SHADER := preload("res://shaders/person.gdshader")
const CLOTH_SHADER := preload("res://shaders/cloth.gdshader")

enum Pattern { PLAIN, STRIPES, PLAID, STAINS, DENIM, KNIT }

const SKIN_TONES: Array[Color] = [Color(1, 1, 1), Color(0.95, 0.86, 0.78), Color(0.82, 0.66, 0.54),
	Color(0.64, 0.48, 0.37), Color(0.47, 0.34, 0.26), Color(0.36, 0.26, 0.2)]

static var _hair := {}             # hairstyle id -> PackedScene


## Named looks. "neighbor": tall, grey-haired, bearded, glasses, stained shirt under a worn
## olive work jacket — ordinary enough to be unsettling.
static func preset(name: String) -> Dictionary:
	match name:
		"neighbor":
			return _look({ "skin": SKIN_TONES[2].lerp(SKIN_TONES[1], 0.5), "hair": "hair_simpleparted",
				"hair_color": Color("6e6a64"), "beard": true, "glasses": true,
				"top": Color("b9ae93"), "top_pattern": Pattern.STAINS, "sleeves": 2,
				"jacket": "open_jacket", "jacket_color": Color("4a4a34"),
				"bottom": Color("3a3029"), "bottom_pattern": Pattern.PLAIN, "shoes": Color("1f1a16"),
				"height": 1.07 })
		"pale":   # a monster-ish variant: grey skin, torn dark clothes
			return _look({ "skin": Color(0.62, 0.66, 0.62), "hair": "", "top": Color("2c2a2a"),
				"top_pattern": Pattern.STAINS, "sleeves": 1, "bottom": Color("262626"),
				"bottom_pattern": Pattern.STAINS, "shoes": Color("141414"), "height": 1.12 })
	return _look({})


## Fills defaults so every key exists.
static func _look(values: Dictionary) -> Dictionary:
	var look := {
		"female": false, "skin": SKIN_TONES[1], "hair": "", "hair_color": Color("4a2f1e"), "beard": false,
		"top": Color("8a8150"), "top_pattern": Pattern.PLAIN, "sleeves": 1, "jacket": "", "jacket_color": Color("2e3440"),
		"bottom": Color("2b3a67"), "bottom_pattern": Pattern.PLAIN, "shoes": Color("1f1f24"),
		"glasses": false, "height": 1.0,
	}
	look.merge(values, true)
	return look


## Dresses an instantiated body scene (Outfit.BODY) in place.
static func dress(body_root: Node3D, look: Dictionary) -> void:
	var gender := "female" if look.female else "male"
	var skeleton: Skeleton3D = body_root.find_child("Skeleton3D", true, false)
	var data := OutfitMesh.body(gender, body_root)
	for mesh_node: MeshInstance3D in body_root.find_children("*", "MeshInstance3D", true, false):
		if mesh_node.name.to_lower().begins_with("superhero"):
			mesh_node.mesh = data.mesh
			mesh_node.material_override = _person_material(data, look)
		else:
			mesh_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var jacket: String = look.jacket
	if jacket not in ["hoodie", "jacket", "coat"]:
		_add_shell(skeleton, data, gender, "top_%d" % clampi(int(look.sleeves), 0, 2), _cloth(look.top, look.top_pattern, 0.86))
	_add_shell(skeleton, data, gender, "trousers", _cloth(look.bottom, look.bottom_pattern, 0.88))
	_add_shell(skeleton, data, gender, "shoes", _cloth(look.shoes, Pattern.PLAIN, 0.45))
	if jacket != "":
		_add_shell(skeleton, data, gender, jacket, _cloth(look.jacket_color, Pattern.PLAIN, 0.8))
	if look.hair != "":
		_add_hair(skeleton, look.hair, look.hair_color)
	if look.beard:
		_add_hair(skeleton, "hair_beard", look.hair_color)
	if look.glasses:
		_add_glasses(skeleton)


static func _person_material(data: Dictionary, look: Dictionary) -> ShaderMaterial:
	var material := ShaderMaterial.new()
	material.shader = PERSON_SHADER
	material.set_shader_parameter("skin_texture", data.albedo)
	material.set_shader_parameter("normal_texture", data.normal)
	material.set_shader_parameter("roughness_texture", data.roughness)
	material.set_shader_parameter("skin_tint", look.skin)
	material.set_shader_parameter("top_color", look.top)
	material.set_shader_parameter("top_pattern", look.top_pattern)
	material.set_shader_parameter("bottom_color", look.bottom)
	material.set_shader_parameter("bottom_pattern", look.bottom_pattern)
	material.set_shader_parameter("shoe_color", look.shoes)
	# Sleeve end along the arm: 0 sleeveless, 0.3 t-shirt, 1 to the wrist.
	material.set_shader_parameter("sleeve_end", [0.02, 0.32, 1.02][clampi(int(look.sleeves), 0, 2)])
	material.set_shader_parameter("leg_start", 0.02)
	return material


## A garment material for shells and small props.
static func _cloth(color: Color, pattern: int, roughness: float) -> ShaderMaterial:
	var material := ShaderMaterial.new()
	material.shader = CLOTH_SHADER
	material.set_shader_parameter("color", color)
	material.set_shader_parameter("pattern", pattern)
	material.set_shader_parameter("roughness", roughness)
	return material


## Hairstyles are skinned to the same skeleton: move their mesh onto this body's Skeleton3D.
static func _add_hair(skeleton: Skeleton3D, id: String, color: Color) -> void:
	if not _hair.has(id):
		_hair[id] = load(HAIR % id)
	var scene: Node3D = (_hair[id] as PackedScene).instantiate()
	for mesh_node: MeshInstance3D in scene.find_children("*", "MeshInstance3D", true, false):
		mesh_node.get_parent().remove_child(mesh_node)
		mesh_node.owner = null
		skeleton.add_child(mesh_node)
		mesh_node.skeleton = NodePath("..")
		var material := mesh_node.mesh.surface_get_material(0)
		if material is BaseMaterial3D:
			var tinted := (material as BaseMaterial3D).duplicate() as BaseMaterial3D
			tinted.albedo_color = color.lightened(0.12)   # hair textures are mid-brown
			mesh_node.material_override = tinted
	scene.free()


static func _add_shell(skeleton: Skeleton3D, data: Dictionary, gender: String, garment: String, material: Material) -> void:
	var node := MeshInstance3D.new()
	node.name = garment.capitalize().replace(" ", "")
	node.mesh = OutfitMesh.shell(gender, garment, data)
	node.skin = data.skin
	node.material_override = material
	skeleton.add_child(node)
	node.skeleton = NodePath("..")


static func _add_glasses(skeleton: Skeleton3D) -> void:
	var head := BoneAttachment3D.new()
	head.bone_name = "Head"
	skeleton.add_child(head)
	var lens := StandardMaterial3D.new()
	lens.albedo_color = Color("15181c")
	lens.metallic = 0.5
	lens.roughness = 0.12
	var parts := [[Vector3(0.045, 0.03, 0.008), Vector3(-0.032, 0.098, 0.105)],
		[Vector3(0.045, 0.03, 0.008), Vector3(0.032, 0.098, 0.105)],
		[Vector3(0.13, 0.006, 0.006), Vector3(0, 0.106, 0.104)]]
	var rest := skeleton.get_bone_global_rest(skeleton.find_bone("Head"))
	for part: Array in parts:
		var glass := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = part[0]
		box.material = lens
		glass.mesh = box
		head.add_child(glass)
		# Offset from the head bone in body space (x right, y up, z forward), whatever its axes.
		glass.transform = rest.affine_inverse() * Transform3D(Basis.IDENTITY, rest.origin + part[1])
