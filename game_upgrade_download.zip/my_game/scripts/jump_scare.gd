class_name JumpScare
extends Node
## Being caught: the camera snaps to the neighbour's face, he grabs, a flash, a low boom and a
## shake (short and bloodless — store friendly). After Config.CAUGHT_TIME you lose a life and
## wake at the last checkpoint while he patrols from the far side of the house; with no lives
## left the game emits game_over.

var game: HorrorGame
var active := false
var _time := 0.0


func begin() -> void:
	if not game.running or active:
		return
	game.interaction.unhide()
	var player := game.player
	player.active = false
	player.auto_input = Vector2.ZERO
	active = true
	_time = 0.0
	var rig := game.rig
	var to := game.neighbor.eye() - rig.camera.global_position
	rig.yaw = atan2(-to.x, -to.z)
	rig.pitch = clampf(asin(to.normalized().y), -0.5, 0.5)
	game.neighbor.gesture("grab", Config.CAUGHT_TIME)
	Sfx.play("scare", 4.0)
	Sfx.play("hit", 0.0)
	Fx.shake(game, 0.9)
	Fx.vibrate(300)
	game.hud.scare()


func cancel() -> void:
	active = false


func _physics_process(delta: float) -> void:
	if not active:
		return
	_time += delta
	if _time < Config.CAUGHT_TIME:
		return
	active = false
	game.lives -= 1
	game.hud.set_lives(game.lives)
	if game.lives <= 0:
		game.running = false
		game.game_over.emit()
		return
	var checkpoint := game.objectives.checkpoint
	game.place_player(checkpoint, game.objectives.checkpoint_yaw)
	var far := game.house.neighbor_start
	for point in game.house.patrol:
		if point.distance_to(checkpoint) > far.distance_to(checkpoint):
			far = point
	game.brain.reset(far, Config.RESPAWN_GRACE)
	game.player.active = true
	game.hud.toast(Hud.TEXT.caught % game.lives, Config.CORAL)
	Sfx.music("calm", 1.5)
