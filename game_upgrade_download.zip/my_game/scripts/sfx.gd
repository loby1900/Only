extends Node
## Autoload "Sfx": one-shot sounds by name — Sfx.play("pickup"), positional Sfx.play_at("slam",
## position) — and one looping music track with fades: Sfx.music("chase"), Sfx.stop_music().
## Streams are loaded by path at runtime, not preload(): autoloads compile before a fresh
## project's first import, when preload() of an .ogg would fail. Add a sound = one line below.

const SOUNDS := {
	"click": "res://assets/interface-sounds/click_001.ogg",
	"open": "res://assets/interface-sounds/confirmation_002.ogg",
	"step": ["res://assets/impact-sounds/footstep_wood_000.ogg", "res://assets/impact-sounds/footstep_wood_001.ogg",
		"res://assets/impact-sounds/footstep_wood_002.ogg", "res://assets/impact-sounds/footstep_wood_003.ogg"],
	"step_grass": ["res://assets/impact-sounds/footstep_grass_000.ogg", "res://assets/impact-sounds/footstep_grass_001.ogg"],
	"step_heavy": ["res://assets/impact-sounds/footstep_concrete_000.ogg", "res://assets/impact-sounds/footstep_concrete_001.ogg",
		"res://assets/impact-sounds/footstep_concrete_002.ogg"],
	"door_open": "res://assets/rpg-audio/dooropen_1.ogg",
	"door_close": "res://assets/rpg-audio/doorclose_1.ogg",
	"slam": "res://assets/rpg-audio/doorclose_4.ogg",
	"bang": "res://assets/impact-sounds/impactwood_heavy_000.ogg",
	"locked": "res://assets/rpg-audio/metalclick.ogg",
	"unlock": "res://assets/rpg-audio/metallatch.ogg",
	"pickup": "res://assets/rpg-audio/handlesmallleather.ogg",
	"creak": "res://assets/rpg-audio/creak1.ogg",
	"hide": "res://assets/rpg-audio/cloth1.ogg",
	"bottles": "res://assets/impact-sounds/impactglass_heavy_000.ogg",
	"fuse": "res://assets/sci-fi-sounds/forcefield_000.ogg",
	"heart": "res://assets/impact-sounds/impactsoft_heavy_000.ogg",
	"sting": "res://assets/digital-audio/lowthreetone.ogg",
	"scare": "res://assets/sci-fi-sounds/lowfrequency_explosion_000.ogg",
	"hit": "res://assets/impact-sounds/impactpunch_heavy_000.ogg",
	"level_done": "res://assets/music-loops/idents/serious_ident.ogg",
	"game_over": "res://assets/impact-sounds/impactbell_heavy_000.ogg",
}
## Looping tracks: title theme, the quiet house drone, the chase.
const MUSIC := {
	"theme": "res://assets/music-loops/loops/sad_descent.ogg",
	"calm": "res://assets/sci-fi-sounds/spaceenginelow_000.ogg",
	"chase": "res://assets/music-loops/loops/drumming_sticks.ogg",
}
const MUSIC_DB := -10.0
const VOICES := 10
const VOICES_3D := 6

var _players: Array[AudioStreamPlayer] = []
var _players_3d: Array[AudioStreamPlayer3D] = []
var _next := 0
var _next_3d := 0
var _cache := {}
var _music: AudioStreamPlayer
var _music_name := ""
var _fade: Tween


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in VOICES:
		var player := AudioStreamPlayer.new()
		add_child(player)
		_players.append(player)
	for i in VOICES_3D:
		var player := AudioStreamPlayer3D.new()
		player.unit_size = 8.0
		player.max_distance = 60.0
		add_child(player)
		_players_3d.append(player)
	_music = AudioStreamPlayer.new()
	add_child(_music)


func play(sound: String, volume_db := 0.0, pitch_jitter := 0.06, pitch := 1.0) -> void:
	var stream := _stream(sound, SOUNDS)
	if stream == null or not GameState.settings.sound:
		return
	var player := _players[_next]
	_next = (_next + 1) % VOICES
	player.stream = stream
	player.volume_db = volume_db
	player.pitch_scale = pitch + randf_range(-pitch_jitter, pitch_jitter)
	player.play()


## A sound heard from a place in the 3D world (quieter far from the camera).
func play_at(sound: String, position: Vector3, volume_db := 0.0) -> void:
	var stream := _stream(sound, SOUNDS)
	if stream == null or not GameState.settings.sound:
		return
	var player := _players_3d[_next_3d]
	_next_3d = (_next_3d + 1) % VOICES_3D
	player.stream = stream
	player.volume_db = volume_db
	player.pitch_scale = 1.0 + randf_range(-0.06, 0.06)
	player.global_position = position
	player.play()


## Starts (or cross-fades to) a looping music track. Respects the music setting.
func music(track: String, fade := 1.0) -> void:
	_music_name = track
	if not GameState.settings.music:
		return
	var stream := _stream(track, MUSIC)
	if stream == null:
		return
	if _music.playing and _music.stream == stream:
		_fade_to(MUSIC_DB, fade)
		return
	if stream is AudioStreamOggVorbis:
		(stream as AudioStreamOggVorbis).loop = true
	_music.stream = stream
	_music.volume_db = -40.0
	_music.play()
	_fade_to(MUSIC_DB, fade)


func stop_music(fade := 0.8) -> void:
	_music_name = ""
	if _music.playing:
		_fade_to(-40.0, fade, true)


## Re-applies the sound / music settings (called by GameState.set_setting).
func refresh() -> void:
	if not GameState.settings.music:
		var track := _music_name
		_music.stop()
		_music_name = track
	elif _music_name != "" and not _music.playing:
		music(_music_name, 0.5)


func _fade_to(volume: float, time: float, stop_after := false) -> void:
	if _fade:
		_fade.kill()
	_fade = create_tween()
	_fade.tween_property(_music, "volume_db", volume, maxf(time, 0.01))
	if stop_after:
		_fade.tween_callback(_music.stop)


## A sound entry is a path or an Array of variant paths (one is picked at random).
func _stream(sound: String, table: Dictionary) -> AudioStream:
	if not table.has(sound):
		push_warning("Unknown sound: %s" % sound)
		return null
	var entry: Variant = table[sound]
	var path: String = entry[randi() % entry.size()] if entry is Array else entry
	if not _cache.has(path):
		_cache[path] = load(path)
	return _cache[path]
