extends Node
## Test run, only with `-- --probe` (see GameState / main.gd), never in play. For every level:
## builds it, checks the navmesh reaches every room, the cellar and the secret, then an
## autopilot walks the level's objective chain (take items, open doors, fuse, secret) through
## the real interact button until the level completes. Then AI scenarios (ProbeAI): a noise
## makes the neighbour SUSPICIOUS and he reaches the spot; a lit player in view → CHASE;
## hiding unseen → SEARCH → PATROL; seen hiding → dragged out; a stationary player is caught
## (a life lost, back at the checkpoint). Prints PROBE ok / FAIL lines and PROBE_DONE.
## `-- --probe --shot-dir=DIR` (windowed) also saves screenshots (`--shots-only` skips the checks).

var main: Main
var game: HorrorGame
var failures := 0
var shot_dir := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--shot-dir="):
			shot_dir = arg.substr(11)
	_run.call_deferred()


func check(ok: bool, what: String) -> void:
	print("PROBE %s %s" % ["ok  " if ok else "FAIL", what])
	if not ok:
		failures += 1


func frames(count: int) -> void:
	for i in count:
		await get_tree().physics_frame


func shot(name: String) -> void:
	if shot_dir == "" or DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("%s/%s.png" % [shot_dir, name])
	print("PROBE shot %s" % name)


func _run() -> void:
	await frames(10)
	game = main.game as HorrorGame
	var windowed := shot_dir != "" and DisplayServer.get_name() != "headless"
	if windowed:
		await get_tree().create_timer(1.5).timeout
		await shot("01_title")
	Engine.time_scale = 1.0 if OS.get_cmdline_user_args().has("--real-time") else 3.0
	var walker := ProbeWalk.new(self)
	var checks := not OS.get_cmdline_user_args().has("--shots-only")
	for i in (Levels.LIST.size() if checks else 0):
		await walker.start_level(i)
		var level: Dictionary = Levels.LIST[i]
		check(game.running and game.house.doors.size() > 0, "level %d %s builds (%d doors, %d things, %d lamps)" % [i + 1, level.name, game.house.doors.size(), game.house.things.size(), game.house.lamps.size()])
		walker.check_navmesh()
		game.brain.enabled = false
		var won := await walker.play_steps(level)
		check(won, "level %d: autopilot completes %d objectives and finds the secret" % [i + 1, level.steps.size()])
		await frames(3)
	if checks:
		await ProbeAI.new(self).run()
	if windowed:
		Engine.time_scale = 1.0
		await ProbeShots.new(self).run()
	Engine.time_scale = 1.0
	print("PROBE_DONE failures=%d" % failures)
	get_tree().quit()
