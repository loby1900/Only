class_name Main
extends Node3D
## Game flow: TITLE → PLAYING ⇄ PAUSED → GAME_OVER (Retry / Home) or LEVEL_DONE → next level.
## Restarts never reload the scene; losing app focus pauses a running game.
##
## Contract with the game node ($Game, scenes/game.tscn — the part you replace):
##   func start(level: int)       build / reset level `level` (0-based) and place the player
##   func stop()                  freeze and clean up (title, pause-free menus, game over)
##   signal score_changed(value: int)
##   signal game_over()
##   signal level_done()
##   optional: signal status_changed(text: String)  → HUD line under the score
##   optional vars it receives before start(): player (Player), rig (CameraRig), hud (Hud)
##   optional func title_scene()  → dress the backdrop behind the title screen
##   optional func command(name)  → HUD commands main does not know
## Main owns the shell nodes: Player, CameraRig, HUD, the sky/light (WorldLook — the game may
## rebuild it per level). Test hook: `-- --probe` adds scripts/probe.gd (never in normal play).

enum State { TITLE, PLAYING, PAUSED, GAME_OVER, LEVEL_DONE }

const GAME_OVER_DELAY := 0.9         # let the final hit read before the card appears

var state := State.TITLE
var _next_level_in := 0.0
var _card_shown := false

@onready var game: Node = $Game
@onready var player: Player = $Player
@onready var rig: CameraRig = $CameraRig
@onready var hud: Hud = $HUD


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for node: Node in [game, player, rig]:
		node.process_mode = Node.PROCESS_MODE_PAUSABLE
	WorldLook.build(self)
	if OS.has_feature("mobile"):
		DisplayServer.screen_set_orientation(DisplayServer.SCREEN_SENSOR_PORTRAIT if Config.PORTRAIT else DisplayServer.SCREEN_SENSOR_LANDSCAPE)
	get_window().size_changed.connect(_fit_orientation)
	_fit_orientation()
	hud.touch.set_rig(rig)
	hud.command.connect(_on_command)
	for key in ["player", "rig", "hud"]:
		if key in game:
			game.set(key, get(key))
	game.score_changed.connect(GameState.set_score)
	game.game_over.connect(_on_game_over)
	game.level_done.connect(_on_level_done)
	if game.has_signal("status_changed"):
		game.status_changed.connect(hud.set_status)
	_go_title()
	if GameState.probe:
		var probe: Node = load("res://scripts/probe.gd").new()
		probe.set("main", self)
		add_child(probe)


func _on_command(name: String) -> void:
	if name == "help" or name == "back":
		return
	match name:
		"play":
			GameState.new_game()
			_start(true)
		"continue":
			_start(true)
		"restart":
			_start(true)
		"resume":
			_set_paused(false)
		"pause":
			_set_paused(true)
		"home":
			GameState.playing = false
			GameState.save_now()
			_go_title()
		_:
			if game.has_method("command"):
				game.command(name)


func _go_title() -> void:
	state = State.TITLE
	get_tree().paused = false
	GameState.playing = false
	player.active = false
	game.stop()
	if game.has_method("title_scene"):
		game.title_scene()
	rig.title_spin = true
	hud.show_title()
	Sfx.music("theme")


## Starts GameState.level. `fresh` = a new run (score back to 0); false = the next level.
func _start(fresh: bool) -> void:
	get_tree().paused = false
	if fresh:
		GameState.start_run()
		Sfx.play("open", -4.0)
	GameState.playing = true
	state = State.PLAYING
	rig.title_spin = false
	hud.show_playing()
	game.start(GameState.level)
	player.active = true


func _set_paused(on: bool) -> void:
	if on and state == State.PLAYING:
		state = State.PAUSED
		get_tree().paused = true
		hud.show_pause()
		GameState.save_now()
	elif not on and state == State.PAUSED:
		state = State.PLAYING
		get_tree().paused = false
		hud.show_playing()


func _on_game_over() -> void:
	if state != State.PLAYING:
		return
	state = State.GAME_OVER
	_card_shown = false
	player.active = false
	var record := GameState.finish_run()
	Sfx.play("game_over")
	Fx.vibrate(120)
	hud.touch.set_active(false)
	get_tree().create_timer(GAME_OVER_DELAY).timeout.connect(func() -> void:
		if state == State.GAME_OVER:
			_card_shown = true
			game.stop()
			hud.show_game_over(GameState.score, GameState.best, record))


func _on_level_done() -> void:
	if state != State.PLAYING:
		return
	state = State.LEVEL_DONE
	player.active = false
	GameState.complete_level()
	Sfx.play("level_done")
	hud.show_level_done()
	_next_level_in = Config.LEVEL_DONE_DELAY


func _process(delta: float) -> void:
	# Keyboard / gamepad: jump starts from the title and retries from the game-over card.
	if Input.is_action_just_pressed("jump"):
		if state == State.TITLE:
			_on_command("continue" if GameState.has_save() else "play")
		elif state == State.GAME_OVER and _card_shown:
			_on_command("restart")
	if state == State.LEVEL_DONE and not get_tree().paused:
		_next_level_in -= delta
		if _next_level_in <= 0.0:
			game.stop()
			_start(false)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		_set_paused(state == State.PLAYING)


func _notification(what: int) -> void:
	if (what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED) and not GameState.probe:
		_set_paused(true)


## Same UI size held upright or sideways: the base resolution follows the window's shape.
func _fit_orientation() -> void:
	var window := get_window()
	var wanted := Vector2i(1280, 720) if window.size.x >= window.size.y else Vector2i(720, 1280)
	if window.content_scale_size != wanted:
		window.content_scale_size = wanted
