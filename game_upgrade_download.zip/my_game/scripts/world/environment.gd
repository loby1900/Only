class_name WorldLook
extends RefCounted
## Builds the sky, the key light (sun or moon) and colour grading of the 3D world in one call:
##   WorldLook.build(self)            # Config.LOOK
##   WorldLook.build(self, "night")   # deep blue sky, cool moonlight, fog — dark but readable
## Variants: "day", "dusk" (late evening, low orange sun), "night". Filmic tonemap with white 6.0
## keeps lit colours rich. Call it again with another variant to switch (old nodes replaced).
## Night is never black: the ambient colour keeps every room readable, lamps add warm pools.

const LOOKS := {
	"day": {
		"sky_top": Color(0.18, 0.61, 0.94), "sky_horizon": Color(0.66, 0.86, 1.0),
		"ground_bottom": Color(0.48, 0.55, 0.64), "ambient": Color(0.75, 0.89, 1.0), "ambient_energy": 0.45,
		"sun": Color(1.0, 0.95, 0.86), "sun_energy": 1.25, "sun_pitch": -50.0, "sun_yaw": 35.0,
		"fog": 0.004, "exposure": 1.1,
	},
	"dusk": {
		"sky_top": Color(0.1, 0.13, 0.3), "sky_horizon": Color(0.62, 0.36, 0.33),
		"ground_bottom": Color(0.1, 0.1, 0.16), "ambient": Color(0.5, 0.52, 0.8), "ambient_energy": 0.42,
		"sun": Color(1.0, 0.6, 0.4), "sun_energy": 0.9, "sun_pitch": -14.0, "sun_yaw": -70.0,
		"fog": 0.025, "exposure": 1.15,
	},
	"night": {
		"sky_top": Color(0.04, 0.06, 0.15), "sky_horizon": Color(0.14, 0.18, 0.32),
		"ground_bottom": Color(0.04, 0.05, 0.09), "ambient": Color(0.42, 0.5, 0.82), "ambient_energy": 0.36,
		"sun": Config.MOON_LIGHT, "sun_energy": 0.7, "sun_pitch": -36.0, "sun_yaw": 30.0,
		"fog": Config.FOG_DENSITY, "exposure": 1.25,
	},
}


static func build(parent: Node, variant: String = Config.LOOK) -> WorldEnvironment:
	var look: Dictionary = LOOKS.get(variant, LOOKS.night)
	# Switching variants updates the existing nodes: replacing a Sky leaks its GPU textures in
	# the Compatibility renderer.
	var world := parent.get_node_or_null("WorldEnvironment") as WorldEnvironment
	if world == null:
		world = WorldEnvironment.new()
		world.name = "WorldEnvironment"
		var env := Environment.new()
		env.background_mode = Environment.BG_SKY
		env.sky = Sky.new()
		env.sky.sky_material = ProceduralSkyMaterial.new()
		env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
		env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
		env.tonemap_white = 6.0
		env.glow_enabled = false
		env.fog_enabled = true
		env.fog_sky_affect = 0.0
		world.environment = env
		parent.add_child(world)
	var environment := world.environment
	var sky_material := environment.sky.sky_material as ProceduralSkyMaterial
	sky_material.sky_top_color = look.sky_top
	sky_material.sky_horizon_color = look.sky_horizon
	sky_material.sky_curve = 0.12
	sky_material.ground_bottom_color = look.ground_bottom
	sky_material.ground_horizon_color = look.sky_horizon
	sky_material.sun_angle_max = 8.0
	environment.ambient_light_color = look.ambient
	environment.ambient_light_energy = look.ambient_energy
	environment.tonemap_exposure = look.exposure
	environment.fog_light_color = (look.sky_horizon as Color).lerp(look.sky_top, 0.4)
	environment.fog_density = look.fog

	var sun := parent.get_node_or_null("Sun") as DirectionalLight3D
	if sun == null:
		sun = DirectionalLight3D.new()
		sun.name = "Sun"
		sun.shadow_enabled = true
		sun.shadow_opacity = 0.85
		sun.shadow_blur = 1.5
		sun.directional_shadow_max_distance = 45.0
		parent.add_child(sun)
	sun.light_color = look.sun
	sun.light_energy = look.sun_energy
	sun.rotation_degrees = Vector3(look.sun_pitch, look.sun_yaw, 0.0)
	return world
