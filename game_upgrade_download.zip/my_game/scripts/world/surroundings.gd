class_name Surroundings
extends Node3D
## A dressed suburban street around the neighbour's plot. The house/tree assets are bundled
## Quaternius GLBs; smaller street details are purpose-built meshes so they stay lightweight on
## mobile. All set dressing is scenery only and deliberately sits outside the playable plot.
##
## EDITING THE LAYOUT: adjust the named offsets in `_build_street_dressing()` and the tree
## spacing below. These are rebuilt per level, while the core house layout remains in Levels.

const HOUSES := [
	"res://assets/city-kit-suburban/building-type-a.glb",
	"res://assets/city-kit-suburban/building-type-c.glb",
	"res://assets/city-kit-suburban/building-type-f.glb"
]
const TREE := "res://assets/city-kit-suburban/tree-large.glb"
const HOUSE_SCALE := 6.0

const ASPHALT := Color("#343943")
const CURB := Color("#777a7c")
const CONCRETE := Color("#8d8c84")
const METAL := Color("#303944")
const BIN_GREEN := Color("#344c42")
const WOOD_DARK := Color("#45352d")
const WINDOW_DARK := Color("#18212a")

func build(plan: Plan) -> void:
	for child in get_children():
		remove_child(child)
		child.queue_free()
	var half := Vector2(plan.w, plan.h) * Config.CELL * 0.5
	_plane(Vector3(0, -0.02, 0), Vector2(220, 220), Config.GRASS.darkened(0.25))
	var road_z := half.y + 5.0
	# Asphalt, two raised curbs and a worn pedestrian strip give the street a readable profile.
	_plane(Vector3(0, 0.005, road_z), Vector2(220, 7.0), ASPHALT)
	_plane(Vector3(0, 0.018, road_z - 3.55), Vector2(220, 0.22), CURB)
	_plane(Vector3(0, 0.018, road_z + 3.55), Vector2(220, 0.22), CURB)
	_plane(Vector3(0, 0.012, road_z - 4.25), Vector2(220, 1.25), CONCRETE)
	# Faded centre markings and a few asphalt repairs; small surface variation breaks up the plane.
	for i in 13:
		_plane(Vector3(-36.0 + i * 6.0, 0.022, road_z), Vector2(2.2, 0.075), Color("#c2b89b"))
	var rng := RandomNumberGenerator.new()
	rng.seed = plan.w * 731 + plan.h * 97
	for i in 11:
		var x := rng.randf_range(-42.0, 42.0)
		var z := road_z + rng.randf_range(-2.8, 2.8)
		var patch := _box(Vector3(rng.randf_range(0.35, 1.2), 0.012, rng.randf_range(0.12, 0.3)), Color("#292d34"), "RoadRepair")
		add_child(patch)
		patch.position = Vector3(x, 0.024, z)
		patch.rotation.y = rng.randf_range(-0.12, 0.12)

	# Houses across the street and at the edges; these are real included GLB assets, not hidden.
	var spots: Array = [
		[Vector3(-16, 0, road_z + 12), PI], [Vector3(2, 0, road_z + 12), PI],
		[Vector3(20, 0, road_z + 12), PI], [Vector3(-half.x - 9, 0, 0), PI * 0.5],
		[Vector3(half.x + 9, 0, -2), -PI * 0.5]
	]
	for i in spots.size():
		_house(HOUSES[i % HOUSES.size()], spots[i][0], spots[i][1], i < 2)

	for x in [-24.0, 12.0]:
		_street_lamp(Vector3(x, 0, road_z - 4.7))
	_build_street_dressing(half, road_z, rng)

	# Tree positions are deterministic per layout, so the neighbourhood feels consistent between
	# retries instead of moving around at every restart. Keep all trees outside the fenced plot.
	for i in 14:
		var angle := rng.randf() * TAU
		var p := Vector3(cos(angle) * (half.x + 5 + rng.randf() * 9), 0,
			sin(angle) * (half.y + 5 + rng.randf() * 7))
		if absf(p.z - road_z) < 6.0:
			p.z -= 8.0
		if absf(p.x) < half.x + 2.0 and absf(p.z) < half.y + 2.0:
			p.x = signf(p.x if not is_zero_approx(p.x) else 1.0) * (half.x + 4.5)
		var tree: Node3D = load(TREE).instantiate()
		tree.name = "NeighbourhoodTree_%02d" % i
		tree.scale = Vector3.ONE * rng.randf_range(5.5, 7.5)
		tree.rotation.y = rng.randf() * TAU
		add_child(tree)
		tree.position = p


func _build_street_dressing(half: Vector2, road_z: float, rng: RandomNumberGenerator) -> void:
	# The mailbox is a small landmark at the front edge of the property.
	_mailbox(Vector3(half.x - 2.2, 0, half.y + 1.55))
	# Two wheelie bins beside the fence, out of the route used by the player and the neighbour.
	_trash_bin(Vector3(half.x + 2.4, 0, half.y + 2.8), BIN_GREEN, 0.04)
	_trash_bin(Vector3(half.x + 3.15, 0, half.y + 3.05), Color("#424a54"), -0.08)
	# An abandoned car adds scale and a strong silhouette without adding physics or blocking play.
	_abandoned_car(Vector3(-7.5, 0, road_z + 0.4), -0.025)
	# Utility poles and sagging cable imply a lived-in street; the cable is split into segments to
	# approximate a shallow sag and avoid a single overly long, bright line.
	_utility_pole(Vector3(-31.0, 0, road_z + 0.4))
	_utility_pole(Vector3(31.0, 0, road_z + 0.4))
	for i in 7:
		var x := -31.0 + float(i) * (62.0 / 6.0)
		var t := absf(float(i) - 3.0) / 3.0
		var cable := _box(Vector3(62.0 / 6.0 + 0.08, 0.035, 0.035), Color("#20252d"), "PowerCable")
		add_child(cable)
		cable.position = Vector3(x + 31.0 / 6.0, 5.55 - (1.0 - t) * 0.6, road_z + 0.4)
	# A few irregular low shrubs along the side boundaries; never placed inside the house footprint.
	for i in 9:
		var side := -1.0 if i % 2 == 0 else 1.0
		var shrub := _shrub(rng.randf_range(0.45, 0.8))
		add_child(shrub)
		shrub.position = Vector3(side * (half.x + 4.0 + rng.randf_range(0.0, 2.0)), 0,
			rng.randf_range(-half.y - 1.0, half.y + 1.0))


func _plane(at: Vector3, size: Vector2, color: Color) -> void:
	var mesh := PlaneMesh.new()
	mesh.size = size
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.95
	mesh.material = material
	var node := MeshInstance3D.new()
	node.mesh = mesh
	node.position = at
	node.name = "GroundSurface"
	add_child(node)


func _house(path: String, at: Vector3, yaw: float, lit: bool) -> void:
	var model: Node3D = load(path).instantiate()
	model.name = "DistantHouse"
	model.scale = Vector3.ONE * HOUSE_SCALE
	model.rotation.y = yaw
	add_child(model)
	model.position = at
	if lit:
		var light := OmniLight3D.new()
		light.name = "PorchLight"
		light.light_color = Config.LAMP_LIGHT
		light.light_energy = 1.2
		light.omni_range = 6.5
		light.shadow_enabled = false
		add_child(light)
		light.position = at + Vector3(sin(yaw), 0, cos(yaw)) * 4.5 + Vector3.UP * 2.6


func _street_lamp(at: Vector3) -> void:
	var pole := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = 0.055
	cylinder.bottom_radius = 0.095
	cylinder.height = 4.5
	cylinder.material = _material(METAL, 0.65)
	pole.mesh = cylinder
	pole.name = "StreetLampPole"
	add_child(pole)
	pole.position = at + Vector3.UP * 2.25
	var arm := _box(Vector3(0.75, 0.07, 0.07), METAL, "StreetLampArm")
	add_child(arm)
	arm.position = at + Vector3(0.28, 4.28, 0)
	var head := _box(Vector3(0.48, 0.16, 0.32), Color("#e7c98b"), "StreetLampHead")
	var glow := head.mesh.material as StandardMaterial3D
	glow.emission_enabled = true
	glow.emission = Color(1.0, 0.68, 0.32)
	glow.emission_energy_multiplier = 2.0
	add_child(head)
	head.position = at + Vector3(0.52, 4.25, 0)
	var light := OmniLight3D.new()
	light.light_color = Color(1.0, 0.68, 0.38)
	light.light_energy = 1.6
	light.omni_range = 9.0
	light.shadow_enabled = false
	add_child(light)
	light.position = at + Vector3(0.45, 4.0, 0)


func _mailbox(at: Vector3) -> void:
	var post := _cylinder(0.055, 0.07, 1.0, WOOD_DARK, "MailboxPost")
	add_child(post)
	post.position = at + Vector3.UP * 0.5
	var body := _box(Vector3(0.42, 0.3, 0.26), Color("#4e5862"), "Mailbox")
	add_child(body)
	body.position = at + Vector3.UP * 1.08
	var lid := _box(Vector3(0.44, 0.055, 0.28), Color("#6c747a"), "MailboxLid")
	add_child(lid)
	lid.position = at + Vector3.UP * 1.25
	var flag := _box(Vector3(0.22, 0.035, 0.035), Config.CORAL, "MailboxFlag")
	add_child(flag)
	flag.position = at + Vector3(0.28, 1.08, 0)
	flag.rotation.z = -0.2


func _trash_bin(at: Vector3, tint: Color, yaw: float) -> void:
	var bin := _box(Vector3(0.55, 0.88, 0.58), tint, "WheelieBin")
	add_child(bin)
	bin.position = at + Vector3.UP * 0.46
	bin.rotation.y = yaw
	var lid := _box(Vector3(0.61, 0.09, 0.62), tint.darkened(0.25), "WheelieBinLid")
	add_child(lid)
	lid.position = at + Vector3.UP * 0.93
	lid.rotation.y = yaw
	for side in [-1.0, 1.0]:
		var wheel := _cylinder(0.09, 0.09, 0.07, Color("#171b20"), "BinWheel")
		wheel.rotation.z = PI * 0.5
		add_child(wheel)
		wheel.position = at + Vector3(0.28 * side, 0.14, -0.2)


func _utility_pole(at: Vector3) -> void:
	var pole := _cylinder(0.12, 0.18, 6.0, WOOD_DARK, "UtilityPole")
	add_child(pole)
	pole.position = at + Vector3.UP * 3.0
	var crossbar := _box(Vector3(1.25, 0.12, 0.14), WOOD_DARK, "UtilityCrossbar")
	add_child(crossbar)
	crossbar.position = at + Vector3.UP * 5.55
	for x in [-0.45, 0.0, 0.45]:
		var insulator := _cylinder(0.07, 0.07, 0.22, Color("#8c8c82"), "Insulator")
		add_child(insulator)
		insulator.position = at + Vector3(x, 5.72, 0)


func _abandoned_car(at: Vector3, yaw: float) -> void:
	var root := Node3D.new()
	root.name = "AbandonedCar"
	add_child(root)
	root.position = at + Vector3.UP * 0.05
	root.rotation.y = yaw
	var chassis := _box(Vector3(4.1, 0.62, 1.75), Color("#444b50"), "CarBody")
	root.add_child(chassis)
	chassis.position.y = 0.55
	var hood := _box(Vector3(1.05, 0.32, 1.68), Color("#535b60"), "CarHood")
	root.add_child(hood)
	hood.position = Vector3(-1.38, 0.88, 0)
	var trunk := _box(Vector3(0.8, 0.3, 1.65), Color("#353b41"), "CarTrunk")
	root.add_child(trunk)
	trunk.position = Vector3(1.52, 0.84, 0)
	var cabin := _box(Vector3(1.9, 0.72, 1.38), WINDOW_DARK, "CarCabin")
	root.add_child(cabin)
	cabin.position = Vector3(0.05, 1.17, 0)
	var roof := _box(Vector3(1.18, 0.11, 1.28), Color("#3c444b"), "CarRoof")
	root.add_child(roof)
	roof.position = Vector3(0.02, 1.56, 0)
	for x in [-1.35, 1.35]:
		for z in [-0.9, 0.9]:
			var wheel := _cylinder(0.34, 0.34, 0.16, Color("#171a1d"), "CarWheel")
			wheel.rotation.z = PI * 0.5
			root.add_child(wheel)
			wheel.position = Vector3(x, 0.35, z)
	for z in [-0.9, 0.9]:
		var lamp := _box(Vector3(0.12, 0.14, 0.045), Color("#d4bda0"), "CarHeadlight")
		root.add_child(lamp)
		lamp.position = Vector3(-2.08, 0.65, z * 0.72)
		var tail := _box(Vector3(0.08, 0.13, 0.045), Color("#6f2928"), "CarTailLight")
		root.add_child(tail)
		tail.position = Vector3(2.08, 0.64, z * 0.72)


func _shrub(scale_value: float) -> Node3D:
	var root := Node3D.new()
	root.name = "LowShrub"
	for i in 3:
		var leaf := MeshInstance3D.new()
		var sphere := SphereMesh.new()
		sphere.radius = 0.34 * scale_value
		sphere.height = 0.62 * scale_value
		sphere.material = _material(Color("#273d2b") if i != 1 else Color("#344b31"), 0.98)
		leaf.mesh = sphere
		root.add_child(leaf)
		leaf.position = Vector3((i - 1) * 0.28 * scale_value, 0.25 * scale_value, (i % 2) * 0.16 * scale_value)
	return root


func _box(size: Vector3, tint: Color, node_name: String) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh.material = _material(tint, 0.82)
	node.mesh = mesh
	node.name = node_name
	return node


func _cylinder(top: float, bottom: float, height: float, tint: Color, node_name: String) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = top
	mesh.bottom_radius = bottom
	mesh.height = height
	mesh.material = _material(tint, 0.85)
	node.mesh = mesh
	node.name = node_name
	return node


func _material(tint: Color, roughness: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = tint
	material.roughness = roughness
	return material
