class_name Tension
extends Node
## Fear feedback from the neighbour's distance and state: a heartbeat (lub-dub) that speeds up
## and grows louder as he gets close, a sting + chase music + red pulse when he spots you, the
## HUD's danger eye and vignette, and calm drone music again once he loses you.

var game: HorrorGame
var danger := 0.0                    # 0 calm .. 1 he is on you
var _beat := 0.0
var _second := -1.0


func watch(brain: NeighborBrain) -> void:
	if not brain.state_changed.is_connected(_on_state):
		brain.state_changed.connect(_on_state)


func reset() -> void:
	danger = 0.0
	_beat = 0.0
	_second = -1.0


func update(delta: float) -> void:
	var brain := game.brain
	var d := game.neighbor.global_position.distance_to(game.player.global_position)
	var near := clampf(1.0 - d / Config.HEARTBEAT_RANGE, 0.0, 1.0)
	var target := near * 0.8
	match brain.state:
		NeighborBrain.State.CHASE, NeighborBrain.State.CATCH:
			target = maxf(target, 0.85)
		NeighborBrain.State.SUSPICIOUS, NeighborBrain.State.SEARCH:
			target = maxf(target, 0.4)
	target = maxf(target, brain.alert * 0.7)
	danger = move_toward(danger, target, delta * 1.5)
	game.hud.set_danger(danger, brain.state, brain.alert)
	_heartbeat(delta)


func _heartbeat(delta: float) -> void:
	if _second >= 0.0:
		_second -= delta
		if _second < 0.0:
			Sfx.play("heart", lerpf(-22.0, -6.0, danger), 0.0, 0.5)
	if danger < 0.08:
		_beat = 0.3
		return
	_beat -= delta
	if _beat <= 0.0:
		_beat = lerpf(Config.HEARTBEAT_SLOW, Config.HEARTBEAT_FAST, danger)
		Sfx.play("heart", lerpf(-18.0, -2.0, danger), 0.0, 0.55)
		_second = 0.17
		if danger > 0.6:
			Fx.vibrate(15)


func _on_state(state: NeighborBrain.State) -> void:
	if not game.running:
		return
	if state == NeighborBrain.State.CHASE:
		Sfx.play("sting", 2.0)
		Sfx.music("chase", 0.4)
		game.hud.pulse(Config.CORAL)
		Fx.shake(game, 0.25)
	elif state == NeighborBrain.State.SUSPICIOUS:
		Sfx.play("creak", -6.0)
	elif state == NeighborBrain.State.PATROL:
		Sfx.music("calm", 2.5)
