class_name HorrorOverlay
extends Control
## Full-screen mood layer under the HUD: a vignette that darkens with danger, a red pulse when
## the neighbour spots you, the view from inside a wardrobe (slats) or under a bed (the frame
## above you), the jump-scare flash and a fade to black. Never blocks touches.

const VIGNETTE := """shader_type canvas_item;
void fragment() {
	vec2 d = (UV - 0.5) * vec2(1.25, 1.0);
	float edge = smoothstep(0.28, 0.78, length(d));
	COLOR = vec4(0.02, 0.03, 0.08, edge * 0.92);
}"""

var danger := 0.0
var hide_mode := -1                  # -1 none, 0 wardrobe slats, 1 under the bed
var _pulse := 0.0
var _pulse_color := Config.CORAL
var _flash := 0.0
var _vignette: ColorRect


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var shader := Shader.new()
	shader.code = VIGNETTE
	var material := ShaderMaterial.new()
	material.shader = shader
	_vignette = ColorRect.new()
	_vignette.material = material
	_vignette.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_vignette)


func pulse(color: Color) -> void:
	_pulse = 1.0
	_pulse_color = color


func scare() -> void:
	_flash = 1.0
	_pulse = 1.0
	_pulse_color = Config.CORAL


func _process(delta: float) -> void:
	_pulse = maxf(_pulse - delta * 1.2, 0.0)
	_flash = maxf(_flash - delta * 0.9, 0.0)
	# A slow breathing throb once he is close.
	var throb := 0.0
	if danger > 0.5:
		throb = (sin(Time.get_ticks_msec() * 0.008) * 0.5 + 0.5) * (danger - 0.5) * 0.25
	_vignette.modulate.a = clampf(0.55 + danger * 0.45 + throb, 0.0, 1.0)
	queue_redraw()


func _draw() -> void:
	var s := size
	if hide_mode == 0:
		# Wardrobe door slats: dark boards with thin gaps of room light between them.
		var boards := 9
		for i in boards + 1:
			var y := s.y * (float(i) / boards) - s.y * 0.04
			draw_rect(Rect2(0, y, s.x, s.y / boards * 0.4), Color(0.06, 0.045, 0.05, 0.78), true)
		draw_rect(Rect2(0, 0, s.x * 0.06, s.y), Color(0.04, 0.03, 0.04, 0.95), true)
		draw_rect(Rect2(s.x * 0.94, 0, s.x * 0.06, s.y), Color(0.04, 0.03, 0.04, 0.95), true)
	elif hide_mode == 1:
		draw_rect(Rect2(0, 0, s.x, s.y * 0.3), Color(0.05, 0.04, 0.05, 0.94), true)
		draw_rect(Rect2(0, s.y * 0.3, s.x, 10), Color(0.2, 0.14, 0.1, 0.9), true)
		draw_rect(Rect2(0, s.y * 0.9, s.x, s.y * 0.1), Color(0.05, 0.04, 0.05, 0.8), true)
	if _pulse > 0.0:
		draw_rect(Rect2(Vector2.ZERO, s), Color(_pulse_color, 0.28 * _pulse), true)
	if _flash > 0.0:
		var white := clampf((_flash - 0.8) * 5.0, 0.0, 1.0)
		draw_rect(Rect2(Vector2.ZERO, s), Color(1.0, 0.95, 0.9, 0.85 * white), true)
		draw_rect(Rect2(Vector2.ZERO, s), Color(0.0, 0.0, 0.0, clampf(0.9 - _flash, 0.0, 0.9) * float(_flash > 0.05)), true)
