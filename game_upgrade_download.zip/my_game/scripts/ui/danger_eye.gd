class_name DangerEye
extends Control
## The small eye at the top of the screen: shut and dim while the neighbour is unaware, half
## open and yellow while he is suspicious or searching, wide open and red during a chase. The
## iris ring fills with his "alert" (how sure he is that he saw you).

var danger := 0.0
var state := NeighborBrain.State.PATROL
var alert := 0.0
var _open := 0.0


func _ready() -> void:
	custom_minimum_size = Vector2(110, 60)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func show_state(new_danger: float, new_state: NeighborBrain.State, new_alert: float) -> void:
	danger = new_danger
	state = new_state
	alert = new_alert


func _process(delta: float) -> void:
	var target := 0.12
	match state:
		NeighborBrain.State.CHASE, NeighborBrain.State.CATCH:
			target = 1.0
		NeighborBrain.State.SUSPICIOUS, NeighborBrain.State.SEARCH:
			target = 0.6
	target = maxf(target, alert * 0.8)
	_open = move_toward(_open, target, delta * 3.0)
	queue_redraw()


func _draw() -> void:
	var c := size * 0.5
	var w := size.x * 0.46
	var h := size.y * 0.42 * maxf(_open, 0.08)
	var color := Config.CREAM.lerp(Config.SUNNY, clampf(_open * 1.6, 0.0, 1.0))
	if state == NeighborBrain.State.CHASE or state == NeighborBrain.State.CATCH:
		color = Config.CORAL
	var alpha := 0.45 + 0.55 * clampf(_open + danger * 0.3, 0.0, 1.0)
	var lid := PackedVector2Array()
	for i in 33:
		var t := float(i) / 32.0
		var x := lerpf(-w, w, t)
		lid.append(c + Vector2(x, -h * (1.0 - pow(2.0 * t - 1.0, 2.0))))
	for i in range(31, 0, -1):
		var t := float(i) / 32.0
		var x := lerpf(-w, w, t)
		lid.append(c + Vector2(x, h * (1.0 - pow(2.0 * t - 1.0, 2.0))))
	draw_colored_polygon(lid, Color(Config.INK, 0.75 * alpha))
	draw_polyline(lid + PackedVector2Array([lid[0]]), Color(color, alpha), 3.0, true)
	if _open > 0.2:
		var r := minf(h * 0.8, size.y * 0.3)
		draw_circle(c, r, Color(color, alpha), true, -1.0, true)
		draw_circle(c, r * 0.45, Color(Config.INK, alpha), true, -1.0, true)
		if alert > 0.02 and alert < 0.999:
			draw_arc(c, r + 5.0, -PI * 0.5, -PI * 0.5 + TAU * alert, 32, Color(Config.SUNNY, alpha), 3.0, true)
