class_name InventoryBar
extends Control
## Bottom-centre strip: the carried items in Inventory.SLOTS rounded slots (icon tinted with the
## item colour, the fuse drawn by hand) and a thin stamina bar above them that only shows while
## stamina is not full (red while sprinting on an empty tank).

const SLOT := 64.0
const GAP := 10.0

var items: Array[String] = []
var stamina := 100.0
var sprinting := false
var _icons := {}
var _shown := 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(Inventory.SLOTS * (SLOT + GAP) - GAP, SLOT + 26.0)


func set_items(list: Array[String]) -> void:
	items = list.duplicate()
	queue_redraw()


func set_stamina(value: float, running: bool) -> void:
	stamina = value
	sprinting = running


func _process(delta: float) -> void:
	_shown = move_toward(_shown, 1.0 if stamina < 99.5 else 0.0, delta * 3.0)
	queue_redraw()


func _draw() -> void:
	var width := size.x
	if _shown > 0.01:
		var bar := Rect2(Vector2(0, 2), Vector2(width, 10))
		draw_rect(bar, Color(Config.INK, 0.6 * _shown), true)
		var fill := bar
		fill.size.x = width * stamina / 100.0
		var color := Config.MINT if stamina > Config.STAMINA_MIN else Config.CORAL
		draw_rect(fill, Color(color, 0.9 * _shown), true)
	for i in Inventory.SLOTS:
		var rect := Rect2(Vector2(i * (SLOT + GAP), 22), Vector2(SLOT, SLOT))
		var style := StyleBoxFlat.new()
		style.bg_color = Color(Config.INK, 0.55)
		style.set_corner_radius_all(14)
		style.border_color = Color(Config.CREAM, 0.25)
		style.set_border_width_all(2)
		draw_style_box(style, rect)
		if i < items.size():
			_draw_item(items[i], rect)


func _draw_item(id: String, rect: Rect2) -> void:
	var info := Inventory.info(id)
	var color: Color = info.color
	var icon_path: String = info.icon
	var inner := rect.grow(-12)
	if icon_path != "":
		if not _icons.has(icon_path):
			_icons[icon_path] = load(icon_path)
		draw_texture_rect(_icons[icon_path], inner, false, color.lightened(0.15))
		return
	# The fuse: a glass cartridge with metal caps.
	var c := inner.get_center()
	draw_rect(Rect2(c - Vector2(16, 9), Vector2(32, 18)), color, true)
	for x in [-22.0, 16.0]:
		draw_rect(Rect2(c + Vector2(x, -11), Vector2(6, 22)), Color("#c0c4c8"), true)
