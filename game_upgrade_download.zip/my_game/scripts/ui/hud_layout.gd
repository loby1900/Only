class_name HudLayout
extends RefCounted
## Builds the in-game HUD widgets for Hud and hands them over with hud.adopt(). Returns the
## node that holds them all (hidden on menus). Layout (landscape): objective top-left, danger
## eye top-centre, lives + pause top-right, crosshair dot + prompt centre, toast under it,
## inventory + stamina bottom-centre (between the stick and the buttons).


static func build(hud: Hud, safe: MarginContainer) -> Control:
	var layer := Control.new()
	layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	safe.add_child(layer)
	var left := VBoxContainer.new()
	left.mouse_filter = Control.MOUSE_FILTER_IGNORE
	left.add_theme_constant_override("separation", 0)
	layer.add_child(left)
	left.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	left.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	left.custom_minimum_size.x = 430
	var night := _label(24, Config.SUNNY)
	night.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	left.add_child(night)
	var objective := _label(28, Config.CREAM)
	objective.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	objective.custom_minimum_size.x = 430
	objective.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	left.add_child(objective)
	var eye := DangerEye.new()
	layer.add_child(eye)
	eye.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	eye.offset_left = -55
	eye.offset_right = 55
	eye.offset_bottom = 60
	var right := HBoxContainer.new()
	right.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right.add_theme_constant_override("separation", 16)
	layer.add_child(right)
	right.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	right.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	var lives := _label(34, Config.CORAL)
	lives.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	right.add_child(lives)
	var pause := UiStyle.icon_button(Hud.ICON_PAUSE, Color(Config.INK, 0.7), 76)
	pause.pressed.connect(func() -> void:
		Sfx.play("click")
		hud.command.emit("pause"))
	right.add_child(pause)
	var dot := _Dot.new()
	layer.add_child(dot)
	dot.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	var prompt := _label(28, Config.SUNNY)
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	layer.add_child(prompt)
	prompt.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	prompt.offset_left = -300
	prompt.offset_right = 300
	prompt.offset_top = 34
	prompt.offset_bottom = 74
	var toast := _label(26, Config.CREAM)
	toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast.modulate.a = 0.0
	layer.add_child(toast)
	toast.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	toast.offset_left = -360
	toast.offset_right = 360
	toast.offset_top = -150
	toast.offset_bottom = -110
	var bar := InventoryBar.new()
	layer.add_child(bar)
	bar.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	var width := bar.custom_minimum_size.x
	bar.offset_left = -width * 0.5
	bar.offset_right = width * 0.5
	bar.offset_top = -bar.custom_minimum_size.y
	hud.adopt({"objective": objective, "night": night, "lives": lives, "prompt": prompt,
		"toast": toast, "dot": dot, "eye": eye, "bar": bar})
	return layer


static func _label(font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	return label


## The crosshair: a small dot, gold when something can be used.
class _Dot extends Control:
	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		draw_circle(Vector2.ZERO, 5.0, Color(Config.INK, 0.6), true, -1.0, true)
		draw_circle(Vector2.ZERO, 3.2, Color.WHITE, true, -1.0, true)
