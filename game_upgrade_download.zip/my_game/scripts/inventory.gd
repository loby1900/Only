class_name Inventory
extends RefCounted
## The items you carry (up to SLOTS) and the item catalogue: name, colour, HUD icon and the 3D
## model lying in the house. ADD AN ITEM: one ITEMS entry, then use its id in a level's
## "items" and "locks" (scripts/levels.gd). Keys are tinted copies of one model.

signal changed

const SLOTS := 4
const KEY_MODEL := "res://assets/platformer-kit/key.glb"
const ITEMS := {
	"key_red": {"name": "المفتاح الأحمر", "color": Color("#d9483b"), "icon": "res://assets/mobile-controls/icons/icon_key.png"},
	"key_blue": {"name": "المفتاح الأزرق", "color": Color("#3b7fd9"), "icon": "res://assets/mobile-controls/icons/icon_key.png"},
	"fuse": {"name": "فيوز كهرباء", "color": Color("#e8b33c"), "icon": ""},
	"crowbar": {"name": "عتلة", "color": Color("#c43d2e"), "icon": "res://assets/mobile-controls/icons/icon_wrench.png"},
}

var items: Array[String] = []


func add(id: String) -> bool:
	if items.size() >= SLOTS or items.has(id):
		return false
	items.append(id)
	changed.emit()
	return true


func has(id: String) -> bool:
	return items.has(id)


func remove(id: String) -> void:
	items.erase(id)
	changed.emit()


func clear() -> void:
	items.clear()
	changed.emit()


static func info(id: String) -> Dictionary:
	return ITEMS.get(id, {"name": id, "color": Config.CREAM, "icon": ""})


## The item as it lies in the house: key model, a fuse cartridge or a crowbar, plus a small
## glow so it can be found in the dark.
static func model(id: String) -> Node3D:
	var root := Node3D.new()
	var color: Color = info(id).color
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = 0.55
	material.roughness = 0.35
	material.emission_enabled = true
	material.emission = color
	material.emission_energy_multiplier = 0.35
	if id.begins_with("key"):
		var key: Node3D = load(KEY_MODEL).instantiate()
		key.scale = Vector3.ONE * 1.5
		key.rotation.z = 0.3
		root.add_child(key)
		for mesh: MeshInstance3D in key.find_children("*", "MeshInstance3D", true, false):
			mesh.material_override = material
	elif id == "fuse":
		_part(root, CylinderMesh.new(), Vector3(0.09, 0.26, 0.09), Vector3(0, 0.13, 0), material, PI * 0.5)
		var cap := material.duplicate() as StandardMaterial3D
		cap.albedo_color = Color("#c0c4c8")
		for x in [-0.14, 0.14]:
			_part(root, CylinderMesh.new(), Vector3(0.1, 0.05, 0.1), Vector3(x, 0.13, 0), cap, PI * 0.5)
	else:
		_part(root, BoxMesh.new(), Vector3(0.7, 0.05, 0.05), Vector3(0, 0.1, 0), material, 0.0)
		_part(root, BoxMesh.new(), Vector3(0.16, 0.05, 0.05), Vector3(0.38, 0.14, 0), material, 0.9)
	var glow := OmniLight3D.new()
	glow.light_color = color.lerp(Color.WHITE, 0.4)
	glow.light_energy = 0.9
	glow.omni_range = 1.6
	glow.position = Vector3(0, 0.4, 0)
	root.add_child(glow)
	return root


static func _part(root: Node3D, mesh: PrimitiveMesh, size: Vector3, at: Vector3, material: Material, roll: float) -> void:
	var node := MeshInstance3D.new()
	if mesh is BoxMesh:
		(mesh as BoxMesh).size = size
	elif mesh is CylinderMesh:
		(mesh as CylinderMesh).top_radius = size.x * 0.5
		(mesh as CylinderMesh).bottom_radius = size.x * 0.5
		(mesh as CylinderMesh).height = size.y
	mesh.material = material
	node.mesh = mesh
	node.position = at
	node.rotation.z = roll
	root.add_child(node)
