class_name Door
extends Node3D
## A hinged door in a wall line. Swings away from whoever opens it, can be locked by an item
## ("key_red", "fuse" power, "crowbar" planks), slams (loud noise + camera shake) and closes
## itself behind the neighbour when it was locked. The panel is an AnimatableBody3D on layer 5
## ("doors"): it blocks bodies but is left out of the navmesh bake, so paths go through doors;
## once fully open it stops colliding.

signal opened(door: Door, by_player: bool)
signal slammed(door: Door)

const OPEN_SPEED := 3.2              # radians per second
const SLAM_SPEED := 9.0

var letter := "D"                    # "D" or the lock letter from the plan
var needs := ""                      # item id, "power" or "" (unlocked)
var locked := false
var is_open := false
var relock := false                  # close + lock again once nobody is near (neighbour passed)
var width := Config.CELL
var _angle := 0.0
var _target := 0.0
var _speed := OPEN_SPEED
var _relock_timer := 0.0
var _pivot: Node3D
var _panel: AnimatableBody3D
var _shape: CollisionShape3D
var _lock_mark: MeshInstance3D
var _planks: Node3D


## `along_x`: the wall line runs along X. `color` tints the lock plate for locked doors.
func setup(along_x: bool, lock: String, color: Color) -> void:
	needs = lock
	locked = lock != ""
	rotation.y = 0.0 if along_x else PI * 0.5
	_pivot = Node3D.new()
	_pivot.position = Vector3(-width * 0.5 + 0.06, 0, 0)
	add_child(_pivot)
	_panel = AnimatableBody3D.new()
	_panel.collision_layer = 16
	_panel.collision_mask = 0
	_pivot.add_child(_panel)
	var size := Vector3(width - 0.14, Config.DOOR_HEIGHT - 0.04, 0.07)
	var mesh := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	var wood := StandardMaterial3D.new()
	wood.albedo_color = Config.WOOD.darkened(0.15) if not locked else Config.WOOD.darkened(0.35)
	wood.roughness = 0.8
	box.material = wood
	mesh.mesh = box
	mesh.position = Vector3(size.x * 0.5, size.y * 0.5 + 0.02, 0)
	_panel.add_child(mesh)
	_shape = CollisionShape3D.new()
	_shape.shape = BoxShape3D.new()
	(_shape.shape as BoxShape3D).size = size
	_shape.position = mesh.position
	_panel.add_child(_shape)
	_add_frame(size)
	_add_door_panels(size)
	_add_hinges(size)
	_add_handle(size)
	if locked:
		_lock_mark = _box(Vector3(0.16, 0.22, 0.14), Vector3(size.x - 0.16, 1.05, 0), color, true)
		_panel.add_child(_lock_mark)
	if lock == "crowbar":
		_planks = Node3D.new()
		add_child(_planks)
		for i in 3:
			var plank := _box(Vector3(width * 1.05, 0.16, 0.05), Vector3(0, 0.55 + i * 0.5, 0.08 * (1 - 2 * (i % 2))), Config.FENCE, false)
			plank.rotation.z = 0.25 * (1 - 2 * (i % 2))
			_planks.add_child(plank)


## The point the player aims at to use the door.
func aim_point() -> Vector3:
	return global_position + Vector3.UP * 1.1


## Opens away from `from`. Unlocking is the caller's job (Interaction checks the inventory).
func open_from(from: Vector3, by_player: bool) -> void:
	if is_open:
		return
	var local := to_local(from)
	_target = (1.0 if local.z > 0.0 else -1.0) * PI * 0.5   # +90° swings the panel toward -Z
	_speed = OPEN_SPEED
	is_open = true
	Sfx.play_at("door_open", global_position, -4.0)
	opened.emit(self, by_player)


func close(slam := false) -> void:
	if not is_open:
		return
	is_open = false
	_target = 0.0
	_speed = SLAM_SPEED if slam else OPEN_SPEED
	if slam:
		Sfx.play_at("slam", global_position, 2.0)
		slammed.emit(self)
	else:
		Sfx.play_at("door_close", global_position, -6.0)


func unlock() -> void:
	locked = false
	needs = ""
	relock = false
	if _lock_mark:
		_lock_mark.queue_free()
		_lock_mark = null
	if _planks:
		_planks.queue_free()
		_planks = null


## Locked doors the neighbour walks through lock again behind him.
func pass_through(from: Vector3) -> void:
	if locked:
		relock = true
	open_from(from, false)
	_relock_timer = 2.5


func _physics_process(delta: float) -> void:
	_angle = move_toward(_angle, _target, _speed * delta)
	if _pivot:
		_pivot.rotation.y = _angle
		# A fully open door stops colliding: it never pinches the doorway paths run through.
		_shape.disabled = is_open and is_equal_approx(_angle, _target)
	if relock and is_open:
		_relock_timer -= delta
		if _relock_timer <= 0.0:
			close()


func keep_open() -> void:
	_relock_timer = 2.5


## A fixed wooden jamb makes the doorway read as part of the house instead of a floating slab.
func _add_frame(size: Vector3) -> void:
	var frame_color := Config.WOOD.darkened(0.28)
	for side in [-1.0, 1.0]:
		var post := _box(Vector3(0.12, Config.DOOR_HEIGHT + 0.08, 0.16), Vector3(side * (width * 0.5 - 0.015), Config.DOOR_HEIGHT * 0.5, 0.0), frame_color, false)
		add_child(post)
	var lintel := _box(Vector3(width + 0.12, 0.13, 0.16), Vector3(0, Config.DOOR_HEIGHT + 0.015, 0.0), frame_color, false)
	add_child(lintel)


## Raised rails and inset panels add depth to the door without changing its collision shape.
func _add_door_panels(size: Vector3) -> void:
	var trim := Config.WOOD.darkened(0.28)
	var inset := Config.WOOD.lightened(0.08) if not locked else Config.WOOD.darkened(0.23)
	for side in [-1.0, 1.0]:
		var z := side * 0.041
		for x in [-size.x * 0.5 + 0.09, size.x * 0.5 - 0.09]:
			var rail := _box(Vector3(0.045, size.y - 0.16, 0.025), Vector3(x, size.y * 0.5, z), trim, false)
			_panel.add_child(rail)
		for y in [0.52, 1.43]:
			var panel := _box(Vector3(size.x - 0.34, 0.58, 0.022), Vector3(0, y, z), inset, false)
			_panel.add_child(panel)
			var top_rail := _box(Vector3(size.x - 0.30, 0.035, 0.026), Vector3(0, y + 0.30, z), trim, false)
			_panel.add_child(top_rail)
			var bottom_rail := _box(Vector3(size.x - 0.30, 0.035, 0.026), Vector3(0, y - 0.30, z), trim, false)
			_panel.add_child(bottom_rail)


func _add_hinges(size: Vector3) -> void:
	for side in [-1.0, 1.0]:
		for y in [0.35, 1.0, 1.72]:
			var hinge := _box(Vector3(0.07, 0.16, 0.025), Vector3(-size.x * 0.5 + 0.09, y, side * 0.052), Color("#4c4942"), true)
			_panel.add_child(hinge)


func _add_handle(size: Vector3) -> void:
	for side in [-1.0, 1.0]:
		var plate := _box(Vector3(0.11, 0.20, 0.025), Vector3(size.x - 0.16, 1.0, 0.052 * side), Color("#6b5237"), true)
		_panel.add_child(plate)
		var knob := _box(Vector3(0.075, 0.075, 0.07), Vector3(size.x - 0.16, 1.0, 0.09 * side), Color("#c0a06a"), true)
		_panel.add_child(knob)


static func _box(size: Vector3, at: Vector3, color: Color, metal: bool) -> MeshInstance3D:
	var node := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = 0.6 if metal else 0.0
	material.roughness = 0.35 if metal else 0.85
	box.material = material
	node.mesh = box
	node.position = at
	return node
