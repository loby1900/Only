class_name Lamp
extends OmniLight3D
## A warm house light with an emissive bulb. `flicker` makes it stutter now and then (a bad
## wire), `powered` = false keeps it dark until the fuse box gets a fuse, and blackout(seconds)
## kills it for a scare. The neighbour's senses read `lit_at()` to know if you stand in light.

var flicker := false
var powered := true
var base_energy := 1.4
var bulb: StandardMaterial3D
var _blackout := 0.0
var _stutter := 0.0
var _rng := RandomNumberGenerator.new()


func setup(energy: float, reach: float, flickers: bool, has_power: bool) -> void:
	base_energy = energy
	omni_range = reach
	omni_attenuation = 1.4
	light_color = Config.LAMP_LIGHT
	shadow_enabled = false
	flicker = flickers
	powered = has_power
	_rng.randomize()
	_apply(1.0)


func set_powered(on: bool) -> void:
	powered = on
	_apply(1.0)


func blackout(seconds: float) -> void:
	_blackout = seconds


func is_on() -> bool:
	return powered and _blackout <= 0.0 and light_energy > base_energy * 0.3


## 0..1: how strongly this lamp lights a point (0 outside its useful radius).
func lit_at(point: Vector3) -> float:
	if not is_on():
		return 0.0
	var d := global_position.distance_to(point)
	return clampf(1.2 - d / (omni_range * 0.75), 0.0, 1.0)


func _process(delta: float) -> void:
	if _blackout > 0.0:
		_blackout -= delta
		# A dying bulb: a few weak sparks, then dark.
		_apply(0.25 if _rng.randf() < 0.06 else 0.0)
		return
	if not flicker or not powered:
		_apply(1.0)
		return
	_stutter -= delta
	if _stutter <= 0.0:
		_stutter = _rng.randf_range(2.0, 6.0) if _rng.randf() < 0.7 else _rng.randf_range(0.05, 0.25)
	_apply(1.0 if _stutter > 0.3 else _rng.randf_range(0.1, 0.8))


func _apply(level: float) -> void:
	var on := 1.0 if powered else 0.0
	light_energy = base_energy * level * on
	if bulb:
		bulb.emission_energy_multiplier = 2.5 * level * on
