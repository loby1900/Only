class_name Props
extends RefCounted
## Furniture for the plan's prop characters: which model, how big, and how it stands. Models are
## centred on their footprint and scaled here, so any .glb works whatever its origin.
## ADD A PROP: a free lowercase letter → {model, scale, …}; then use the letter in a plan.
##   against_wall: backs onto the nearest wall (else stands in the middle of the cell)
##   solid: gets a box collider (layer 2) — blocks you, the neighbour and the navmesh
##   lamp: [energy, range, flickers]   ceiling: hangs from the ceiling

const KIT := "res://assets/furniture-kit/%s.glb"
const PROPS := {
	"k": {"model": "kitchencabinetdrawer", "scale": 2.0, "against_wall": true, "solid": true},
	"r": {"model": "kitchenfridge", "scale": 2.0, "against_wall": true, "solid": true},
	"s": {"model": "loungesofa", "scale": 1.9, "against_wall": true, "solid": true},
	"t": {"model": "table", "scale": 2.0, "against_wall": false, "solid": true},
	"b": {"model": "bookcaseopen", "scale": 2.2, "against_wall": true, "solid": true},
	"v": {"model": "cabinettelevision", "scale": 1.8, "against_wall": true, "solid": true, "top": "televisionvintage"},
	"w": {"model": "washer", "scale": 2.0, "against_wall": true, "solid": true},
	"c": {"model": "cardboardboxclosed", "scale": 2.6, "against_wall": false, "solid": true, "top": "cardboardboxopen"},
	"l": {"model": "lamproundfloor", "scale": 2.0, "against_wall": true, "solid": true, "lamp": [1.5, 6.5, true]},
	"e": {"model": "lampsquareceiling", "scale": 2.0, "against_wall": false, "solid": false, "lamp": [1.8, 7.5, false], "ceiling": true},
	"H": {"model": "bookcasecloseddoors", "scale": 2.35, "against_wall": true, "solid": true},
	"U": {"model": "bedsingle", "scale": 2.0, "against_wall": true, "solid": true},
	"X": {"model": "res://assets/survival-kit/chest.glb", "scale": 3.0, "against_wall": true, "solid": true},
	"x": {"model": "res://assets/survival-kit/bottle.glb", "scale": 2.4, "against_wall": false, "solid": false},
}


## The prop's model, centred on x/z with its bottom at y = 0, scaled. `size` meta = footprint.
static func make(letter: String) -> Node3D:
	var info: Dictionary = PROPS[letter]
	var root := Node3D.new()
	root.name = "Prop_" + letter
	var model := _load(info.model)
	root.add_child(model)
	model.scale = Vector3.ONE * float(info.scale)
	var box := bounds(model)
	model.position = Vector3(-box.get_center().x, -box.position.y, -box.get_center().z)
	if info.has("top"):
		var top := _load(info.top)
		root.add_child(top)
		top.scale = Vector3.ONE * float(info.scale)
		var top_box := bounds(top)
		top.position = Vector3(-top_box.get_center().x, box.size.y - top_box.position.y, -top_box.get_center().z)
	root.set_meta("size", box.size)
	return root


static func _load(path: String) -> Node3D:
	var full := path if path.begins_with("res://") else KIT % path
	return (load(full) as PackedScene).instantiate() as Node3D


## Merged bounds of every mesh under `node`, in node's parent space.
static func bounds(node: Node3D) -> AABB:
	var result := AABB()
	var first := true
	for child in node.find_children("*", "VisualInstance3D", true, false) + [node]:
		if not child is VisualInstance3D:
			continue
		var visual := child as VisualInstance3D
		var xform := node.transform
		var walk: Node = visual
		var local := Transform3D.IDENTITY
		while walk != node and walk is Node3D:
			local = (walk as Node3D).transform * local
			walk = walk.get_parent()
		var box := (xform * local) * visual.get_aabb()
		result = box if first else result.merge(box)
		first = false
	return result


## A static box collider on layer 2 around a placed prop.
static func add_collider(prop: Node3D, size: Vector3, shrink := 0.9) -> void:
	var body := StaticBody3D.new()
	body.collision_layer = 2
	body.collision_mask = 0
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(size.x * shrink, size.y, size.z * shrink)
	shape.shape = box
	shape.position.y = size.y * 0.5
	body.add_child(shape)
	prop.add_child(body)
