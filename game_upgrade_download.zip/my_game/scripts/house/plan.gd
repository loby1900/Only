class_name Plan
extends RefCounted
## Reads a level's ASCII plans (Levels) and answers grid questions: what is at a cell, is it a
## wall line, indoor or outdoor, which room (flood-filled region) it belongs to, where a cell
## is in the world, and how the stairs run. Pure data, no nodes. `below` = the cellar plan.

const WALLS := "#WDABC"            # characters that sit in a wall line
const DOORS := "DABC"
const FLOORS := ".:,="

var rows: PackedStringArray
var cellar: PackedStringArray
var w := 0
var h := 0
var regions := {}                  # Vector2i -> room index (ground indoor cells)
var stairs: Array[Vector2i] = []   # the S cells, from the top landing downwards
var stair_top := Vector2i.ZERO     # the walkable ground cell the stairs start from
var stair_dir := Vector2i.ZERO     # downhill direction


func _init(level: Dictionary) -> void:
	rows = PackedStringArray(level.rows)
	cellar = PackedStringArray(level.get("cellar", []))
	h = rows.size()
	w = rows[0].length()
	_find_stairs()
	_flood_rooms()


func at(c: Vector2i, below := false) -> String:
	var plan := cellar if below else rows
	if c.y < 0 or c.y >= plan.size() or c.x < 0 or c.x >= plan[c.y].length():
		return " " if below else "~"
	return plan[c.y][c.x]


func walled(c: Vector2i, below := false) -> bool:
	return WALLS.contains(at(c, below))


func fence(c: Vector2i) -> bool:
	return at(c) == "f"


## The floor character under a cell: markers and props inherit it from a neighbour.
func floor_of(c: Vector2i) -> String:
	var ch := at(c)
	if FLOORS.contains(ch):
		return ch
	if ch == "f" or ch == "~":
		return ","
	for d: Vector2i in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
		var other := at(c + d)
		if FLOORS.contains(other):
			return other
	return "."


func outdoor(c: Vector2i) -> bool:
	return not walled(c) and at(c) != "S" and floor_of(c) in [",", "="]


## Walkable on the ground floor (doors count; walls, fences and furniture decide elsewhere).
func open_ground(c: Vector2i) -> bool:
	var ch := at(c)
	return ch != "~" and ch != "f" and (not walled(c) or DOORS.contains(ch))


## Cell centre on the floor surface (ground y = 0, cellar y = -CELLAR_DEPTH).
func center(c: Vector2i, below := false) -> Vector3:
	return Vector3((c.x + 0.5 - w * 0.5) * Config.CELL, -Config.CELLAR_DEPTH if below else 0.0,
		(c.y + 0.5 - h * 0.5) * Config.CELL)


func cell_of(p: Vector3) -> Vector2i:
	return Vector2i(floori(p.x / Config.CELL + w * 0.5), floori(p.z / Config.CELL + h * 0.5))


func is_below(p: Vector3) -> bool:
	return p.y < -1.2


func find(ch: String, below := false) -> Array[Vector2i]:
	var found: Array[Vector2i] = []
	var plan := cellar if below else rows
	for y in plan.size():
		for x in plan[y].length():
			if plan[y][x] == ch:
				found.append(Vector2i(x, y))
	return found


## A door or window runs along X when its left/right neighbours are wall line too.
func along_x(c: Vector2i, below := false) -> bool:
	return walled(c + Vector2i.LEFT, below) or walled(c + Vector2i.RIGHT, below)


## First neighbouring wall direction (furniture backs onto it), or ZERO.
func wall_side(c: Vector2i, below := false) -> Vector2i:
	for d: Vector2i in [Vector2i.UP, Vector2i.LEFT, Vector2i.RIGHT, Vector2i.DOWN]:
		if at(c + d, below) == "#" or at(c + d, below) == "W":
			return d
	return Vector2i.ZERO


func _find_stairs() -> void:
	var cells := find("S")
	if cells.is_empty():
		return
	var vertical := cells.size() == 1 or cells[1].x == cells[0].x
	stair_dir = Vector2i.DOWN if vertical else Vector2i.RIGHT
	var first := cells[0]
	var last := cells[cells.size() - 1]
	# The stairs start at the end touching a walkable ground cell and run away from it.
	if not open_ground(first - stair_dir) or open_ground(last + stair_dir):
		stair_dir = -stair_dir
		cells.reverse()
	stairs = cells
	stair_top = stairs[0] - stair_dir


func _flood_rooms() -> void:
	var next := 0
	for y in h:
		for x in w:
			var start := Vector2i(x, y)
			if regions.has(start) or walled(start) or outdoor(start) or at(start) == "~":
				continue
			var queue: Array[Vector2i] = [start]
			regions[start] = next
			while not queue.is_empty():
				var c: Vector2i = queue.pop_back()
				for d: Vector2i in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
					var o: Vector2i = c + d
					if not regions.has(o) and not walled(o) and not outdoor(o) and at(o) != "~":
						regions[o] = next
						queue.append(o)
			next += 1
