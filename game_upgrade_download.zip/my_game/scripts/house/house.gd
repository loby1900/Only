class_name House
extends NavigationRegion3D
## Builds one level's house from its ASCII plans (Levels / Plan): floors, thin walls (a post per
## wall cell plus arms toward wall neighbours), windows with glass, door headers, ceilings, the
## cellar and the stairs ramp — merged into a few meshes by Mesher, colliders on layer 2. Then
## Furnish adds doors, furniture, lamps, items and hiding spots, and the navmesh is baked from
## the static colliders (doors are on layer 5, so paths run through them).

const NAV_LAYER_MASK := 2

var plan: Plan
var level: Dictionary
var doors: Array[Door] = []
var things: Array[Interactable] = []      # items, hiding spots, fuse box, secret
var lamps: Array[Lamp] = []
var patrol: Array[Vector3] = []
var triggers: Array[Vector2i] = []        # "!" cells in plan order → level "scares"
var bottles: Array[Vector3] = []
var player_start := Vector3.ZERO
var neighbor_start := Vector3.ZERO
var body: StaticBody3D


func build(new_level: Dictionary) -> void:
	clear()
	level = new_level
	plan = Plan.new(level)
	body = StaticBody3D.new()
	body.name = "Structure"
	body.collision_layer = 2
	body.collision_mask = 0
	add_child(body)
	var m := Mesher.new(body)
	_materials(m)
	_ground(m)
	for below in [false, true]:
		for y in plan.h:
			for x in plan.w:
				if plan.walled(Vector2i(x, y), below):
					_wall(m, Vector2i(x, y), below)
				elif not below and plan.fence(Vector2i(x, y)):
					HouseParts.fence(m, plan, Vector2i(x, y))
	HouseParts.stairs(m, plan)
	HouseParts.roof(m, plan)
	m.commit(self)
	Furnish.new(self).run()
	_add_secret_evidence()
	_bake()


## Optional side quest: collect the neighbour's hidden evidence in the cellar. These are
## lightweight interactables placed on authored walkable marker cells; they do not block paths.
func _add_secret_evidence() -> void:
	var ground_cells := plan.find("*")
	var cellar_cells := plan.find("*", true)
	var placements: Array[Dictionary] = []
	# Two clues in the house and one deeper in the cellar, when those cells exist.
	for i in mini(2, ground_cells.size()):
		placements.append({"cell": ground_cells[i], "below": false})
	if not cellar_cells.is_empty():
		placements.append({"cell": cellar_cells[cellar_cells.size() / 2], "below": true})
	# Some layouts have few authored markers; safely fill from any remaining cellar markers.
	for cell: Vector2i in cellar_cells:
		if placements.size() >= 3:
			break
		var already_used := false
		for placement: Dictionary in placements:
			if bool(placement["below"]) and placement["cell"] == cell:
				already_used = true
		if not already_used:
			placements.append({"cell": cell, "below": true})
	for i in placements.size():
		var clue := Interactable.new()
		clue.name = "HiddenEvidence_%d" % (i + 1)
		clue.kind = Interactable.Kind.EVIDENCE
		clue.slot = str(i + 1)
		var visual := Node3D.new()
		var paper := MeshInstance3D.new()
		var sheet := BoxMesh.new()
		sheet.size = Vector3(0.32, 0.045, 0.24)
		paper.mesh = sheet
		var paper_mat := StandardMaterial3D.new()
		paper_mat.albedo_color = Color(0.82, 0.75, 0.55)
		paper_mat.roughness = 0.92
		paper.material_override = paper_mat
		visual.add_child(paper)
		var seal := MeshInstance3D.new()
		var seal_mesh := BoxMesh.new()
		seal_mesh.size = Vector3(0.045, 0.012, 0.16)
		seal.mesh = seal_mesh
		seal.position = Vector3(0.0, 0.03, 0.0)
		var seal_mat := StandardMaterial3D.new()
		seal_mat.albedo_color = Color(0.55, 0.12, 0.12)
		seal.material_override = seal_mat
		visual.add_child(seal)
		clue.setup(Interactable.Kind.EVIDENCE, str(i + 1), visual)
		add_child(clue)
		var cell: Vector2i = placements[i]["cell"]
		clue.global_position = plan.center(cell, bool(placements[i]["below"])) + Vector3(0.0, 0.22, 0.0)
		clue.rotation.y = float(i) * 1.7
		things.append(clue)


func clear() -> void:
	for child in get_children():
		remove_child(child)
		child.queue_free()
	doors.clear()
	things.clear()
	lamps.clear()
	patrol.clear()
	triggers.clear()
	bottles.clear()


func _materials(m: Mesher) -> void:
	m.material("wood", Config.WOOD, 1, 0.75)
	m.material("tile", Config.TILE, 2, 0.5)
	m.material("grass", Config.GRASS, 3, 0.95)
	m.material("path", Config.PATH, 6, 0.9)
	m.material("concrete", Config.CONCRETE, 4, 0.9)
	m.material("ceiling", Config.CEILING, 7, 0.95)
	m.material("siding", Config.SIDING, 5, 0.85)
	m.material("trim", Config.WOOD.darkened(0.3), 1, 0.7)
	m.material("fence", Config.FENCE, 1, 0.9)
	m.material("roof", Config.ROOF, 5, 0.9)
	for i in Config.ROOM_TINTS.size():
		m.material("wall_%d" % i, Config.ROOM_TINTS[i], 0, 0.9)
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color(0.55, 0.68, 0.9, 0.22)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass.roughness = 0.1
	glass.metallic = 0.4
	m.set_material("glass", glass)


## Floor slabs for every ground cell but the stairs; their undersides are the cellar ceiling.
func _ground(m: Mesher) -> void:
	for y in plan.h:
		for x in plan.w:
			var c := Vector2i(x, y)
			var ch := plan.at(c)
			if ch == "S":
				continue
			var key: String = {".": "wood", ":": "tile", ",": "grass", "=": "path"}[plan.floor_of(c)]
			var p := plan.center(c)
			m.box(p + Vector3(0, -0.1, 0), Vector3(Config.CELL, 0.2, Config.CELL),
				func(_f: Vector3, n: Vector3) -> String: return "concrete" if n.y < -0.5 else key, false)
			if not plan.outdoor(c) and not plan.fence(c):
				m.box(p + Vector3(0, Config.WALL_HEIGHT + 0.1, 0), Vector3(Config.CELL, 0.2, Config.CELL), "ceiling", false)
			var below := plan.at(c, true)
			if below != " " and not plan.walled(c, true):
				m.box(plan.center(c, true) + Vector3(0, -0.1, 0), Vector3(Config.CELL, 0.2, Config.CELL), "concrete", false)
		# One collider per row run instead of one per cell.
		_row_collider(m, y, false)
		_row_collider(m, y, true)


func _row_collider(m: Mesher, y: int, below: bool) -> void:
	var start := -1
	for x in plan.w + 1:
		var solid := x < plan.w and (plan.at(Vector2i(x, y), below) != " " if below else plan.at(Vector2i(x, y)) != "S")
		if solid and start < 0:
			start = x
		elif not solid and start >= 0:
			var a := plan.center(Vector2i(start, y), below)
			var b := plan.center(Vector2i(x - 1, y), below)
			m.shape((a + b) * 0.5 + Vector3(0, -0.1, 0), Vector3((x - start) * Config.CELL, 0.2, Config.CELL))
			start = -1


func _wall(m: Mesher, c: Vector2i, below: bool) -> void:
	var ch := plan.at(c, below)
	var base := plan.center(c, below)
	var top := 0.0 if below else Config.WALL_HEIGHT
	var y0 := base.y
	var t := Config.WALL_THICKNESS
	var face := _wall_face.bind(below)
	if ch == "#":
		m.box(base + Vector3(0, (top - y0) * 0.5, 0), Vector3(t, top - y0, t), face)
		for d: Vector2i in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
			if plan.walled(c + d, below):
				var dir := Vector3(d.x, 0, d.y)
				var length := (Config.CELL - t) * 0.5
				var size := Vector3(length if d.x != 0 else t, top - y0, length if d.y != 0 else t)
				m.box(base + dir * (t * 0.5 + length * 0.5) + Vector3(0, (top - y0) * 0.5, 0), size, face)
		return
	var along := Vector3(Config.CELL, 0, t) if plan.along_x(c, below) else Vector3(t, 0, Config.CELL)
	var cut_low := Config.WINDOW_SILL if ch == "W" else 0.0
	var cut_high := Config.WINDOW_TOP if ch == "W" else Config.DOOR_HEIGHT
	if cut_low > 0.0:
		m.box(base + Vector3(0, cut_low * 0.5, 0), along + Vector3(0, cut_low, 0), face)
		var pane := Vector3(along.x if along.x > 1.0 else 0.03, cut_high - cut_low, along.z if along.z > 1.0 else 0.03)
		m.box(base + Vector3(0, (cut_low + cut_high) * 0.5, 0), pane, "glass", false)
	m.box(base + Vector3(0, (cut_high + top - y0) * 0.5, 0), along + Vector3(0, top - y0 - cut_high, 0), face)


## Which material a wall face gets: the tint of the room it faces, siding outside, trim inside
## door and window openings, concrete in the cellar.
func _wall_face(face: Vector3, n: Vector3, below: bool) -> String:
	if below:
		return "concrete"
	if absf(n.y) > 0.5:
		return "trim"
	var cell := plan.cell_of(face + n * Config.CELL * 0.45)
	if plan.walled(cell) or plan.at(cell) == "~":
		return "trim"
	if plan.outdoor(cell) or plan.fence(cell):
		return "siding"
	return "wall_%d" % (int(plan.regions.get(cell, 0)) % Config.ROOM_TINTS.size())


func _bake() -> void:
	var mesh := NavigationMesh.new()
	mesh.geometry_parsed_geometry_type = NavigationMesh.PARSED_GEOMETRY_STATIC_COLLIDERS
	mesh.geometry_collision_mask = NAV_LAYER_MASK
	mesh.cell_size = 0.1
	mesh.cell_height = 0.1
	mesh.agent_radius = 0.3
	mesh.agent_height = 1.7
	mesh.agent_max_climb = 0.3
	mesh.agent_max_slope = 42.0
	navigation_mesh = mesh
	bake_navigation_mesh(false)
