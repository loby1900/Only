class_name Furnish
extends RefCounted
## Walks both plans of a House and places everything that is not structure: doors (locks from
## the level), furniture (Props), lamps, items, hiding spots, the fuse box, the secret chest,
## bottles, and records markers (player / neighbour start, patrol points, scare triggers).

var house: House
var plan: Plan
var _power_needed := false


func _init(target: House) -> void:
	house = target
	plan = target.plan
	_power_needed = (house.level.locks as Dictionary).values().has("power")


func run() -> void:
	for below in [false, true]:
		for y in plan.h:
			for x in plan.w:
				_place(Vector2i(x, y), below)


func _place(c: Vector2i, below: bool) -> void:
	var ch := plan.at(c, below)
	var p := plan.center(c, below)
	match ch:
		"D", "A", "B", "C":
			_door(c, below, ch)
		"P":
			house.player_start = p
		"N":
			house.neighbor_start = p
		"*":
			house.patrol.append(p)
		"!":
			house.triggers.append(c)
		"x":
			house.bottles.append(p)
			for i in 3:
				var bottle := Props.make("x")
				house.add_child(bottle)
				bottle.position = p + Vector3(0.25 * cos(i * 2.1), 0, 0.25 * sin(i * 2.1))
				bottle.rotation.z = 1.4 if i == 1 else 0.0     # one knocked over
		"F":
			_fuse_box(c, below)
		"1", "2", "3", "4":
			var thing := Interactable.new()
			thing.item = String(house.level.items.get(ch, "key_red"))
			thing.setup(Interactable.Kind.ITEM, ch, Inventory.model(thing.item))
			house.add_child(thing)
			thing.position = p + Vector3.UP * 0.15
			house.things.append(thing)
		_:
			if Props.PROPS.has(ch):
				_prop(c, below, ch)


func _door(c: Vector2i, below: bool, ch: String) -> void:
	var door := Door.new()
	door.letter = ch
	house.add_child(door)
	door.position = plan.center(c, below)
	var needs := String(house.level.locks.get(ch, "")) if ch != "D" else ""
	var color: Color = Config.CORAL if needs == "power" else Inventory.info(needs).color
	door.setup(plan.along_x(c, below), needs, color)
	house.doors.append(door)


func _prop(c: Vector2i, below: bool, ch: String) -> void:
	var info: Dictionary = Props.PROPS[ch]
	var prop := Props.make(ch)
	var size: Vector3 = prop.get_meta("size")
	var p := plan.center(c, below)
	var side := plan.wall_side(c, below)
	if info.against_wall and side != Vector2i.ZERO:
		var back := Vector3(side.x, 0, side.y)
		prop.rotation.y = atan2(-back.x, -back.z)          # the kit's models face +Z
		p += back * (Config.CELL * 0.5 - Config.WALL_THICKNESS * 0.5 - size.z * 0.5 - 0.02)
	if info.get("ceiling", false):
		p.y = (-0.2 if below else Config.WALL_HEIGHT) - size.y
	house.add_child(prop)
	prop.position = p
	if info.solid:
		Props.add_collider(prop, size)
	if info.has("lamp"):
		_lamp(prop, info, size, below)
	var forward := Vector3(sin(prop.rotation.y), 0, cos(prop.rotation.y))
	if ch == "H" or ch == "U" or ch == "X":
		var thing := Interactable.new()
		var kind := {"H": Interactable.Kind.CLOSET, "U": Interactable.Kind.BED, "X": Interactable.Kind.SECRET}[ch] as Interactable.Kind
		thing.setup(kind, ch, null)
		house.add_child(thing)
		thing.position = p
		thing.face_yaw = prop.rotation.y + PI       # the camera looks out of the front (+Z)
		thing.exit = p + forward * (size.z * 0.5 + 0.55)
		thing.eye = p + Vector3.UP * 1.45 - forward * 0.05
		if kind == Interactable.Kind.BED:
			var across := Vector3(forward.z, 0, -forward.x)
			if not plan.open_ground(plan.cell_of(p + across * Config.CELL)):
				across = -across
			thing.exit = p + across * (size.x * 0.5 + 0.5)
			thing.eye = p + Vector3.UP * 0.25
			thing.face_yaw = atan2(-across.x, -across.z)   # camera yaw looking along `across`
		elif kind == Interactable.Kind.SECRET:
			thing.model = prop
		house.things.append(thing)


func _lamp(prop: Node3D, info: Dictionary, size: Vector3, below: bool) -> void:
	var settings: Array = info.lamp
	var lamp := Lamp.new()
	prop.add_child(lamp)
	lamp.position = Vector3(0, size.y - 0.15 if not info.get("ceiling", false) else -0.25, 0)
	var bulb := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.09
	sphere.height = 0.18
	var glow := StandardMaterial3D.new()
	glow.albedo_color = Config.LAMP_LIGHT
	glow.emission_enabled = true
	glow.emission = Config.LAMP_LIGHT
	sphere.material = glow
	bulb.mesh = sphere
	bulb.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	lamp.add_child(bulb)
	lamp.bulb = glow
	var wired: bool = info.get("ceiling", false) and _power_needed
	lamp.setup(settings[0], settings[1], settings[2], not wired)
	lamp.set_meta("wired", wired)
	lamp.set_meta("cellar", below)
	house.lamps.append(lamp)


func _fuse_box(c: Vector2i, below: bool) -> void:
	var side := plan.wall_side(c, below)
	var back := Vector3(side.x, 0, side.y)
	var thing := Interactable.new()
	var box := Node3D.new()
	var panel := Door._box(Vector3(0.55, 0.75, 0.16), Vector3(0, 1.3, 0), Color("#6f7680"), true)
	box.add_child(panel)
	var led := Door._box(Vector3(0.08, 0.08, 0.04), Vector3(0.18, 1.58, 0.09), Config.CORAL, false)
	(led.mesh.surface_get_material(0) as StandardMaterial3D).emission_enabled = true
	(led.mesh.surface_get_material(0) as StandardMaterial3D).emission = Config.CORAL
	box.add_child(led)
	box.set_meta("led", led)
	thing.setup(Interactable.Kind.FUSE_BOX, "F", box)
	house.add_child(thing)
	thing.position = plan.center(c, below) + back * (Config.CELL * 0.5 - Config.WALL_THICKNESS * 0.5 - 0.1)
	thing.rotation.y = atan2(-back.x, -back.z)
	house.things.append(thing)
