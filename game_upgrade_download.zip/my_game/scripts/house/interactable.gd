class_name Interactable
extends Node3D
## Anything the player can use that is not a door: an item to pick up, a hiding spot (inside a
## wardrobe or under a bed), the fuse box and the secret. Holds data and small animations only;
## what using it does lives in Interaction (scripts/interaction.gd). Doors share the same
## duck-typed API: aim_point().

enum Kind { ITEM, CLOSET, BED, FUSE_BOX, SECRET, EVIDENCE }

var kind := Kind.ITEM
var item := ""                        # ITEM: the item id
var slot := ""                        # the plan character ("1", "F", "X") — objective steps use it
var used := false
var eye := Vector3.ZERO               # hiding: where the camera goes (global)
var exit := Vector3.ZERO              # hiding: where the player steps out; the neighbour checks here
var face_yaw := 0.0                   # hiding: the way the camera looks from inside
var model: Node3D
var _base_y := 0.0
var _anim: AnimationPlayer


func setup(new_kind: Kind, plan_char: String, visual: Node3D) -> void:
	kind = new_kind
	slot = plan_char
	model = visual
	if model:
		add_child(model)
		_base_y = model.position.y
		_anim = model.find_child("AnimationPlayer", true, false)


func aim_point() -> Vector3:
	match kind:
		Kind.ITEM:
			return global_position + Vector3.UP * 0.35
		Kind.BED:
			return global_position + Vector3.UP * 0.5
		Kind.FUSE_BOX:
			return global_position + Vector3.UP * 1.3
	return global_position + Vector3.UP * 1.0


## Hiding spots are big: aiming anywhere at them within reach counts.
func reach_bonus() -> float:
	return 0.6 if kind == Kind.CLOSET or kind == Kind.BED else 0.0


func take() -> void:
	used = true
	var tween := create_tween()
	tween.tween_property(self, "scale", Vector3.ONE * 0.01, 0.2).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_IN)
	tween.tween_callback(queue_free)


## Secret chest / fuse box: plays the model's "open" clip if it has one.
func open_up() -> void:
	used = true
	if _anim and _anim.has_animation("open"):
		_anim.play("open")


func _process(delta: float) -> void:
	if kind == Kind.ITEM and model and not used:
		model.rotation.y += delta * 1.6
		model.position.y = _base_y + sin(Time.get_ticks_msec() * 0.003) * 0.05
