class_name Mesher
extends RefCounted
## Collects thousands of boxes into a few merged meshes (one per material key and CHUNK-sized
## block, so each piece only gets the lamps near it — the Compatibility renderer lights an object
## with at most max_lights_per_object lights) plus box colliders on one StaticBody3D.
## Each face of a box can pick its own material: pass a Callable(face_centre, normal) -> key.
##   var m := Mesher.new(body)
##   m.material("floor", Config.WOOD, 1)
##   m.box(Vector3(0, -0.1, 0), Vector3(1.5, 0.2, 1.5), "floor")
##   m.commit(parent)

const FACES := [Vector3.RIGHT, Vector3.LEFT, Vector3.UP, Vector3.DOWN, Vector3.BACK, Vector3.FORWARD]
const SHADER := preload("res://shaders/surface.gdshader")
const CHUNK := 9.0                  # metres per merged block

var body: StaticBody3D
var _tools := {}                    # key -> SurfaceTool
var _materials := {}                # key -> Material


func _init(static_body: StaticBody3D) -> void:
	body = static_body


## Registers a surface material (see shaders/surface.gdshader for patterns).
func material(key: String, color: Color, pattern: int, roughness := 0.85, floor_y := 0.0) -> void:
	var mat := ShaderMaterial.new()
	mat.shader = SHADER
	mat.set_shader_parameter("color", color)
	mat.set_shader_parameter("pattern", pattern)
	mat.set_shader_parameter("roughness", roughness)
	mat.set_shader_parameter("floor_y", floor_y)
	_materials[key] = mat


## Registers any other material (glass).
func set_material(key: String, mat: Material) -> void:
	_materials[key] = mat


## An axis-aligned box. `key` is a material key or a Callable(face_centre, normal) -> key
## ("" skips the face). `collide` adds a matching BoxShape3D to the body.
func box(center: Vector3, size: Vector3, key: Variant, collide := true) -> void:
	var half := size * 0.5
	var block := "|%d,%d" % [floori(center.x / CHUNK), floori(center.z / CHUNK)]
	for n: Vector3 in FACES:
		var face_center := center + n * half
		var surface: String = key.call(face_center, n) if key is Callable else String(key)
		if surface == "":
			continue
		_face(_tool(surface + block), center, half, n)
	if collide:
		shape(center, size)


## A flat convex polygon (roofs, gables), points counter-clockwise seen from its front side.
func poly(points: Array[Vector3], key: String) -> void:
	var tool := _tool(key + "|poly")
	var n := (points[1] - points[0]).cross(points[2] - points[0]).normalized()
	tool.set_normal(n)
	for i in range(1, points.size() - 1):
		for p: Vector3 in [points[0], points[i + 1], points[i]]:   # reversed: Godot fronts are clockwise
			tool.add_vertex(p)


## A collider without a mesh.
func shape(center: Vector3, size: Vector3, rotation := Vector3.ZERO) -> void:
	var box_shape := BoxShape3D.new()
	box_shape.size = size
	var node := CollisionShape3D.new()
	node.shape = box_shape
	node.position = center
	node.rotation = rotation
	body.add_child(node)


## Builds one MeshInstance3D per material key under `parent`.
func commit(parent: Node3D, cast_shadows := true) -> void:
	for key: String in _tools:
		var tool: SurfaceTool = _tools[key]
		var node := MeshInstance3D.new()
		var material_key := key.get_slice("|", 0)
		node.name = "Mesh_" + material_key
		node.mesh = tool.commit()
		node.material_override = _materials.get(material_key)
		if not cast_shadows or key.begins_with("glass"):
			node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		parent.add_child(node)
	_tools.clear()


func _tool(key: String) -> SurfaceTool:
	if not _tools.has(key):
		var tool := SurfaceTool.new()
		tool.begin(Mesh.PRIMITIVE_TRIANGLES)
		_tools[key] = tool
	return _tools[key]


## One quad facing `n`. Godot's front faces are clockwise seen from the viewer.
static func _face(tool: SurfaceTool, c: Vector3, half: Vector3, n: Vector3) -> void:
	var u := Vector3(n.y, n.z, n.x).abs()       # two axes spanning the face
	var v := n.cross(u)
	var center := c + n * half
	var a := u * half
	var b := Vector3(absf(v.x) * half.x, absf(v.y) * half.y, absf(v.z) * half.z) * v.sign()
	var corners := [center - a - b, center + a - b, center + a + b, center - a + b]
	if (corners[1] - corners[0]).cross(corners[2] - corners[0]).dot(n) > 0.0:
		corners.reverse()
	tool.set_normal(n)
	for i: int in [0, 1, 2, 0, 2, 3]:
		tool.add_vertex(corners[i])
