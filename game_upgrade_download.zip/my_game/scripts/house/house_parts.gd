class_name HouseParts
extends RefCounted
## The House's special pieces, built into the same Mesher: garden fences (post + rails toward
## fence neighbours), the cellar stairs (visual steps + one smooth ramp collider the player and
## the navmesh can walk) and a gabled roof over the house's footprint.


static func fence(m: Mesher, plan: Plan, c: Vector2i) -> void:
	var base := plan.center(c)
	m.box(base + Vector3(0, 0.85, 0), Vector3(0.14, 1.7, 0.14), "fence")
	for d: Vector2i in [Vector2i.RIGHT, Vector2i.DOWN]:
		if plan.fence(c + d):
			var dir := Vector3(d.x, 0, d.y)
			var size := Vector3(Config.CELL if d.x != 0 else 0.06, 1.5, Config.CELL if d.y != 0 else 0.06)
			m.box(base + dir * Config.CELL * 0.5 + Vector3(0, 0.85, 0), size, "fence")


## Visual steps plus one smooth ramp collider (walkable for the player and the navmesh).
static func stairs(m: Mesher, plan: Plan) -> void:
	if plan.stairs.is_empty():
		return
	var dir := Vector3(plan.stair_dir.x, 0, plan.stair_dir.y)
	var run := plan.stairs.size() * Config.CELL
	var drop := Config.CELLAR_DEPTH
	var start := plan.center(plan.stairs[0]) - dir * Config.CELL * 0.5
	var width := Config.CELL - Config.WALL_THICKNESS
	var steps := int(round(drop / 0.2))
	for i in steps:
		var along := (i + 0.5) * run / steps
		var top := -(i + 1) * drop / steps
		var size := Vector3(width, 0.2, run / steps)
		if dir.x != 0.0:
			size = Vector3(run / steps, 0.2, width)
		m.box(start + dir * along + Vector3(0, top - 0.1, 0), size, "wood", false)
	var slope := atan2(drop, run)
	var length := sqrt(run * run + drop * drop)
	var mid := start + dir * run * 0.5 + Vector3(0, -drop * 0.5 - 0.12 / cos(slope), 0)
	if dir.x != 0.0:
		m.shape(mid, Vector3(length, 0.2, width), Vector3(0, 0, -slope * dir.x))
	else:
		m.shape(mid, Vector3(width, 0.2, length), Vector3(slope * dir.z, 0, 0))


## A gabled roof over the house's footprint (its bounding box), ridge along the long side.
static func roof(m: Mesher, plan: Plan) -> void:
	var low := Vector2(INF, INF)
	var high := Vector2(-INF, -INF)
	for y in plan.h:
		for x in plan.w:
			var c := Vector2i(x, y)
			if not plan.outdoor(c) and not plan.fence(c) and plan.at(c) != "~":
				var p := plan.center(c)
				low = Vector2(minf(low.x, p.x), minf(low.y, p.z))
				high = Vector2(maxf(high.x, p.x), maxf(high.y, p.z))
	if low.x == INF:
		return
	var eave := Config.CELL * 0.5 + 0.35
	low -= Vector2(eave, eave)
	high += Vector2(eave, eave)
	var y := Config.WALL_HEIGHT + 0.2
	var along_x := high.x - low.x >= high.y - low.y
	# Build in a frame where the ridge runs along "u"; flip to world axes at the end.
	var u0 := low.x if along_x else low.y
	var u1 := high.x if along_x else high.y
	var v0 := low.y if along_x else low.x
	var v1 := high.y if along_x else high.x
	var rise := minf((v1 - v0) * 0.32, 2.6)
	var vc := (v0 + v1) * 0.5
	var at := func(u: float, h: float, v: float) -> Vector3: return Vector3(u, h, v) if along_x else Vector3(v, h, u)
	var slopes := [[at.call(u0, y, v1), at.call(u1, y, v1), at.call(u1, y + rise, vc), at.call(u0, y + rise, vc)],
		[at.call(u1, y, v0), at.call(u0, y, v0), at.call(u0, y + rise, vc), at.call(u1, y + rise, vc)]]
	var gables := [[at.call(u0, y, v0), at.call(u0, y, v1), at.call(u0, y + rise, vc)],
		[at.call(u1, y, v1), at.call(u1, y, v0), at.call(u1, y + rise, vc)]]
	for points: Array in slopes + gables:
		var face: Array[Vector3] = []
		face.assign(points)
		if not along_x:
			face.reverse()                  # swapping axes mirrors the winding
		m.poly(face, "roof" if points.size() == 4 else "siding")
