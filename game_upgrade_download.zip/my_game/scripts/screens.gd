class_name Screens
extends Control
## The full-screen menus, built in code over a tinted backdrop that blocks touches to the game:
## title (game title, tagline, Continue at night N when a save exists, New game, sound toggle),
## pause card (Resume, look-sensitivity slider, Restart, Home) and the caught card (night
## reached, Retry, Home). Buttons emit `command(name)`; the strings come from Hud.TEXT.

signal command(name: String)

const ICON_SOUND := "res://assets/mobile-controls/icons/icon_sound.png"
const ICON_MUTED := "res://assets/mobile-controls/icons/icon_sound_disabled.png"

var _screen: Control
var _sound: Button


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func show_title(text: Dictionary) -> void:
	var box := _open(0.35, false)
	box.add_child(UiStyle.title_label(text.title, 112, Config.CREAM))
	_label(text.tagline, 30, box)
	if GameState.best > 0:
		_label(text.best % GameState.best, 26, box).add_theme_color_override("font_color", Config.SUNNY)
	var row := _row(box)
	if GameState.has_save():
		row.add_child(_button("%s · %s" % [text.continue, text.level % (GameState.level + 1)], "continue", Config.SUNNY))
	row.add_child(_button(text.play, "play", Config.CORAL))
	_sound = UiStyle.icon_button(ICON_SOUND, Config.SKY)
	_sound.pressed.connect(_toggle_sound)
	_refresh_sound_icon()
	_screen.add_child(_sound)
	_sound.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	_sound.offset_left = -124.0
	_sound.offset_right = -32.0
	_sound.offset_top = 28.0
	_sound.offset_bottom = 120.0


func show_pause(text: Dictionary) -> void:
	var box := _open(0.55, true)
	box.add_child(UiStyle.title_label(text.paused, 70))
	box.add_child(_button(text.resume, "resume", Config.MINT))
	var help_button := _button(text.help, "help", Config.SKY)
	help_button.pressed.connect(func() -> void: show_help(text))
	box.add_child(help_button)
	_label(text.sensitivity, 24, box)
	var slider := HSlider.new()
	slider.min_value = 0.3
	slider.max_value = 2.5
	slider.step = 0.05
	slider.value = float(GameState.settings.camera_sensitivity)
	slider.custom_minimum_size = Vector2(420, 44)
	slider.value_changed.connect(func(value: float) -> void: GameState.settings.camera_sensitivity = value)
	slider.drag_ended.connect(func(_changed: bool) -> void: GameState.set_setting("camera_sensitivity", slider.value))
	box.add_child(slider)
	_label("جودة الرسومات", 26, box)
	var quality := OptionButton.new()
	for name in MobileSettings.QUALITY_NAMES:
		var arabic_name: String = str({"Low": "منخفضة", "Medium": "متوسطة", "High": "عالية", "Ultra": "فائقة"}.get(name, name))
		quality.add_item(arabic_name)
	quality.custom_minimum_size = Vector2(300, 48)	
	quality.select(maxi(0, MobileSettings.QUALITY_NAMES.find(str(GameState.settings.get("quality", "High")))))
	quality.item_selected.connect(func(index: int) -> void:
		MobileSettings.set_quality(MobileSettings.QUALITY_NAMES[index]))
	box.add_child(quality)
	var row := _row(box)
	row.add_child(_button(text.restart, "restart", Config.SUNNY))
	row.add_child(_button(text.home, "home", Config.SKY))



func show_help(text: Dictionary) -> void:
	var box := _open(0.62, true)
	box.add_child(UiStyle.title_label(text.help, 54, Config.SUNNY))
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(560, 190)
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_child(scroll)
	var instructions := _label(text.help_text, 23, scroll)
	instructions.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	instructions.custom_minimum_size = Vector2(520, 280)
	instructions.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var back := _button(text.back, "back", Config.MINT)
	back.pressed.connect(func() -> void: show_pause(text))
	box.add_child(back)

func show_game_over(text: Dictionary, night: int) -> void:
	var box := _open(0.6, true)
	box.add_child(UiStyle.title_label(text.game_over, 80, Config.CORAL))
	box.add_child(UiStyle.title_label(text.reached % night, 40, Config.CREAM))
	var row := _row(box)
	row.add_child(_button(text.retry, "restart", Config.SUNNY))
	row.add_child(_button(text.home, "home", Config.SKY))


func close() -> void:
	_sound = null   # freed with the title screen
	if _screen:
		_screen.queue_free()
		_screen = null


func _open(dim: float, with_panel: bool) -> VBoxContainer:
	close()
	var backdrop := ColorRect.new()
	backdrop.color = Color(Config.INK.darkened(0.4), dim)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(backdrop)
	_screen = backdrop
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	backdrop.add_child(center)
	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 18)
	var shown: Control = box
	if with_panel:
		shown = UiStyle.panel()
		shown.add_child(box)
	center.add_child(shown)
	_pop_after_layout(shown)
	return box


## Containers get their size one frame later; pop from the real centre then.
func _pop_after_layout(node: Control) -> void:
	node.modulate.a = 0.0
	await get_tree().process_frame
	if is_instance_valid(node):
		node.modulate.a = 1.0
		UiStyle.pop(node)


func _row(parent: Control) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 20)
	parent.add_child(row)
	return row


func _button(text: String, action: String, color: Color) -> Button:
	var node := UiStyle.button(text, color)
	node.pressed.connect(func() -> void:
		Sfx.play("click")
		command.emit(action))
	return node


func _label(text: String, font_size: int, parent: Control) -> Label:
	var label := Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", font_size)
	parent.add_child(label)
	return label


func _toggle_sound() -> void:
	var on := not bool(GameState.settings.sound)
	GameState.settings.music = on
	GameState.set_setting("sound", on)
	_refresh_sound_icon()
	Sfx.play("click")


func _refresh_sound_icon() -> void:
	if _sound:
		_sound.icon = load(ICON_SOUND if GameState.settings.sound else ICON_MUTED)
