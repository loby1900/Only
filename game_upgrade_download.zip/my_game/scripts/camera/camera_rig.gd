class_name CameraRig
extends Node3D
## One camera rig, four modes (pick with Config.CAMERA_MODE, or call set_mode() at runtime):
##   ORBIT        third-person: SpringArm3D behind the target, drag (right side / second finger /
##                right mouse) or Q/E to orbit, wheel to zoom, swings behind a moving target
##   TOP_DOWN     tilted fixed-pitch follow (arcade, twin-stick, builder games)
##   FIRST_PERSON camera at eye height (target.eye_height if it has one), drag to look, pitch
##                clamped; hides the target's model
##   FIXED        static shot from Config.FIXED_POSITION looking at Config.FIXED_LOOK_AT
## Tells the target which way is "forward" through `target.camera_basis` every frame, and
## applies Fx camera shake. Scene layout: CameraRig > SpringArm3D > Camera3D.

enum Mode { ORBIT, TOP_DOWN, FIRST_PERSON, FIXED }

const MODES := {"orbit": Mode.ORBIT, "top_down": Mode.TOP_DOWN,
	"first_person": Mode.FIRST_PERSON, "fixed": Mode.FIXED}

@export var target: Node3D

var mode := Mode.ORBIT
var yaw := 0.0
var pitch := 0.0
var distance := Config.ORBIT_DISTANCE
var title_spin := false               # slow circling behind the title screen
var _drag_cooldown := 0.0
var _sway := 0.0

@onready var arm: SpringArm3D = $SpringArm3D
@onready var camera: Camera3D = $SpringArm3D/Camera3D


func _ready() -> void:
	camera.current = true
	if target is CollisionObject3D:
		arm.add_excluded_object((target as CollisionObject3D).get_rid())
	set_mode(MODES.get(Config.CAMERA_MODE, Mode.ORBIT))
	get_viewport().size_changed.connect(_fit)
	_fit()
	snap()


func set_mode(value: Mode) -> void:
	mode = value
	arm.collision_mask = 2 if mode == Mode.ORBIT else 0   # only the orbit arm avoids walls
	match mode:
		Mode.ORBIT:
			pitch = deg_to_rad(Config.ORBIT_PITCH_DEG)
		Mode.TOP_DOWN:
			pitch = deg_to_rad(Config.TOP_DOWN_PITCH_DEG)
			yaw = deg_to_rad(Config.TOP_DOWN_YAW_DEG)
		_:
			pitch = 0.0
	if target and target.has_method("set_model_visible"):
		target.set_model_visible(mode != Mode.FIRST_PERSON)
	snap()


## Drag input in pixels (from CameraDrag). Ignored by the modes that do not look around.
func look(relative: Vector2) -> void:
	if mode != Mode.ORBIT and mode != Mode.FIRST_PERSON:
		return
	var sensitivity := Config.LOOK_SENSITIVITY * float(GameState.settings.camera_sensitivity)
	yaw -= relative.x * sensitivity
	pitch -= relative.y * sensitivity
	var limits := Config.ORBIT_PITCH_RANGE if mode == Mode.ORBIT else Config.FP_PITCH_RANGE
	pitch = clampf(pitch, deg_to_rad(limits.x), deg_to_rad(limits.y))
	_drag_cooldown = 0.8


func zoom(factor: float) -> void:
	distance = clampf(distance * factor, Config.ORBIT_ZOOM.x, Config.ORBIT_ZOOM.y)


## Jumps straight to the target (new level, respawn) instead of gliding there.
func snap(behind_yaw := 0.0, look_pitch := 0.0) -> void:
	if mode == Mode.ORBIT or mode == Mode.FIRST_PERSON:
		yaw = behind_yaw
	if mode == Mode.FIRST_PERSON:
		pitch = look_pitch
	if target:
		global_position = _goal()
	_physics_process(0.0)


func _physics_process(delta: float) -> void:
	yaw += Input.get_axis("camera_right", "camera_left") * Config.KEY_TURN_SPEED * delta
	_drag_cooldown -= delta
	if title_spin and mode != Mode.FIRST_PERSON:
		yaw += Config.TITLE_SPIN * delta
	elif title_spin:
		_sway += delta
		yaw += sin(_sway * 0.35) * Config.TITLE_SPIN * delta   # a slow uneasy glance around
	match mode:
		Mode.ORBIT, Mode.TOP_DOWN:
			if mode == Mode.ORBIT:
				_auto_align(delta)
			arm.spring_length = lerpf(arm.spring_length, distance if mode == Mode.ORBIT else Config.TOP_DOWN_DISTANCE, minf(delta * 8.0, 1.0))
			if target:
				global_position = global_position.lerp(_goal(), 1.0 - exp(-Config.CAMERA_FOLLOW * delta))
			rotation = Vector3(0.0, yaw, 0.0)
			arm.rotation.x = pitch
		Mode.FIRST_PERSON:
			arm.spring_length = 0.0
			if target:
				global_position = _goal()
			rotation = Vector3(0.0, yaw, 0.0)
			arm.rotation.x = pitch
		Mode.FIXED:
			arm.spring_length = 0.0
			arm.rotation = Vector3.ZERO
			global_position = Config.FIXED_POSITION
			look_at(Config.FIXED_LOOK_AT, Vector3.UP)
	Fx.update_shake(camera, delta)
	if target and "camera_basis" in target:
		target.camera_basis = camera.global_transform.basis


## Drifts behind a target that runs sideways, like most mobile third-person games.
func _auto_align(delta: float) -> void:
	if target == null or _drag_cooldown > 0.0 or title_spin or not "velocity" in target:
		return
	var velocity: Vector3 = target.velocity
	var flat := Vector3(velocity.x, 0.0, velocity.z)
	if flat.length() < 2.0:
		return
	var behind := atan2(-flat.x, -flat.z)
	var sideways := absf(sin(angle_difference(yaw, behind)))
	yaw = lerp_angle(yaw, behind, Config.ORBIT_AUTO_ALIGN * sideways * delta * 0.5)


func _goal() -> Vector3:
	var height := Config.EYE_HEIGHT if mode == Mode.FIRST_PERSON else Config.TARGET_HEIGHT
	if mode == Mode.FIRST_PERSON and "eye_height" in target:
		height = target.eye_height        # crouching and head bob
	return target.global_position + Vector3.UP * height


## Portrait screens keep the horizontal field of view, so the world is not cropped to a slit.
func _fit() -> void:
	var size := get_viewport().get_visible_rect().size
	if size.y > size.x:
		camera.keep_aspect = Camera3D.KEEP_WIDTH
		camera.fov = Config.CAMERA_FOV_PORTRAIT
	else:
		camera.keep_aspect = Camera3D.KEEP_HEIGHT
		camera.fov = Config.CAMERA_FOV
