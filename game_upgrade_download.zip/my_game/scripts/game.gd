class_name HorrorGame
extends Node3D
## The game: sneak into the neighbour's house at night, follow the objective chain of the level
## (find items, open locked doors, restore power) and reach the secret in the cellar without
## being caught. Owns the House, the Neighbor (+ NeighborBrain), Interaction, Tension, Scares
## and the Inventory; checkpoints after every objective; caught = jump-scare, lose a life,
## back to the last checkpoint (JumpScare); no lives left = game over.
## Contract with main.gd: start(level), stop(), title_scene(), signals score_changed,
## game_over, level_done, status_changed (objective line). main hands over player, rig, hud.

signal score_changed(value: int)
signal game_over
signal level_done
signal status_changed(text: String)

var player: Player
var rig: CameraRig
var hud: Hud
var running := false
var level: Dictionary = {}
var level_index := -1
var inventory := Inventory.new()
var objectives := Objectives.new()
var lives := Config.LIVES
var power := false
var evidence_found := 0
var evidence_total := 0

@onready var house: House = $House
@onready var surroundings: Surroundings = $Surroundings
@onready var neighbor: Neighbor = $Neighbor
@onready var brain: NeighborBrain = $Neighbor/Brain
@onready var interaction: Interaction = $Interaction
@onready var tension: Tension = $Tension
@onready var scares: Scares = $Scares
@onready var jump_scare: JumpScare = $JumpScare


func _ready() -> void:
	for node: Node in [interaction, tension, scares, jump_scare]:
		node.set("game", self)
	neighbor.house = house
	brain.neighbor = neighbor
	brain.house = house
	brain.caught_player.connect(func() -> void: jump_scare.begin())
	interaction.progress.connect(_on_progress)
	tension.watch(brain)


## Builds level `index` (only if it changed), used by start() and behind the title screen.
func load_level(index: int) -> void:
	if index == level_index and house.plan:
		return
	level_index = index
	level = Levels.get_level(index)
	WorldLook.build(get_parent(), String(level.get("look", Config.LOOK)))
	house.build(level)
	surroundings.build(house.plan)	
	# Re-apply graphics after procedural level construction; no scenery nodes are hidden.
	MobileSettings.apply_quality()
	for door in house.doors:
		door.opened.connect(func(d: Door, by_player: bool) -> void:
			if by_player and d.letter != "D":
				_on_progress("open:" + d.letter)
			if by_player and player.sprinting:
				noise(d.global_position, Config.NOISE.slam))
		door.slammed.connect(func(d: Door) -> void:
			noise(d.global_position, Config.NOISE.slam)
			Fx.shake(self, 0.3))


## Behind the title: the house seen from across the street, frozen (hidden = no physics).
func title_scene() -> void:
	load_level(GameState.level)
	brain.enabled = false
	neighbor.place(house.neighbor_start)
	var view := house.player_start + Vector3(-5.0, 0.0, 9.0)
	player.respawn(view)
	player.hidden = true
	player.eye_height = 3.2                # over the fence
	var to := Vector3(0, 1.2, -1.5) - view
	rig.snap(atan2(-to.x, -to.z), 0.12)


func start(index: int) -> void:
	stop()
	level_index = -1                     # always a fresh house: doors, items and locks reset
	load_level(index)
	inventory.clear()
	lives = Config.LIVES
	power = false
	evidence_found = 0
	evidence_total = 0
	for thing: Interactable in house.things:
		if thing.kind == Interactable.Kind.EVIDENCE:
			evidence_total += 1
	objectives.reset(level, house.player_start)
	if player.flashlight == null:
		player.attach_flashlight(rig.camera)
		player.step.connect(_on_step)
		inventory.changed.connect(func() -> void: hud.set_inventory(inventory.items))
	player.flashlight.visible = false
	place_player(house.player_start, 0.0)
	brain.player = player
	brain.tuning = level.ai
	brain.enabled = true
	brain.reset(house.neighbor_start, 2.0)
	tension.reset()
	scares.reset()
	hud.set_inventory(inventory.items)
	hud.set_lives(lives)
	running = true
	status_changed.emit(objectives.text())
	Sfx.music("calm", 2.0)


func stop() -> void:
	running = false
	jump_scare.cancel()
	interaction.unhide()
	brain.enabled = false
	if player:
		player.auto_input = Vector2.ZERO


## A sound the neighbour may hear (Config.NOISE radius, scaled by the level's "hearing").
func noise(at: Vector3, radius: float) -> void:
	brain.hear(at, radius)


func set_power(on: bool) -> void:
	power = on
	for lamp in house.lamps:
		if lamp.get_meta("wired", false):
			lamp.set_powered(on)
	for door in house.doors:
		if door.locked and door.needs == "power" and on:
			door.unlock()
			Sfx.play_at("unlock", door.global_position)


func _physics_process(delta: float) -> void:
	if not running:
		return
	if jump_scare.active:
		return
	interaction.update()
	tension.update(delta)
	scares.update(delta)
	hud.set_stamina(player.stamina, player.sprinting)


func place_player(at: Vector3, yaw: float) -> void:
	player.respawn(at)
	rig.snap(yaw)


func _on_step(radius: float, sprinting: bool) -> void:
	var outside := house.plan.outdoor(house.plan.cell_of(player.global_position))
	Sfx.play("step_grass" if outside else "step", (-6.0 if sprinting else -14.0) - (8.0 if player.crouching else 0.0))
	if radius > 0.0:
		noise(player.global_position, radius)


## An objective step done ("take:1", "open:A", "use:F", "reach:X"): checkpoint here.
func _on_progress(key: String) -> void:
	if key == "reach:X":
		_finish()
		return
	if not objectives.mark(key):
		return
	var here := NavigationServer3D.map_get_closest_point(get_world_3d().navigation_map, player.global_position)
	objectives.save_checkpoint(here, rig.yaw)
	hud.toast(Hud.TEXT.checkpoint, Config.MINT)
	status_changed.emit(objectives.text())


func _finish() -> void:
	running = false
	player.active = false
	brain.enabled = false
	neighbor.halt()
	hud.set_prompt("")
	var ending := String(level.get("secret", ""))
	if evidence_total > 0 and evidence_found >= evidence_total:
		ending += Hud.TEXT.evidence_ending
	hud.show_secret(ending)
	score_changed.emit(GameState.score + 100 * lives)
	level_done.emit()
