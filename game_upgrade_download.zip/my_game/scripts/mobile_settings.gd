extends Node
## Runtime graphics presets. Keeps every world object visible; changes render resolution,
## anti-aliasing and shadow cost only. Uses bilinear 3D scaling supported by Compatibility.

const PRESETS := {
    "Low":    {"scale": 0.55, "msaa": Viewport.MSAA_DISABLED, "shadows": false, "shadow_distance": 18.0},
    "Medium": {"scale": 0.70, "msaa": Viewport.MSAA_DISABLED, "shadows": true,  "shadow_distance": 28.0},
    "High":   {"scale": 0.85, "msaa": Viewport.MSAA_2X,       "shadows": true,  "shadow_distance": 45.0},
    "Ultra":  {"scale": 1.00, "msaa": Viewport.MSAA_4X,       "shadows": true,  "shadow_distance": 70.0}
}
const QUALITY_NAMES := ["Low", "Medium", "High", "Ultra"]
var current_quality := "High"

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    current_quality = str(GameState.settings.get("quality", "High"))
    if not PRESETS.has(current_quality):
        current_quality = "High"
    call_deferred("apply_quality", current_quality)

func set_quality(name: String) -> void:
    if not PRESETS.has(name):
        return
    current_quality = name
    GameState.set_setting("quality", name)
    apply_quality(name)

func apply_quality(name: String = "") -> void:
    if not name.is_empty() and PRESETS.has(name):
        current_quality = name
    if not PRESETS.has(current_quality):
        current_quality = "High"
    var preset: Dictionary = PRESETS[current_quality]

    # Root viewport scaling affects 3D rendering only, so HUD and touch controls stay sharp.
    var viewport := get_tree().root
    viewport.scaling_3d_scale = float(preset["scale"])
    viewport.msaa_3d = int(preset["msaa"])

    var scene := get_tree().current_scene
    if scene == null:
        return
    for node in scene.find_children("*", "Light3D", true, false):
        var light := node as Light3D
        if light == null:
            continue
        light.shadow_enabled = bool(preset["shadows"])
        if light is DirectionalLight3D:
            (light as DirectionalLight3D).directional_shadow_max_distance = float(preset["shadow_distance"])
