class_name ProbeAI
extends ProbeWalk
## Neighbour AI scenarios on level 1 (test runs only). Cells refer to level 1's plan: the hall
## (cols 8-13, rows 7-9), the kitchen (3-5, 3-5) and the right room with the wardrobe H (12,3).

const HALL_A := Vector2i(9, 8)
const HALL_B := Vector2i(12, 8)
const KITCHEN := Vector2i(4, 4)
const ROOM := Vector2i(14, 4)


func run() -> void:
	await start_level(0)
	var brain := game.brain
	var plan := game.house.plan
	brain.enabled = true
	var wardrobe: Interactable
	for thing in game.house.things:
		if thing.kind == Interactable.Kind.CLOSET and thing.global_position.y > -1.0 and wardrobe == null:
			wardrobe = thing   # the ground-floor wardrobe in the right room
	# 1. A noise the player makes far away: SUSPICIOUS, and he walks to the spot.
	_place_player(plan.center(KITCHEN), false)
	brain.reset(plan.center(HALL_A))
	await frames(3)
	game.noise(plan.center(HALL_B), Config.NOISE.sprint)
	probe.call("check", brain.state == NeighborBrain.State.SUSPICIOUS, "ai: sprint noise 4 m away → SUSPICIOUS (was %s)" % NeighborBrain.NAMES[brain.state])
	var spot := brain.noise_at
	var reached := await until(func() -> bool: return _flat(game.neighbor.global_position, spot) < 0.8, 12.0)
	probe.call("check", reached, "ai: he walks to the noise (%.1f m left)" % _flat(game.neighbor.global_position, spot))
	# 2. A lit player in front of him: CHASE.
	brain.reset(plan.center(HALL_A))
	_face_neighbor_to(plan.center(HALL_B))
	_place_player(plan.center(HALL_B), true)
	var chased := await until(func() -> bool: return brain.state == NeighborBrain.State.CHASE, 4.0)
	probe.call("check", chased, "ai: lit player in view 4.5 m away → CHASE (alert %.2f)" % brain.alert)
	# 3. Out of his sight, into a wardrobe: he searches, then gives up and patrols.
	_place_player(wardrobe.exit, false)
	await frames(3)
	game.interaction.hide(wardrobe)
	probe.call("check", not brain.saw_hide and game.player.hidden, "ai: hid unseen (saw_hide=%s)" % brain.saw_hide)
	var searching := await until(func() -> bool: return brain.state == NeighborBrain.State.SEARCH, Config.AI_LOSE_TIME + 6.0)
	probe.call("check", searching, "ai: lost the player → SEARCH (%s)" % NeighborBrain.NAMES[brain.state])
	var patrol := await until(func() -> bool: return brain.state == NeighborBrain.State.PATROL, Config.AI_SEARCH_TIME + 30.0)
	probe.call("check", patrol and game.lives == Config.LIVES, "ai: search over → PATROL, never caught (lives %d)" % game.lives)
	game.interaction.unhide()
	# 4. Seen getting into the wardrobe: he comes and drags you out.
	brain.reset(plan.center(ROOM) + Vector3(1.5, 0, 0.8))
	_face_neighbor_to(wardrobe.exit)
	_place_player(wardrobe.exit, true)
	var spotted := await until(func() -> bool: return brain.state == NeighborBrain.State.CHASE, 4.0)
	await frames(2)
	probe.call("check", spotted, "ai: lit player next to the wardrobe → CHASE")
	game.interaction.hide(wardrobe)
	probe.call("check", brain.saw_hide, "ai: seen hiding (saw_hide)")
	var dragged := await until(func() -> bool: return game.lives == Config.LIVES - 1, 12.0)
	probe.call("check", dragged, "ai: pulled out of the wardrobe → caught, a life lost")
	# 5. A stationary, lit player: he comes and catches; back at the checkpoint.
	await frames(4)
	brain.reset(plan.center(HALL_A))
	_face_neighbor_to(plan.center(HALL_B))
	_place_player(plan.center(HALL_B), true)
	var caught := await until(func() -> bool: return game.lives == Config.LIVES - 2, 12.0)
	await until(func() -> bool: return game.player.active, 4.0)
	probe.call("check", caught and game.running, "ai: stationary player caught (lives %d)" % game.lives)
	probe.call("check", _flat(game.player.global_position, game.objectives.checkpoint) < 0.8, "ai: respawned at the checkpoint")


func _place_player(at: Vector3, lit: bool) -> void:
	game.interaction.unhide()
	game.player.respawn(at)
	game.player.flashlight.visible = lit
	game.player.active = true


func _face_neighbor_to(point: Vector3) -> void:
	var to := point - game.neighbor.global_position
	game.neighbor.body.rotation.y = atan2(to.x, to.z)


static func _flat(a: Vector3, b: Vector3) -> float:
	return Vector2(a.x - b.x, a.z - b.z).length()
