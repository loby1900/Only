extends Node
## Autoload "GameState": run state (score, level), progress that survives restarts (best,
## currency, `data`), player settings, the save file and the input actions.
## Saving rules: automatic saves (debounced timer, focus loss, app pause, quit) only happen while
## a run is in play and something changed; explicit events (level done, game over, a purchase,
## a settings change) call save_now(). A missing or corrupt save just means a fresh start.

signal score_changed(score: int)
signal currency_changed(currency: int)

const SAVE_PATH := "user://save.cfg"

var score := 0
var best := 0
var level := 0                        # 0-based; the HUD shows level + 1
var currency := 0
var data: Dictionary = {}             # anything else the game wants saved (unlocks, inventory…)
var settings := {"sound": true, "music": true, "haptics": true, "camera_sensitivity": 1.0, "quality": "High"}
var playing := false                  # true while a run is in play (not on title / game over)
## Test hook: `-- --probe` runs scripts/probe.gd and never reads or writes the save.
var probe := false

var _dirty := false
var _autosave := -1.0
var _has_progress := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	probe = OS.get_cmdline_user_args().has("--probe")
	_register_input()
	if not probe:
		_load()


# ── Run and progress ────────────────────────────────────────────────────────

## A brand-new game from level 1. Best score, currency and settings are kept.
func new_game() -> void:
	level = 0
	data = {}
	mark_dirty()


func start_run() -> void:
	score = 0
	playing = true
	score_changed.emit(score)


func add_score(amount: int) -> void:
	set_score(score + amount)


func set_score(value: int) -> void:
	score = value
	score_changed.emit(score)


## Ends the run; returns true when the score is a new best. Saves.
func finish_run() -> bool:
	playing = false
	var record := score > best
	if record:
		best = score
		mark_dirty()
	save_now()
	return record


func complete_level() -> void:
	level += 1
	best = maxi(best, score)
	mark_dirty()
	save_now()


func add_currency(amount: int) -> void:
	currency = maxi(currency + amount, 0)
	currency_changed.emit(currency)
	mark_dirty()


func set_setting(key: String, value: Variant) -> void:
	settings[key] = value
	mark_dirty()
	save_now()
	Sfx.refresh()


## True when there is progress to continue from (shows the Continue button).
func has_save() -> bool:
	return _has_progress and (level > 0 or not data.is_empty())


# ── Saving ──────────────────────────────────────────────────────────────────

func mark_dirty() -> void:
	_dirty = true
	_autosave = Config.AUTOSAVE_DELAY


## Writes the save now if anything changed. Call it after meaningful events.
func save_now() -> void:
	if not _dirty or probe:
		return
	var file := ConfigFile.new()
	file.set_value("progress", "level", level)
	file.set_value("progress", "best", best)
	file.set_value("progress", "currency", currency)
	file.set_value("progress", "data", data)
	for key: String in settings:
		file.set_value("settings", key, settings[key])
	if file.save(SAVE_PATH) == OK:
		_dirty = false
		_autosave = -1.0
		_has_progress = true


func _process(delta: float) -> void:
	if _autosave < 0.0 or not playing:
		return
	_autosave -= delta
	if _autosave <= 0.0:
		save_now()


func _notification(what: int) -> void:
	match what:
		NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_WM_WINDOW_FOCUS_OUT, \
		NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_WM_CLOSE_REQUEST:
			if playing:
				save_now()


func _load() -> void:
	var file := ConfigFile.new()
	if file.load(SAVE_PATH) != OK:
		return   # no save yet, or unreadable: start fresh
	level = maxi(_read_int(file, "progress", "level", 0), 0)
	best = maxi(_read_int(file, "progress", "best", 0), 0)
	currency = maxi(_read_int(file, "progress", "currency", 0), 0)
	var saved: Variant = file.get_value("progress", "data", {})
	data = saved if saved is Dictionary else {}
	for key: String in settings:
		var value: Variant = file.get_value("settings", key, settings[key])
		if typeof(value) == typeof(settings[key]):
			settings[key] = value
	_has_progress = file.has_section("progress")


static func _read_int(file: ConfigFile, section: String, key: String, fallback: int) -> int:
	var value: Variant = file.get_value(section, key, fallback)
	return int(value) if (value is int or value is float) else fallback


# ── Input actions (keyboard + gamepad defaults; touch presses the same actions) ─

func _register_input() -> void:
	var keys := {
		"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
		"move_forward": [KEY_W, KEY_UP], "move_back": [KEY_S, KEY_DOWN],
		"jump": [KEY_SPACE], "interact": [KEY_E, KEY_ENTER], "crouch": [KEY_C, KEY_CTRL],
		"flashlight": [KEY_F, KEY_L], "run": [KEY_SHIFT], "camera_left": [], "camera_right": [],
		"pause": [KEY_ESCAPE, KEY_P],
	}
	var pads := {"jump": JOY_BUTTON_A, "interact": JOY_BUTTON_A, "crouch": JOY_BUTTON_B,
		"flashlight": JOY_BUTTON_Y, "run": JOY_BUTTON_LEFT_STICK, "pause": JOY_BUTTON_START}
	var axes := {"move_left": [JOY_AXIS_LEFT_X, -1.0], "move_right": [JOY_AXIS_LEFT_X, 1.0],
		"move_forward": [JOY_AXIS_LEFT_Y, -1.0], "move_back": [JOY_AXIS_LEFT_Y, 1.0],
		"camera_left": [JOY_AXIS_RIGHT_X, -1.0], "camera_right": [JOY_AXIS_RIGHT_X, 1.0]}
	for action: String in keys:
		if not InputMap.has_action(action):
			InputMap.add_action(action, 0.2)
		for code: int in keys[action]:
			var key := InputEventKey.new()
			key.physical_keycode = code
			InputMap.action_add_event(action, key)
		if pads.has(action):
			var button := InputEventJoypadButton.new()
			button.button_index = pads[action]
			InputMap.action_add_event(action, button)
		if axes.has(action):
			var motion := InputEventJoypadMotion.new()
			motion.axis = axes[action][0]
			motion.axis_value = axes[action][1]
			InputMap.action_add_event(action, motion)
