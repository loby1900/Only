class_name ProbeShots
extends ProbeWalk
## Screenshots for review (windowed probe runs only): exploring with the flashlight, the
## neighbour patrolling in view, a chase, hiding in a wardrobe, the jump-scare, the house from
## the street and a level complete.


func run() -> void:
	await start_level(0)
	var plan := game.house.plan
	var brain := game.brain
	# From the street: the house at dusk.
	brain.enabled = false
	_pose(plan.center(Vector2i(11, 13)), plan.center(Vector2i(11, 6)) + Vector3.UP * 1.4, false)
	await frames(30)
	await shot("02_house_outside")
	# Exploring the bedroom with the flashlight.
	_pose(plan.center(Vector2i(7, 5)), plan.center(Vector2i(10, 3)) + Vector3.UP * 0.6, true)
	await frames(30)
	await shot("03_flashlight")
	# The neighbour patrolling the hall, seen from the living-room door (crouched, dark).
	brain.enabled = true
	brain.reset(plan.center(Vector2i(12, 7)), 999.0)
	_pose(plan.center(Vector2i(8, 9)), plan.center(Vector2i(12, 7)) + Vector3.UP * 1.2, false)
	game.player.set_crouch(true)
	await frames(90)
	_look(game.neighbor.global_position + Vector3.UP * 1.2)
	await frames(2)
	await shot("04_neighbor_patrol")
	# A chase: he has seen you; you look back.
	game.player.set_crouch(false)
	brain.reset(plan.center(Vector2i(8, 8)))
	_pose(plan.center(Vector2i(11, 8)), plan.center(Vector2i(8, 8)) + Vector3.UP * 1.4, true)
	await until(func() -> bool: return brain.state == NeighborBrain.State.CHASE, 3.0)
	await frames(20)
	_look(game.neighbor.global_position + Vector3.UP * 1.3)
	await frames(2)
	await shot("05_chase")
	# Hiding in the wardrobe while he searches the room.
	var wardrobe: Interactable
	for thing in game.house.things:
		if thing.kind == Interactable.Kind.CLOSET and thing.global_position.y > -1.0 and wardrobe == null:
			wardrobe = thing   # the ground-floor wardrobe in the right room
	game.player.respawn(wardrobe.exit)
	game.player.flashlight.visible = false
	await frames(3)
	game.interaction.hide(wardrobe)
	brain.reset(plan.center(Vector2i(15, 5)), 999.0)
	brain.noise_at = wardrobe.exit + Vector3(0.8, 0, 1.2)
	brain.last_seen = brain.noise_at
	await frames(80)
	await shot("06_hiding")
	game.interaction.unhide()
	# The jump-scare.
	brain.reset(plan.center(Vector2i(9, 8)))
	_pose(plan.center(Vector2i(10, 8)), plan.center(Vector2i(9, 8)) + Vector3.UP * 1.5, true)
	await until(func() -> bool: return brain.state == NeighborBrain.State.CATCH, 5.0)
	await frames(8)
	await shot("07_caught")
	await until(func() -> bool: return game.player.active, 4.0)
	# Level complete: at the open chest in the cellar.
	brain.enabled = false
	var secret: Interactable
	for thing in game.house.things:
		if thing.kind == Interactable.Kind.SECRET:
			secret = thing
	var back := (secret.exit - secret.global_position).normalized()
	_pose(secret.exit, secret.global_position + Vector3.UP * 0.5, true)
	await frames(10)
	game.interaction.use(secret)
	_pose(secret.exit + back * 0.5, secret.global_position + Vector3.UP * 0.2, false)
	await frames(40)
	await shot("08_level_complete")


func shot(name: String) -> void:
	var dir: String = probe.get("shot_dir")
	await RenderingServer.frame_post_draw
	probe.get_viewport().get_texture().get_image().save_png("%s/%s.png" % [dir, name])
	print("PROBE shot %s" % name)


func _pose(at: Vector3, look_at: Vector3, lit: bool) -> void:
	game.interaction.unhide()
	game.player.respawn(at)
	game.player.flashlight.visible = lit
	game.player.active = true
	game.rig.snap(0.0)
	_look(look_at)


func _look(point: Vector3) -> void:
	var eye := game.player.global_position + Vector3.UP * game.player.eye_height
	var to := point - eye
	game.rig.yaw = atan2(-to.x, -to.z)
	game.rig.pitch = asin(clampf(to.normalized().y, -1.0, 1.0))
