class_name Fx
extends RefCounted
## One-shot juice for 3D games: trauma camera shake, hit flash, squash & stretch, palette
## particle bursts and phone vibration. Everything cleans up after itself.
## 3D nodes have no `modulate`: flashes use material_overlay, fades tween a material colour.

const MAX_SHAKE_OFFSET := 0.35       # metres at full trauma
const MAX_SHAKE_ROLL := 0.05         # radians at full trauma

# Materials stay alive for the whole run. Godot frees a StandardMaterial3D's shader when the last
# material using it is gone, and the web build then compiles it again on the next burst or flash:
# a 60-120 ms freeze on phones, every time. One cube mesh per size, one flash material kept around.
static var _cubes := {}
static var _flash_keepalive: StandardMaterial3D

## Adds camera shake (0..1). Works on the viewport's current Camera3D; whoever moves the
## camera calls update_shake() every frame (CameraRig does).
static func shake(from: Node, amount: float) -> void:
	var camera := from.get_viewport().get_camera_3d() if from.is_inside_tree() else null
	if camera:
		camera.set_meta("trauma", minf(float(camera.get_meta("trauma", 0.0)) + amount, 1.0))


## Decays the trauma and offsets the camera. Shake = trauma², so small hits stay subtle.
static func update_shake(camera: Camera3D, delta: float) -> void:
	var trauma := maxf(float(camera.get_meta("trauma", 0.0)) - delta * 1.5, 0.0)
	camera.set_meta("trauma", trauma)
	var amount := trauma * trauma
	var t := Time.get_ticks_msec() * 0.001
	camera.h_offset = sin(t * 47.0) * cos(t * 13.0) * MAX_SHAKE_OFFSET * amount
	camera.v_offset = sin(t * 39.0 + 1.7) * MAX_SHAKE_OFFSET * amount
	camera.rotation.z = sin(t * 31.0 + 0.6) * MAX_SHAKE_ROLL * amount


## Flashes every mesh under `root` with a colour that fades out.
static func flash(root: Node, color: Color = Color(1, 1, 1, 0.85), time := 0.25) -> void:
	if _flash_keepalive == null:
		_flash_keepalive = _flash_material(Color.WHITE)
	var material := _flash_material(color)    # own instance (its alpha fades), shared shader
	var meshes := root.find_children("*", "MeshInstance3D", true, false)
	if root is MeshInstance3D:
		meshes.append(root)
	for node in meshes:
		(node as MeshInstance3D).material_overlay = material
	var tween := root.create_tween()
	tween.tween_property(material, "albedo_color:a", 0.0, time)
	tween.tween_callback(func() -> void:
		for node in meshes:
			if is_instance_valid(node) and (node as MeshInstance3D).material_overlay == material:
				(node as MeshInstance3D).material_overlay = null)


## Squash & stretch: squashes to `amount` (y) and springs back to `base` scale.
static func squash(node: Node3D, base: Vector3 = Vector3.ONE, amount := 0.7, time := 0.35) -> void:
	var wide := sqrt(1.0 / maxf(amount, 0.1))
	if node.has_meta("squash_tween"):
		var previous: Tween = node.get_meta("squash_tween")
		if previous and previous.is_valid():
			previous.kill()
	node.scale = base * Vector3(wide, amount, wide)
	var tween := node.create_tween()
	node.set_meta("squash_tween", tween)
	tween.tween_property(node, "scale", base, time).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)


## A burst of chunky palette-coloured bits. `colors` defaults to Config.PARTICLES.
static func burst(parent: Node, position: Vector3, colors: Array = [], amount := 16, speed := 4.0, size := 0.16) -> void:
	var particles := CPUParticles3D.new()
	particles.one_shot = true
	particles.emitting = false
	particles.amount = amount
	particles.lifetime = 0.7
	particles.explosiveness = 0.95
	particles.direction = Vector3.UP
	particles.spread = 75.0
	particles.initial_velocity_min = speed * 0.5
	particles.initial_velocity_max = speed
	particles.gravity = Vector3(0, -12.0, 0)
	particles.angular_velocity_min = -360.0
	particles.angular_velocity_max = 360.0
	particles.mesh = _cube(size)
	var curve := Curve.new()
	curve.add_point(Vector2(0, 1))
	curve.add_point(Vector2(1, 0))
	particles.scale_amount_curve = curve
	var palette: Array = colors if not colors.is_empty() else Config.PARTICLES
	# A stepped gradient: each particle picks one palette colour at random.
	var offsets := PackedFloat32Array()
	var tints := PackedColorArray()
	for i in palette.size():
		offsets.append(float(i) / palette.size())
		tints.append(palette[i])
	var ramp := Gradient.new()
	ramp.interpolation_mode = Gradient.GRADIENT_INTERPOLATE_CONSTANT
	ramp.offsets = offsets
	ramp.colors = tints
	particles.color_initial_ramp = ramp
	parent.add_child(particles)
	particles.global_position = position
	particles.emitting = true
	particles.finished.connect(particles.queue_free)


## Short phone vibration, only when the player's haptics setting is on.
static func vibrate(milliseconds := 40) -> void:
	if GameState.settings.haptics:
		Input.vibrate_handheld(milliseconds)


static func _flash_material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.albedo_color = color
	return material


static func _cube(size: float) -> Mesh:
	if _cubes.has(size):
		return _cubes[size]
	var mesh := BoxMesh.new()
	mesh.size = Vector3.ONE * size
	var material := StandardMaterial3D.new()
	material.vertex_color_use_as_albedo = true   # particle colours tint the cube
	material.roughness = 0.7
	mesh.material = material
	_cubes[size] = mesh
	return mesh
